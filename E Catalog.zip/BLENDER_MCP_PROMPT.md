# Blender MCP prompt — producing 3D ball files for the Forward E-Catalog

Copy the block in **§2** verbatim into Claude (with the Blender MCP server connected).
It tells Claude exactly what our web viewer needs, and ships a ready-made Blender
Python snippet so the UVs come out correct the first time.

---

> **Update:** you no longer strictly need Blender for an STL — if you upload a raw `.stl` in
> Admin → Articles, the server now auto-converts it (decimate to ~24k tris + equirectangular UVs +
> binary GLB) and uses that. Use this Blender prompt when you want *better* results: cleaned
> topology, seam grooves per construction, exact UVs, smaller files.

## 1 · How our system consumes 3D files (why the requirements below exist)

- The catalog (Next.js + three.js / @react-three/fiber) wraps a **2048×1024 equirectangular
  (2:1) canvas texture** onto whatever model you upload: the generated panel design, the
  designer's SVG panel map (Panel Intelligence) and the selected rexine grain all live on that
  one 2:1 map.
- The viewer **auto-centres and auto-scales** any model to a unit sphere and **replaces all
  materials at runtime** — so embedded textures/materials are ignored. What matters is
  **shape + UV layout**.
- Accepted formats: **`.glb` (preferred)**, `.gltf`, `.obj`, `.stl`. STL/OBJ without UVs get
  generic spherical UVs auto-generated; a **GLB with proper equirectangular UVs aligns the
  artwork perfectly with zero fiddling** — that is what we want from Blender.
- UV convention the viewer expects (three.js space, Y-up, texture v=0 at image top):
  `u = 0.5 + atan2(z, x) / 2π`, `v = 0.5 − asin(y) / π`.
  In **Blender space (Z-up)** this is exactly:
  `u = 0.5 − atan2(Y, X) / 2π`, `v = 0.5 + asin(Z / r) / π`  (the glTF exporter converts axes).
- The SVG artwork files you received are **not** Blender input. They go to
  **Admin → Articles → “SVG panel map”** (they drive the printed design). Blender only makes
  the **physical shape** (including seam grooves / panel puff if wanted).

---

## 2 · COPY-PASTE PROMPT FOR CLAUDE (Blender MCP)

```
You are producing a 3D asset for a web catalog that wraps a 2:1 equirectangular texture
(the ball's printed design + leather grain) onto the model at runtime. The viewer
auto-centres and auto-scales the model and replaces its materials, so SHAPE and UV LAYOUT
are the only things that matter.

TASK: create/prepare ONE football (soccer ball) mesh and export it as a self-contained
binary glTF (.glb) that satisfies ALL of the following:

1. GEOMETRY
   - A single closed ball mesh (join shells if needed), normals facing outward.
   - Real-world size: size-5 ball = 0.22 m diameter (any size works, it is auto-scaled,
     but keep it sane).
   - Origin exactly at the ball's centre; apply all transforms (location/rotation/scale).
   - Polygon budget 20k–60k triangles. Use Decimate/Subsurf to stay inside it.
   - OPTIONAL SHAPE DETAIL (only if I ask for it per article):
     * "hand-stitched": shallow V-grooves along the panel seams (1–1.5 mm deep) so the
       stitching channels read in silhouette;
     * "thermal-bonded": perfectly smooth sphere with fused-panel edges as very shallow
       (0.3 mm) grooves;
     * otherwise: plain sphere is fine.

2. UVs — CRITICAL, use EXACTLY this equirectangular layout (Blender Z-up coordinates),
   computed per loop from the vertex position, with seam-wrap fix per polygon.
   Run this Python in Blender on the target object (replace OBJ_NAME):

   import bpy, math
   obj = bpy.data.objects["OBJ_NAME"]
   me = obj.data
   if not me.uv_layers:
       me.uv_layers.new(name="UVMap")
   uvl = me.uv_layers.active.data
   mw = obj.matrix_world
   for poly in me.polygons:
       us = []
       for li in poly.loop_indices:
           co = mw @ me.vertices[me.loops[li].vertex_index].co
           r = max(co.length, 1e-9)
           u = 0.5 - math.atan2(co.y, co.x) / (2 * math.pi)
           v = 0.5 + math.asin(max(-1.0, min(1.0, co.z / r))) / math.pi
           uvl[li].uv = (u, v)
           us.append(u)
       if max(us) - min(us) > 0.5:          # polygon crosses the back seam
           for li in poly.loop_indices:
               u, v = uvl[li].uv
               if u < 0.5:
                   uvl[li].uv = (u + 1.0, v)
   me.update()

   The u=0/1 seam must end up at the BACK of the ball (−Y in Blender), and v=0 must be the
   TOP pole. Do not use Smart Project, Cube Project or unwrap operators — the formula
   above is the contract with the web viewer.

3. MATERIALS / TEXTURES
   - Delete all materials and do not pack or reference any images. The website applies
     its own material at runtime.
   - Keep exactly ONE UV map named "UVMap".

4. EXPORT
   - Format: GLB (binary glTF), single file, nothing external.
   - Settings: use_selection=True (only the ball), export_apply=True,
     export_materials='NONE' (or export with an empty material), export_yup=True,
     no animations, no cameras, no lights.
   - File name: <ARTICLE_NO>.glb (e.g. FS-TB-01.glb). Keep it under ~5 MB.

5. REPORT BACK
   - Triangle count, bounding-box diameter, UV seam location confirmation, file path,
     and a viewport screenshot from the front (+Y view) so I can check the seam is at back.

Do not deviate from the UV formula. If the source mesh already has UVs, overwrite them
with the formula above.
```

### Per-article one-liners to append after the block

- `ARTICLE_NO = FS-TB-01 (FLARE), shape: thermal-bonded, smooth sphere with 0.3 mm fused-panel grooves.`
- `ARTICLE_NO = FS-HS-06 (MATCH), shape: hand-stitched, 32-panel, 1.2 mm seam grooves, slight panel puff.`
- `ARTICLE_NO = FS-MS-10 (HFT), shape: machine-stitched, 32-panel, 0.8 mm stitch channels.`
- `ARTICLE_NO = FS-VB-14 (VOLLEY BALL), shape: volleyball, 18 shallow arc panels, smooth.`
- `ARTICLE_NO = FS-MB-13 (MINI BALL), shape: size-1 mini ball, 0.15 m diameter, smooth.`

---

## 3 · QC checklist before uploading

1. File opens in https://gltf-viewer.donmccurdy.com (or Blender) and looks like a ball.
2. Triangle count 20k–60k; file < 5 MB.
3. In Blender: UV editor shows a full 0..1 equirectangular spread (not islands/scattered).
4. No materials/textures embedded.
5. Upload: **Admin → Articles → edit → “3D shape of this ball” → Upload 3D model**, then use
   the alignment sliders with the live preview if the design needs rotating onto the seams
   (with correct UVs it should need little or nothing).

## 4 · If Claude offers alternatives

- **Yes:** `.glb` with the UV formula above.
- **Acceptable:** `.stl`/`.obj` (viewer auto-generates spherical UVs; alignment sliders needed).
- **No:** `.blend` (browser can't read it), `.fbx` (not accepted), GLB with Smart-Project UVs
  (artwork will not line up), models with the ball off-origin or multiple loose shells.
