# Forward Sports E-Catalog — Project Handbook

> Read this file first whenever you return to this project. It explains what the system is,
> how every part works, how to run it (locally and in Docker), and what to build next.

**Owner:** Forward Sports (Pvt) Ltd — Sialkot, Pakistan (forward.pk)
**Purpose:** An interactive, customizable e-catalog where buyers configure footballs in live 3D —
choose construction, article, rexine material, add their own logo, see the interior construction,
and request a quote. Only admins can change catalog content.

---

## 1. What the system does (feature map)

| # | Feature | Where |
|---|---------|-------|
| 1 | 7 construction families (Hand-Stitched, Machine-Stitched, Thermal-Bonded, Hybrid, AMB/Mini, Volleyballs, Medicine Balls) in a **single-page catalog** with sticky section navigation | `/catalog` |
| 2 | Article list per section with **live price ranges** (base price + min/max rexine adjustment) | `/catalog` left column |
| 3 | **Live 3D ball** — rotate, zoom, "Texture close-up" that flies into the rexine grain | `/catalog` right rail (studio) |
| 4 | **Rexine material picker** — photo, finish, detail, manual price adjustment per material; switching re-skins the ball instantly | `/catalog` right rail |
| 5 | **Customer logo upload** — buyers drop their own logo and see it printed on the ball (stays in their browser) | `/catalog` right rail |
| 6 | **"Look inside" exploded view** — the ball animates apart into rexine cover, impact foam (mm), woven fabric lining and bladder, each labelled; hover a layer card to isolate it | `/catalog` right rail |
| 7 | **Panel Intelligence** — auto-detects panel shapes from a vector export (SVG) of a CorelDRAW design and applies the selected rexine *panel by panel* | `src/lib/svgPanels.ts`, `src/lib/ballTexture.ts` |
| 8 | **CorelDRAW (.cdr) pipeline** — admin uploads design source files; tracked with statuses (received → in-review → ready → linked) | Admin → CorelDRAW files |
| 9 | **Quote requests** — one click packages article + rexine + logo + quantity + volume tier into a request with a reference number (FSQ-…) | `/catalog` + Admin → Quote requests |
| 10 | **Volume discount tiers** (500/1000/5000 pcs) editable in admin settings | `settings.quoteTiers` |
| 11 | **Self-tuning insights engine** — logs every view/material pick/logo/quote and generates recommendations (popular rexines, viewed-but-not-quoted pricing risks, missing photos, overdue compliance reviews) | Admin → Overview |
| 12 | **Compliance radar** — FIFA Quality, REACH, ISO 9001, SA8000, Prop 65, EN 71 with review dates | Admin → Compliance |
| 13 | **Guided tour** — spotlight walkthroughs for home, catalog and admin; auto-offers on first visit, replayable via header "Tour" button | `src/components/Tour.tsx` |
| 14 | **Admin dashboard** — full CRUD for articles, materials, categories, uploads, quotes, compliance, settings | `/admin` |
| 15 | Mobile experience — articles tap to open a full-screen 3D configurator sheet; bottom "Configure in 3D" bar | `/catalog` |
| 16 | **Admin-uploaded layer photos** — real pictures of your bladder, foam, lining and rexine replace the generated look in the exploded view, with your own descriptions and thicknesses | Admin → Articles |
| 17 | **Per-article 3D shape** — upload a `.glb/.gltf/.obj` model (rexine still applied live) or a static 3D render; each construction can look physically different (hand-stitched seam gap vs flush bonded) | Admin → Articles |
| 18 | **Seam / construction look** — hand-stitched, machine-stitched, thermal-bonded or hybrid seam rendering, drawn on top so the rexine never covers the panel lines | Admin → Articles |
| 19 | **Editable front-page samples** — the home hero balls (Match White, Carbon Edition, Lava TPU) are real article + rexine combos you choose, each with its own Look inside | Admin → Front page |
| 20 | **STL / OBJ / GLB 3D models** — upload a real ball mesh; spherical UVs are generated automatically for STL and the live rexine + panel map wrap onto it, with alignment sliders and a live preview | Admin → Articles |
| 21 | **Buyer-positioned logo** — drag the logo anywhere on the 3D ball, or use panel presets, size, rotation and a white-patch toggle | `/catalog` studio |

---

## 2. Tech stack

- **Next.js 16** (App Router, Turbopack builds, `output: "standalone"` for Docker)
- **React 19** + **TypeScript**
- **Tailwind CSS v4** (theme tokens in `src/app/globals.css` — brand crimson `#CB0000` matched to forward.pk)
- **three.js + @react-three/fiber + @react-three/drei** — the 3D ball viewer
- **PostgreSQL + Drizzle ORM** (`src/db/schema.ts`)
- **lucide-react** icons, **@fontsource-variable/archivo + manrope** fonts (self-hosted, no build-time network)

---

## 3. Running it

### 3a. Docker (recommended)

```bash
# Build + start everything (app on http://localhost:3000, Postgres in a container):
docker compose up --build -d

# Optional overrides (create a .env file next to docker-compose.yml):
ADMIN_PASSWORD=your-real-password
POSTGRES_PASSWORD=your-db-password
```

That's it. On first boot the app **creates its own tables and seeds the catalog automatically**
(see `src/instrumentation.ts` → `src/db/bootstrap.ts` → `src/db/seed.ts`). No migrations to run.

**Before building, verify your project copy is COMPLETE.** Sizes to compare against
(Docker prints the context size in the line `transferring context: …`):

| Item | Expected size | If missing |
|---|---|---|
| whole build context | **≈ 3.1 MB** | build fails or app is broken |
| `public/` (textures + designs) | ≈ 2.4 MB | no rexine photos, flat 3D grain |
| `src/` | ≈ 336 KB | nothing works |
| `package.json` | 1 KB | build fails immediately |
| `package-lock.json` | ≈ 305 KB | optional — Dockerfile falls back to `npm install` |

Must-have files: `package.json`, `src/`, `public/textures/*.jpg` (6 files),
`public/designs/panel-map-ultrabond.svg`, `Dockerfile`, `.dockerignore`,
`docker-compose.yml`, `next.config.ts`.

If Docker reports `transferring context: 255.14kB` (or anything far below 3 MB) your copy is
incomplete — re-copy the project folder, especially `public/`.

Useful commands:
```bash
docker compose logs -f web        # watch server logs (seed/bootstrap messages appear here)
docker compose down               # stop (data persists in volumes)
docker compose down -v            # stop AND delete all data (fresh start)
docker compose up --build -d      # rebuild after code changes
docker volume ls                  # pgdata (database) + uploads (CDR files, textures)
```

### 3a-i. If the Docker build fails on npm network errors (common on Windows/office networks)

Symptom: the build reaches `[deps 4/4] RUN npm …` and then hangs for many minutes before failing
with `npm error code ECONNRESET` / `Invalid response body while trying to fetch https://registry.npmjs.org/next`.
Because the image never finishes building, **no containers are created at all** — that is expected
Compose behaviour, not a bug in the app.

Fixes, in order of preference:

**1 · Use a faster npm mirror for the build** (the Dockerfile already supports this):
```bash
# Windows PowerShell
$env:NPM_REGISTRY="https://registry.npmmirror.com"
docker compose build --build-arg NPM_REGISTRY=$env:NPM_REGISTRY
docker compose up -d

# Windows cmd
set NPM_REGISTRY=https://registry.npmmirror.com
docker compose up --build

# Or permanently: copy .env.example to .env and set NPM_REGISTRY there
```
The install is already retry-hardened (5 retries, 15 min timeout, 3 sockets) — a mirror usually
turns a 25-minute hang into a 2-minute success.

**2 · Check Docker Desktop's network/proxy** — Settings → Resources → Proxies. If your office needs a
proxy, set it there (Docker builds inherit it) or use the mirror above.

**3 · Plan B — run the app on Windows, Postgres in Docker.** This bypasses the in-container npm
network completely and gets you a running catalog fastest:
```bash
docker compose -f docker-compose.db.yml up -d     # Postgres only, on localhost:5432
npm install                                       # uses your normal Windows npm (usually works fine)
npm run build

# Windows cmd:
set DATABASE_URL=postgresql://postgres:postgres@127.0.0.1:5432/app_db
set ADMIN_PASSWORD=forward2026
npm run start
# → http://localhost:3000   (tables + seed are created automatically on boot)
```
PowerShell equivalent: `$env:DATABASE_URL="postgresql://postgres:postgres@127.0.0.1:5432/app_db"`

Development mode instead of `npm run start`: `npm run dev` (same env vars).

**4 · Build the image once on a machine with good internet**, then ship it:
```bash
docker save e-catalog-web | gzip > ecatalog-image.tar.gz     # on the good machine
docker load < ecatalog-image.tar.gz                          # on your machine
docker compose up -d --no-build
```

Backups:
```bash
docker compose exec db pg_dump -U postgres app_db > backup-$(date +%F).sql
cat backup.sql | docker compose exec -T db psql -U postgres app_db   # restore
```

Uploaded files (CorelDRAW files, admin-uploaded textures/artwork) live in the `uploads`
Docker volume mounted at `/app/storage/uploads`. Back it up with:
```bash
docker run --rm -v <project>_uploads:/data -v $(pwd):/backup alpine tar czf /backup/uploads.tar.gz -C /data .
```

### 3b. Local development (no Docker)

```bash
npm install
# .env must contain: DATABASE_URL=postgresql://postgres:postgres@127.0.0.1:5432/app_db
npm run dev
```
Tables + seed are created automatically on server start. You can also force it any time:
`curl http://localhost:3000/api/seed` (idempotent).

Optionally sync the schema from `src/db/schema.ts` instead of the bootstrap DDL:
`npx drizzle-kit push` — both produce the same schema.

### 3c. Environment variables

| Variable | Default | Purpose |
|---|---|---|
| `DATABASE_URL` | — (required) | Postgres connection string |
| `ADMIN_PASSWORD` | `forward2026` | Admin login password. **Change in production.** The login page shows the demo hint only while no `ADMIN_PASSWORD` is set |
| `POSTGRES_PASSWORD` | `postgres` | Docker compose only — Postgres container password |

---

## 4. Admin guide

### 4.0 Logging in (step by step)

The admin is **deliberately invisible on the public site** — no links, buttons or hints anywhere.
It is reachable only by typing the URL directly:

1. Open `http://localhost:3000/admin` (the only address it lives at).
2. Enter the password: the value of the `ADMIN_PASSWORD` environment variable.
   - Default when unset: `forward2026`. Set your own in `.env` next to `docker-compose.yml`
     (`ADMIN_PASSWORD=…`) then `docker compose up -d` again to apply. The login page never displays
     the password.
3. The session lasts 2 days (httpOnly cookie `fs_admin_token`). "Sign out" in the left sidebar ends it.
4. Everything you change is **live on the public catalog immediately** — there is no publish step
   except the per-article `live / draft` status.

**Tabs:** Overview · Articles · Rexine materials · CorelDRAW files · Front page · **Site content** ·
Quote requests · Compliance · Settings.

### 4.0.0 Editing every word on the site (Site content tab)

Admin → **Site content** lists *every* public string — hero badge/titles/paragraph/buttons, stat
labels, capacity card, section headings, featured heading, the three process steps (label/title/text),
capability chips, compliance heading/text, closing CTA, catalog page heading/intro, all 3D studio
labels (materials heading, “Inside this ball”, price heading + FOB sub-line, quote button, look-inside
and close-up buttons, mobile bar button), and the whole footer (about, address, email, phone, hours,
compliance note, copyright, crafted-in line). Grouped, searchable, with an “edited” marker per field,
Reset-to-defaults and one Save button. Stored in `settings.content`; pages fall back to built-in
defaults for anything empty. Category names/taglines/descriptions are edited under **Articles →
categories data** via the Categories records (Admin API) and article/material names in their tabs —
i.e. there is no hard-coded copy left on the public pages.

### 4.0.1 Adding layer photos (bladder, foam, lining, rexine) — the "Look inside" pictures

Admin → **Articles** → edit an article → block **“Look inside” layer photos**:

| Layer | What to upload | What the buyer sees |
|---|---|---|
| Rexine cover | photo of the actual cover material | replaces the generated cover skin in the exploded view |
| Impact foam | photo of your foam sheet / cross-section | the foam shell shows that exact photo |
| Fabric lining | photo of the winding / lining fabric | the lining shell shows that exact photo |
| Bladder | photo of the real bladder | the bladder shows that exact photo |

Next to them, the description fields (**Bladder description**, **Fabric lining description**,
**Foam thickness (mm)**, **Cover note**) are the text printed on each layer's label in the exploded
view. Photos are optional — if a layer has no photo, the system uses its realistic generated look
(cream EVA foam, woven cotton-poly lining, dark butyl or light latex bladder).

Tips: square-ish macro photos work best (they are wrapped on a curved shell); JPG/PNG/WebP up to 25 MB.

### 4.0.2 Uploading a separate 3D shape for an article

Different constructions sit differently — hand-stitched panels have a visible gap, bonded panels are
flush. Admin → **Articles** → edit → block **“3D shape of this ball”**:

- **3D model (.glb / .gltf / .obj / .stl)** — best option. The model replaces the generated sphere, and
  the live rexine texture + Panel Intelligence design are still wrapped onto it, so switching materials
  keeps working. The viewer auto-centres and auto-scales any model to fit.

**Yes, an STL of a 32-panel ball works — and it is now crash-proof.** Raw CAD/scan STLs are far too
heavy for browsers (hundreds of thousands to millions of triangles; ASCII STLs double in size as JS
strings — this used to kill the tab the moment a file was picked). So since this revision the server
**converts every uploaded STL immediately** (`src/lib/stlNormalize.ts`, called from `/api/upload`):

1. Parses binary or ASCII STL on the server (no browser involvement).
2. Welds/decimates it to ~24k triangles (spatial quantisation, degenerates dropped).
3. Bakes the equirectangular UVs the viewer expects (`u = 0.5 − atan2(y,x)/2π`, `v = 0.5 + asin(z/r)/π`,
   with back-seam vertex duplication) and radial normals.
4. Writes a self-contained binary **.glb** next to the original and returns it as `derivedUrl`;
   the admin form stores **the GLB**, not the STL, in `articles.model_url`. The original STL stays in
   storage as the source of record (uploads note: "normalized to glb on upload"; deleting the upload
   removes both files).

Tested: a 39,200-tri binary STL (1.9 MB) → 23,904-tri GLB (673 KB); an ASCII STL → 1,096-tri GLB.
Extra safety nets: uploads >25 MB refused with a decimate-first message; the viewer refuses any model
>900k triangles and falls back to the generated ball; the admin 3D preview is wrapped in SafeBoundary.
The browser-side `applySphericalUVs()` remains only as a legacy fallback for old rows pointing at .stl.
Notes:
- The UV seam is deliberately placed at the **back** of the ball so it is never visible from the front.
- STL gives you the *shape* (including real panel bumps/gaps if the model has them). The panel *design*
  still comes from your SVG panel map / artwork / procedural style — the two are independent.
- Because STL has no artwork coordinates, the design may not line up with the model's geometric panel
  seams at first. Use the **Align the design on this 3D shape** sliders that appear in the article form
  as soon as a model is attached: *Rotate model*, *Shift design ↔*, *Shift design ↕*, *Design scale*,
  with a **live 3D preview** right next to them. Saved to `articles.model_adjust` and used on the public
  catalog. Expect a few minutes of fiddling per model, once.
- Prefer **.glb** when you can: it can carry UVs (perfect alignment with no fiddling) and is smaller.
  Free convertors: Blender (Import STL → Export glTF .glb — see `BLENDER_MCP_PROMPT.md`), or any
  online STL→GLB tool. If you upload a raw STL anyway, the server now auto-converts it (above).
- **Static 3D render (png/jpg)** — if you only have a rendered picture, upload it here. Buyers see the
  render for the assembled ball; clicking **Look inside** still gives the real exploded 3D layers.
- **Nothing uploaded** — the system generates the ball from *panel style + seam style + colours +
  vector panel map*.

Priority: **3D model → static render → generated ball**.

**Blender via Claude MCP:** the exact copy-paste prompt (including the Blender Python UV script that
matches our viewer's equirectangular convention, export settings, per-article shape notes and a QC
checklist) lives in **`BLENDER_MCP_PROMPT.md`** at the project root. Short version: ask for a
**single-centred ball mesh, 20–60k tris, no materials, exported as `.glb`, UVs computed with
`u = 0.5 − atan2(Y,X)/2π`, `v = 0.5 + asin(Z/r)/π` + per-polygon seam fix**. Remember the received
**SVG artworks are not Blender input** — they go to Admin → Articles → “SVG panel map”.

**About the CDR files you are collecting:** CorelDRAW is a 2D illustration program — a `.cdr` cannot
be loaded as a 3D model. Three ways to use what your designer gives you:
1. **2D panel map (works today, no extra software):** in CorelDRAW do *File → Export → SVG* with the
   panels laid out as a 2:1 rectangle → upload in the article form → Panel Intelligence applies the
   rexine panel by panel. This is the recommended route for all designs.
2. **3D model:** ask whoever models the balls (or use free Blender) to export **.glb** with a single
   UV-unwrapped sphere/equirectangular UV map. Upload it as the article's 3D model.
3. **Render:** export a PNG/JPG picture of the 3D view and upload it as the static render.
The `.cdr` itself is still stored in **CorelDRAW files** as the source of record.

### 4.0.3 Seam / construction look

Admin → Articles → **Seam / construction look** controls how panel seams are drawn:

| Setting | Result |
|---|---|
| Hand-stitched | wide open seam channel + cream waxed-thread dashes (the "little space" hand-stitched balls have) |
| Machine-stitched | narrow channel + tight lock-stitch dashes |
| Thermal bonded | hairline fused groove, no thread |
| Hybrid | bonded channel + stitch points |
| Auto | picks from the panel style (volley/medicine/mini → bonded, else machine) |

Seeds already set: hand-stitched→hand, machine-stitched→machine, thermal-bonded/AMB/volley/medicine→bonded, hybrid→hybrid.

### 4.0.35 Logo placement — buyers position their own logo

When a buyer uploads a logo in the catalog, they control exactly where it sits:

- **Drag it on the ball** — pointer-drag directly on the 3D surface; the hit point is converted to wrap
  coordinates (`useLogoDrag()` in `BallViewer.tsx` reads `intersection.uv`), orbit controls pause while
  dragging, and the ball stops auto-spinning as soon as a logo is loaded so it is easy to place.
- **Panel presets** — Front panel, Left panel, Right panel, Top, Bottom (one click each).
- **Size** (30–200%), **Rotation** (−180…180°) and a **white patch behind logo** toggle (turn it off for
  logos that should print straight onto the rexine).
- **Reset** returns to the default front-centre position.

A logo near the wrap edge is drawn three times (x−W, x, x+W) so it is never sliced in half at the seam.
Position is kept in the browser only (`LogoTransform {u,v,scale,rotate,badge}`) and the logo file never
leaves the buyer's machine; only its filename is stored with the quote request.

### 4.0.4 Front-page hero samples (Match White / Carbon Edition / Lava TPU)

Admin → **Front page**. Each sample = a label + an article + a rexine. The home-page hero renders that
combination in live 3D with its own **Look inside** button and layer cards. Add, remove and reorder as
many samples as you like; changes are live on save. Because a sample points at a real article, it
automatically inherits that article's 3D model, render, vector panel map, seam style, interior specs
and layer photos. Stored in `settings.heroPresets`.

### 4.1 The rest of the dashboard

1. Go to `/admin` → password = `ADMIN_PASSWORD` (demo: `forward2026`).
2. **Overview** — stats, smart insights, top-selected rexines, compliance radar, buyer activity feed.
3. **Articles** — create/edit designs in any section: article number, base price, MOQ, panel style,
   brand colours, featured flag, live/draft status, **interior specs** (bladder / lining / foam mm —
   these power the exploded "Look inside" view), **SVG panel map** (Panel Intelligence), optional
   full-wrap bitmap artwork, and a link to its CorelDRAW source file. A live preview ball renders
   in the form while you edit.
4. **Rexine materials** — upload a macro photo, finish, thickness, gsm, detail text, and the
   **price adjustment** added to every article. Active toggle hides/shows in the catalog.
5. **CorelDRAW files** — drag-drop `.cdr/.ai/.eps/.pdf/.svg`; move through statuses; link to an article.
6. **Quote requests** — every buyer submission with reference, configuration, totals; update status
   (new → contacted → sampling → closed).
7. **Compliance** — standards, statuses and review dates. Overdue non-compliant items become
   insights warnings on the Overview.
8. **Settings** — company info, sales email, lead time, currency, default MOQ, volume discount tiers (JSON).

### The designer hand-off (CorelDRAW workflow)

1. Designer uploads the `.cdr` in **Admin → CorelDRAW files** (source of record).
2. For Panel Intelligence: in CorelDRAW do **File → Export → SVG**, with the panel map laid out as a
   **2:1 (equirectangular) rectangle** (e.g. 2048×1024), one closed shape per panel, panels filled with
   their design colour, curves outlined, no gradients needed. Upload that SVG in the article form.
   The engine auto-detects every panel and re-skins each with the buyer's chosen rexine.
   *(Demo file shipped: `public/designs/panel-map-ultrabond.svg` on article FS-TB-3210.)*
3. Alternative: export a flat **2:1 PNG/JPG wrap** and attach as "full-wrap artwork".
4. If neither is attached, the system generates a design procedurally from the article's
   **panel style + colours** (classic-32, geo-24, vortex-18, stripe-14, volley-18, mini-star, medicine).

**Limitation to know:** browsers cannot parse `.cdr` natively (proprietary Corel format). The SVG/PNG
export step is the bridge. If you ever get a licensed CDR parsing service or convert designs to GLB 3D
models, see the roadmap (§9).

---

## 5. Codebase map

```
src/
  db/
    schema.ts        Drizzle table definitions (source of truth for the data model)
    bootstrap.ts     Idempotent CREATE TABLE IF NOT EXISTS DDL (runs on every boot — Docker friendly)
    seed.ts          Seed data: 7 categories, 16 articles (with interior specs), 6 rexines,
                     compliance items, settings. Re-runnable; enriches missing fields only.
    index.ts         Drizzle client + pg Pool (reads DATABASE_URL)
  instrumentation.ts Next.js boot hook: bootstrap schema → seed
  lib/
    ballTexture.ts   THE texture engine: paints a 2048×1024 equirectangular canvas
                     (procedural designs | full-wrap artwork | SVG panel maps),
                     tiles the rexine grain densely, adds logo + shading
    svgPanels.ts     Panel Intelligence: parses SVG exports, extracts every panel shape (Path2D)
    settings.ts      Reads settings keys (quote tiers etc.)
    insights.ts      Self-tuning engine: stats + rule-based recommendations from activity log
    adminAuth.ts     Password → sha256 cookie session (ADMIN_COOKIE=fs_admin_token)
    tour-steps.ts    Guided-tour step definitions (home / catalog / admin)
    utils.ts         cn(), money/date formatting, fire-and-forget activity logger
  components/
    Configurator.tsx THE catalog page client: one-page sections + sticky 3D studio,
                     material picker, logo upload, exploded-view layer cards, price engine,
                     quote modal, mobile sheet
    BallViewer.tsx   React-Three-Fiber canvas: textured ball, camera rig (close-up zoom),
                     ExplodedBall (4 wedge-cut shells + HTML labels + focus dimming)
    BallThumb.tsx    Fast 2D circular preview of a design (used in lists + admin)
    HeroBall.tsx     Home-page hero 3D ball with preset skins
    Tour.tsx         Guided-tour provider (spotlight overlay, first-visit nudge, localStorage memory)
    Header.tsx / Footer.tsx / CategoryIcon.tsx
    admin/
      AdminStudio.tsx   Dashboard shell: Overview (insights), Quotes, Settings tabs
      AdminEditors.tsx  Articles / Materials / CorelDRAW files / Compliance tabs + forms
      FrontPageTab.tsx  Home-page hero samples editor (label + article + rexine, reorderable)
      AdminLogin.tsx    Password screen
      ui.tsx            Shared admin primitives + api()/uploadFile() fetch helpers
  app/
    page.tsx                       Home (hero, 7 sections grid, featured, process, compliance, CTA)
    catalog/page.tsx               THE one-page catalog (server → Configurator client)
    admin/page.tsx                 Admin gate (cookie check → AdminStudio or AdminLogin)
    api/
      health/                      Liveness (select 1)
      seed/                        Manual idempotent re-seed
      activity/                    POST buyer events (whitelist: article_view, category_visit,
                                   material_select, logo_upload, quote_request)
      quote/                       POST quote request → ref FSQ-…
      upload/                      POST multipart (admin only) → storage/uploads + uploads row
                                   (.cdr .ai .eps .pdf .svg = design-file; png/jpg/jpeg/webp = image)
      files/[name]/                GET serves stored uploads (safe basename only, immutable cache)
      admin/login|logout/          Cookie session
      admin/[resource]/            Admin CRUD router: articles, materials, categories, quotes,
                                   uploads, compliance, settings, insights, activity
public/
  textures/rx-*.jpg                The 6 seeded rexine macro photos
  designs/panel-map-ultrabond.svg  Demo Panel Intelligence file (92 detected panels)
storage/uploads/                   Runtime uploads (Docker volume — never commit)
Dockerfile · docker-compose.yml · .dockerignore · next.config.ts (output: "standalone")
```

---

## 6. How the key engines work

### 6.1 3D texture pipeline (`lib/ballTexture.ts`) — "rexine on panels, seams untouched"
Everything is one 2048×1024 equirectangular canvas wrapped onto a sphere. The key design rule:
**every design is reduced to a PANEL SET** (a list of closed `Path2D` shapes + their colours), whether
it comes from the designer's SVG or from a procedural generator. Then one painter handles all of them:

1. **Seam background** — the whole map is filled with the seam colour first. This is what shows through
   the channels between panels.
2. **Per panel** — clip to the panel shape → fill with the selected rexine (tiled at `GRAIN_TILE = 230px`
   so the grain reads clearly) → three grain passes (`overlay 0.95` relief, `multiply 0.40` tone,
   `soft-light 0.55` sheen) → multiply the designer's original panel colour at 0.55 so the design stays
   recognisable. **Because the fill is clipped, the rexine can never spill over the seam lines.**
3. **Seams drawn last, on top** — style-dependent (see §4.0.3): a dark channel stroke, then a dashed
   thread stroke for stitched constructions or a hairline groove for bonded ones. Nothing is painted
   over them afterwards, which is exactly the "leave the lines untouched" requirement.
4. **Decor + shading + logo** — optional per-design extras (medicine-ball text), pole shading, then the
   buyer's logo on a white rounded patch at the map centre (the sphere rotation presents it to camera).
5. The canvas becomes a `THREE.CanvasTexture` used as `map` **and** `bumpMap` (bumpScale 1.1) on a
   `meshPhysicalMaterial` with clearcoat → grain catches the light.

Tuning knobs: `GRAIN_TILE` (smaller = finer grain), the alphas inside `stampGrain()`, and the seam
widths/dashes in `seamSpecFor()`.

Source priority for the design itself: **SVG panel map (Panel Intelligence) → full-wrap bitmap artwork →
procedural generator** chosen by `panelStyle`.

### 6.1.1 3D shape priority (`BallViewer.tsx`)
**uploaded model (.glb/.gltf/.obj/.stl)** → **static render image** (shown for the assembled view; Look
inside still uses real 3D layers) → **generated sphere**.

`useUploadedModel()` picks the right three.js loader by extension, then `normalise()` centres the object
and scales it to a unit sphere. For **STL** (and any mesh without UVs) `applySphericalUVs()` computes
equirectangular UVs from each vertex direction — `u = 0.5 + atan2(z,x)/2π`, `v = 0.5 − asin(y)/π` — which
puts the UV seam at the back of the ball. `articles.model_adjust` then rotates the model and offsets /
scales the texture so the design lines up with the model's own panel seams.

All loaders are "safe": on a bad URL they silently fall back to the generated ball instead of breaking
the canvas. The same `uv` from a pointer intersection powers buyer logo dragging (§4.0.35).

### 6.2 Panel Intelligence (`lib/svgPanels.ts`)
`loadSvgPanels(url)` fetches the SVG, parses it with `DOMParser`, converts every
`path/polygon/polyline/rect/circle/ellipse` into a `Path2D`, respects each shape's `fill` colour,
and caches by URL. The painter clips to each detected panel, fills with the tiled rexine pattern,
multiplies the designer's fill colour over it, and strokes the seams. The detected panel count is
reported to the UI badge ("Panel Intelligence · N panels auto-detected").

### 6.3 Exploded "Look inside" view (`BallViewer.tsx → ExplodedBall`)
Four concentric **wedge-cut shells** (90° opening facing the camera):
cover r=1.0 (the live rexine texture) → foam r=0.8 → lining r=0.63 → bladder r=0.48 + valve stem.

**Admin photos win:** each shell uses `articles.layer_images[cover|foam|lining|bladder]` when the admin
uploaded one; otherwise it falls back to the generated look (cream EVA foam, procedural woven
cotton-poly lining, dark butyl / light latex bladder chosen from the word "latex" in `specs.bladder`).
Labels come from `specs` + the selected material (name, thickness, foam mm) and are admin-editable text.

Layers damp apart along X when toggled; drei `<Html>` labels float next to each shell; hovering a layer
card (in the catalog rail or on the home hero) dims the other layers to 20% so buyers can study one at a
time. The same exploded component powers both `/catalog` and the front-page hero.

### 6.4 Pricing engine (`Configurator.tsx`)
`unit = article.basePrice + material.priceDelta`; volume tiers from `settings.quoteTiers`
(highest tier with `minQty <= qty` wins) apply a percentage discount; price ranges in the article
list are `base + min/max deltas`. Currency is USD, FOB Sialkot (settings has a currency field for
future multi-currency).

### 6.5 Insights engine (`lib/insights.ts`)
Rule-based, computed on demand from the `activity_log` + catalog tables:
most-selected rexines (auto-ranked message), viewed-but-never-quoted articles (pricing risk),
materials missing photos, drafts pending, CorelDRAW files awaiting processing, overdue compliance
reviews. Rules live in `computeInsights()` — add new rules there as the business learns what matters.

### 6.6 Auth
Deliberately minimal: `POST /api/admin/login {password}` → sha256 cookie (`fs_admin_token`, httpOnly,
2 days). All `/api/admin/*`, `/api/upload` routes and the `/admin` page check it. **Replace with real
accounts (NextAuth/Clerk + roles) before exposing the admin publicly — see roadmap.**

---

## 7. Data model (Drizzle, `src/db/schema.ts`)

- **categories** — 7 construction sections (slug used for `/catalog#slug` anchors)
- **articles** — a design: article_no (unique, e.g. FS-TB-3210), category, base_price, moq,
  panel_style + panel_count, colors jsonb `{base, accent, ink}`, featured, status live|draft,
  artwork_url (bitmap wrap), **design_svg_url** (Panel Intelligence map),
  **model_url** (.glb/.gltf/.obj/.stl 3D shape), **model_adjust jsonb** `{rotY, offsetX, offsetY, scale}`
  to align the wrap onto that shape, **render_url** (static 3D picture),
  **seam_style** (auto|hand|machine|bonded|hybrid),
  **layer_images jsonb** `{cover, foam, lining, bladder}` photos for the exploded view,
  **specs jsonb** `{bladder, lining, foamMm, cover?}`, cdr_upload_id
- **materials** — rexines: code, name, finish, description, texture_url (photo), **price_delta**,
  thickness, weight_gsm, is_active, sort_order
- **quotes** — buyer requests: ref FSQ-…, article+material ids, contact, quantity, unit_price,
  total, logo_name, status new|contacted|sampling|closed
- **activity_log** — every tracked buyer event (feeds insights)
- **uploads** — stored files (CorelDRAW sources, admin images) + status pipeline
- **compliance_items** — standards with status + next_review date
- **settings** — key/value jsonb (company, currency, defaultMoq, leadTime, salesEmail, quoteTiers,
  heroPresets, **content** = every public string, seedVersion = dataset revision)

### 7.1 Catalog dataset provenance & migrations

The shipped articles are the **real acquired price list** (seed v2): THERMO BONDED — FLARE (FIFA
Quality Pro 1005140, $26.25/500), BLAZE ($16.47/500), NEO ($10.30/500), FUTSAL MATCH UP ($9.84/500);
HAND STITCH — MUNDIALE ($11.50/500), MATCH ($6.49/500), FUTSAL PRO ($12.00/500), FUTSAL TRAINING
($7.70/500), HAND BALL ($8.67/1000); MACHINE STITCH — HFT ($6.45/1000), RIHNO ($3.85/1000), STRIKER
($3.50/1000), DIGITAL PRINTED ($4.05/1000); plus MINI BALL ($2.90/1000 → AMB/Mini section) and
VOLLEY BALL ($4.15/1000 → Volleyballs section). MOQ and FOB Sialkot prices are shown everywhere
(article rows, price panel, quote modal). `basePrice` is the FOB price *before* the selected rexine
adjustment, exactly as before.

`seed.ts` is versioned (`SEED_VERSION`). On boot, if a database reports an older `settings.seedVersion`,
the old demo articles are deleted and the current dataset is inserted (hero presets included). To ship
a new dataset later: edit `ARTICLE_SEED`, bump `SEED_VERSION`, rebuild — existing installs migrate
themselves. Quotes keep working (their article link is set to null for removed articles).

3D files for these articles arrive separately — attach them per article in Admin → Articles → “3D
shape of this ball” (see §4.0.2).

---

## 8. Gotchas learned the hard way (do not re-break these)

1. `db.execute(sql…)` returns `{ rows: [...] }` in drizzle 0.45 — read `.rows`, not the result itself
   (this bug once made the seeder think the DB was always empty).
2. All DB-touching pages use `export const dynamic = "force-dynamic"` — builds must never hit the DB.
3. Route files may only export handlers + config: don't add helper exports to `src/app/api/**`.
4. Fonts are bundled via @fontsource (no Google Fonts network calls at build time).
5. The 3D viewer is loaded with `next/dynamic … { ssr: false }` — keep it that way (canvas/three are
   browser-only).
6. Texture centre ↔ camera alignment: the ball mesh rotates `y = -π/2` so the logo faces the viewer.
   Don't "fix" that rotation.
7. `instrumentation.ts` must never throw — wrap boot work in try/catch (DB may not be up yet).
8. Uploaded files are served via `/api/files/<storedName>` (never raw fs paths); the route basenames
   the input to prevent traversal.

---

## 9. Roadmap — future changes to make

**Near term (business value, small effort)**
1. **Per-article material overrides** — some rexines cost differently per construction. Add an
   `article_material_prices` table (article_id, material_id, delta) and use it in the price engine
   when present, else fall back to `materials.price_delta`.
2. **Email delivery of quote requests** — currently stored + shown in admin only. Wire Resend/SMTP
   in `POST /api/quote` (send to `settings.salesEmail`, confirmation to buyer).
3. **PDF spec-sheet export** — a "Download spec sheet" button per configuration (react-pdf rendering
   the ball snapshot + article/material/quote details) for buyers to circulate internally.
4. **Admin content polish** — category editing UI already has an API (`/api/admin/categories`);
   add a Categories tab in AdminStudio for completeness.

**Mid term**
5. **Real accounts & roles** — replace the single admin password with email logins + roles
   (Admin, Sales, Designer). NextAuth/Auth.js with the existing Postgres works well.
6. **GLB/GLTF 3D models** — let designers attach true 3D models per article; load with
   `GLTFLoader` in BallViewer and apply the rexine texture to the model's UVs (needs UV-mapped
   exports). Panel Intelligence SVG remains the zero-modelling path.
7. **Automatic CDR handling** — evaluate a licensed CorelDRAW conversion service or a headless
   converter (CDR → SVG) as a worker behind the existing uploads pipeline so designers skip the
   manual SVG export.
8. **Buyer-side accounts** — save configurations, re-order, view quote history.
9. **Multi-currency & Incoterms** — settings already stores a currency code; add PKR/EUR rates and
   FOB/CIF/DDP selectors that adjust the quote payload.
10. **Analytics dashboard v2** — charts (recharts) on the insights data: conversion funnel
    (view → material pick → logo → quote), export CSV for management meetings.

**Hardening**
11. **Tests** — unit tests for pricing + insights (`vitest`), Playwright e2e for the configure→quote
    flow.
12. **CI** — GitHub Actions: typecheck → build → docker build on every push.
13. **Image pipeline** — move admin-uploaded textures through `sharp` (resize to 1024px, WebP) on
    upload to keep the 3D snappy on phones.
14. **Rate limiting + validation** — add rate limits to `/api/quote` and `/api/activity`
    (e.g. upstash/ratelimit) and zod validation on all public endpoints.
15. **Backups** — scheduled `pg_dump` + uploads volume snapshot (cron in compose or host).
16. **Monitoring** — healthcheck is at `/api/health`; add uptime monitoring + error tracking (Sentry).

**Nice to have**
17. AR view (WebXR / model-viewer USDZ for iOS), comparison tray (configure 2 balls side by side),
    print-position editor (drag the logo to different panels), MOQ-aware tier previews, multilingual
    catalog (EN/AR/ES), sample-request flow, integration with an ERP for live stock/lead times.

---

## 10. Troubleshooting

| Symptom | Fix |
|---|---|
| Docker build fails: `"/package-lock.json": not found` | Your project copy lacks the lockfile. Either copy `package-lock.json` from the original project into the folder, or use the current Dockerfile (`COPY package.json package-lock.json*` + `npm install` fallback) which works without it |
| Build hangs then fails: `npm error code ECONNRESET … registry.npmjs.org/next`, and **no containers are created** | Network inside Docker can't reach npm. See §3a-i: use `--build-arg NPM_REGISTRY=https://registry.npmmirror.com`, fix Docker Desktop proxy settings, or run Plan B (app on Windows + Postgres in Docker) |
| Docker log shows `transferring context: 255kB` (should be ≈3.1 MB) | Your copy is incomplete — `public/` (2.4 MB of rexine textures + SVG) is missing. Re-copy the project folder |
| Rexine photos missing in the container | Your copy of `public/textures/` didn't make it across — re-copy the `public/` folder (textures + designs) and `docker compose up --build` again |
| Pages error right after `docker compose up` | Wait for the healthcheck — web starts only after `db` is healthy. Check `docker compose logs web` for `[bootstrap]`/`[seed]` lines |
| Catalog says "No live articles" | Seed didn't run — `curl http://localhost:3000/api/seed`; check DATABASE_URL points at the same DB you're inspecting |
| Admin login rejects the password | `ADMIN_PASSWORD` env changed after cookies were issued — log in again; default is `forward2026` |
| Uploaded CDR/artwork 404s | The `uploads` volume must be mounted at `/app/storage/uploads`; files live there, served by `/api/files/<name>` |
| Texture too subtle / too strong | Tune `GRAIN_TILE` + pass alphas in `applyRexineGrain()` (`src/lib/ballTexture.ts`) and `bumpScale` in `BallViewer.tsx` |
| SVG panel map not detected | Export must contain closed filled shapes (no `fill="none"`), outlines not strokes-as-art; check browser console for the "Panel Intelligence" badge on the viewer |
| Layer photo uploaded but the exploded view still shows the generated look | Refresh the page (the article was edited after load); confirm the photo was saved on that article — Admin → Articles → the article → “Look inside” layer photos shows a thumbnail |
| Uploaded .glb shows the plain generated ball instead | The model failed to load (bad URL/unsupported file) — the viewer falls back silently. Re-upload a .glb (binary glTF); .gltf with external buffers must be a single self-contained file |
| Seams look wrong for a construction (too tight / no thread) | Set the article's **Seam / construction look** (Admin → Articles) instead of leaving it on Auto — see §4.0.3 |
| Front-page hero shows a default ball | Admin → Front page has no samples saved yet, or the chosen article is `draft` / deleted — pick live articles |
| Picking an STL used to crash the tab | Fixed: STLs are now converted server-side to a light UV-mapped GLB at upload (see §4.0.2). If you ever see it again, the file exceeded 25 MB — decimate first |
| STL model loads but the panels don't line up with its seams | Server-normalized STLs get correct UVs automatically; for hand-made GLB/OBJ use the **Align the design** sliders in the article form (rotate model, shift design, scale) with the live preview |
| STL model appears plain grey / untextured | The article has no design source — attach an SVG panel map or set panel style + colours; the model only supplies the shape |
| Uploaded model looks tiny/huge or off-centre | Should not happen (auto-normalised). If it does, the file may contain several distant objects — re-export with the ball only, centred at the origin |
| Logo drag doesn't move | Dragging works on the assembled ball only (not in the exploded view); if a static render is attached instead of a 3D model there is no surface to drag on — upload a .glb/.stl or clear the render |
| 3D area blank on old devices | WebGL requirement — device/browser must support WebGL2; check console for shader errors |
| Changing schema locally | Edit `src/db/schema.ts` **and** mirror the DDL in `src/db/bootstrap.ts`, then `npx drizzle-kit push` (dev) — Docker environments pick up new tables on restart via bootstrap |

---

## 11. Quick reference

- Catalog (one page): `http://<host>:3000/catalog`
- Admin: `http://<host>:3000/admin` (demo password `forward2026`)
- Health: `GET /api/health` · Re-seed: `GET /api/seed`
- Demo article with vector panels: **FS-TB-3210 "Ultra Bond Pro"** (Thermal-Bonded section)
- Brand theme: crimson `#CB0000` on warm paper/charcoal — tokens in `src/app/globals.css`

*Handbook last updated with: one-page catalog, Panel Intelligence (rexine on panels, seams untouched),
exploded interior view with admin layer photos, per-article 3D models / renders, seam & construction
looks, editable front-page hero samples, texture-visibility fix, Docker deployment.*
