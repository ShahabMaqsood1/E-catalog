import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Required for the Docker image (copies a minimal server into the runner stage)
  output: "standalone",
};

export default nextConfig;
