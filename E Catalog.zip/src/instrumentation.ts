export async function register() {
  if (process.env.NEXT_RUNTIME === "nodejs") {
    // 1) Ensure tables exist (idempotent DDL — works in Docker with zero manual steps)
    try {
      const { bootstrapSchema } = await import("@/db/bootstrap");
      await bootstrapSchema();
    } catch (err) {
      console.warn("[bootstrap] skipped:", (err as Error).message?.slice(0, 140));
    }
    // 2) Seed catalog content if empty + enrich missing fields
    try {
      const { ensureSeeded } = await import("@/db/seed");
      await ensureSeeded();
    } catch (err) {
      console.warn("[seed] skipped:", (err as Error).message?.slice(0, 140));
    }
  }
}
