import {
  boolean,
  integer,
  jsonb,
  numeric,
  pgTable,
  serial,
  text,
  timestamp,
} from "drizzle-orm/pg-core";

export type BallColors = { base: string; accent: string; ink: string };

export type BallSpecs = {
  bladder: string;
  lining: string;
  foamMm: number;
  cover?: string;
};

/** Admin-uploaded photos shown on each layer of the exploded "Look inside" view */
export type LayerImages = {
  cover?: string | null;
  foam?: string | null;
  lining?: string | null;
  bladder?: string | null;
};

/** How the panel seams are drawn — mirrors the real construction */
export type SeamStyle = "auto" | "hand" | "machine" | "bonded" | "hybrid";

/** Per-article alignment of the wrap design onto an uploaded 3D model (STL/GLB) */
export type ModelAdjust = {
  rotY: number; // rotate the model around Y, degrees
  offsetX: number; // shift the design horizontally, -0.5..0.5 of the wrap
  offsetY: number; // shift the design vertically, -0.5..0.5
  scale: number; // design size multiplier, 0.5..2
};

export const DEFAULT_MODEL_ADJUST: ModelAdjust = { rotY: 0, offsetX: 0, offsetY: 0, scale: 1 };

/** Where the buyer's logo sits on the wrap (u,v in 0..1, v measured from the top) */
export type LogoTransform = {
  u: number;
  v: number;
  scale: number;
  rotate: number;
  badge: boolean;
};

export const DEFAULT_LOGO_TRANSFORM: LogoTransform = {
  u: 0.5,
  v: 0.5,
  scale: 1,
  rotate: 0,
  badge: true,
};

export type HeroPreset = {
  label: string;
  articleNo: string;
  materialCode: string;
};

export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  name: text("name").notNull(),
  shortName: text("short_name").notNull(),
  tagline: text("tagline").notNull().default(""),
  description: text("description").notNull().default(""),
  iconKey: text("icon_key").notNull().default("ball"),
  sortOrder: integer("sort_order").notNull().default(0),
  isActive: boolean("is_active").notNull().default(true),
});

export const articles = pgTable("articles", {
  id: serial("id").primaryKey(),
  categoryId: integer("category_id")
    .notNull()
    .references(() => categories.id, { onDelete: "cascade" }),
  articleNo: text("article_no").notNull().unique(),
  name: text("name").notNull(),
  description: text("description").notNull().default(""),
  panelStyle: text("panel_style").notNull().default("classic-32"),
  panelCount: integer("panel_count").notNull().default(32),
  basePrice: numeric("base_price", { precision: 10, scale: 2 }).notNull(),
  moq: integer("moq").notNull().default(300),
  colors: jsonb("colors").$type<BallColors>().notNull(),
  featured: boolean("featured").notNull().default(false),
  status: text("status").notNull().default("live"), // live | draft
  artworkUrl: text("artwork_url"), // full-wrap artwork exported from CorelDRAW
  designSvgUrl: text("design_svg_url"), // vector panel map exported from CorelDRAW — auto-detected
  modelUrl: text("model_url"), // uploaded 3D model (.glb / .gltf / .obj / .stl) for this exact ball shape
  modelAdjust: jsonb("model_adjust").$type<ModelAdjust>(), // align the wrap onto that model
  renderUrl: text("render_url"), // static 3D render image fallback
  seamStyle: text("seam_style").notNull().default("auto"), // hand | machine | bonded | hybrid
  layerImages: jsonb("layer_images").$type<LayerImages>(), // photos for the exploded view
  specs: jsonb("specs").$type<BallSpecs>(), // bladder / lining / foam construction
  cdrUploadId: integer("cdr_upload_id"),
  defaultMaterialCode: text("default_material_code"), // per-article rexine default (materials.code)
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const materials = pgTable("materials", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  name: text("name").notNull(),
  finish: text("finish").notNull().default("Gloss PU"),
  description: text("description").notNull().default(""),
  textureUrl: text("texture_url").notNull().default(""),
  priceDelta: numeric("price_delta", { precision: 10, scale: 2 })
    .notNull()
    .default("0"),
  thickness: text("thickness").notNull().default(""),
  weightGsm: integer("weight_gsm"),
  isActive: boolean("is_active").notNull().default(true),
  sortOrder: integer("sort_order").notNull().default(0),
});

export const quotes = pgTable("quotes", {
  id: serial("id").primaryKey(),
  ref: text("ref").notNull().unique(),
  articleId: integer("article_id").references(() => articles.id, {
    onDelete: "set null",
  }),
  materialId: integer("material_id").references(() => materials.id, {
    onDelete: "set null",
  }),
  customerName: text("customer_name").notNull(),
  company: text("company").notNull().default(""),
  email: text("email").notNull(),
  quantity: integer("quantity").notNull(),
  unitPrice: numeric("unit_price", { precision: 10, scale: 2 }).notNull(),
  total: numeric("total", { precision: 12, scale: 2 }).notNull(),
  logoName: text("logo_name"),
  message: text("message").notNull().default(""),
  status: text("status").notNull().default("new"), // new | contacted | sampling | closed
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const activity = pgTable("activity_log", {
  id: serial("id").primaryKey(),
  event: text("event").notNull(),
  refId: text("ref_id"),
  payload: jsonb("payload").$type<Record<string, unknown>>().notNull().default({}),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const uploads = pgTable("uploads", {
  id: serial("id").primaryKey(),
  originalName: text("original_name").notNull(),
  storedName: text("stored_name").notNull().unique(),
  kind: text("kind").notNull().default("file"), // design-file | image
  size: integer("size").notNull().default(0),
  articleId: integer("article_id").references(() => articles.id, {
    onDelete: "set null",
  }),
  status: text("status").notNull().default("received"), // received | in-review | ready | linked
  note: text("note").notNull().default(""),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const compliance = pgTable("compliance_items", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  standard: text("standard").notNull().default(""),
  detail: text("detail").notNull().default(""),
  status: text("status").notNull().default("compliant"), // compliant | in-progress | attention
  nextReview: text("next_review").notNull().default(""),
  sortOrder: integer("sort_order").notNull().default(0),
});

export const settings = pgTable("settings", {
  key: text("key").primaryKey(),
  value: jsonb("value").notNull(),
});
