export type TourStep = {
  target: string; // CSS selector of the anchor element
  title: string;
  body: string;
  placement?: "top" | "bottom" | "left" | "right";
};

export type TourId = "home" | "catalog" | "admin";

export const TOUR_META: Record<TourId, { title: string; intro: string }> = {
  home: {
    title: "Welcome to the Forward E-Catalog",
    intro:
      "A 60-second walkthrough of the interactive catalog — categories, live 3D previews and the admin studio.",
  },
  catalog: {
    title: "Configure a ball",
    intro:
      "One page, every construction. Pick an article, swap rexines, look inside the ball and apply your logo — the price updates live.",
  },
  admin: {
    title: "Admin studio",
    intro:
      "Everything in the catalog is editable here: articles, materials, CorelDRAW files, quotes and compliance.",
  },
};

export const TOURS: Record<TourId, TourStep[]> = {
  home: [
    {
      target: "[data-tour=brand]",
      title: "Forward Sports E-Catalog",
      body: "This is your digital showroom. Everything a buyer needs to configure and request a ball, built around our real construction types.",
      placement: "bottom",
    },
    {
      target: "[data-tour=hero-ball]",
      title: "Live 3D preview",
      body: "Every ball in the catalog renders in real-time 3D. Drag to rotate, scroll to zoom right into the rexine grain.",
      placement: "left",
    },
    {
      target: "[data-tour=categories]",
      title: "Seven construction families",
      body: "Hand-stitched, machine-stitched, thermal-bonded, hybrid, AMB / mini, volleyballs and medicine balls — each with its own section.",
      placement: "top",
    },
    {
      target: "[data-tour=tour-button]",
      title: "Replay any time",
      body: "You can restart this tour from this button on every page. That's it — go impress them!",
      placement: "bottom",
    },
  ],
  catalog: [
    {
      target: "[data-tour=article-list]",
      title: "1 · Every section on one page",
      body: "All seven construction families live on this single page — use the chips above to jump between sections. Click any article to load it in the 3D studio.",
      placement: "right",
    },
    {
      target: "[data-tour=viewer]",
      title: "2 · See it in 3D",
      body: "The selected ball renders instantly. Drag to spin it and scroll to zoom close enough to see the rexine grain. Articles with a vector panel map are auto-detected by Panel Intelligence.",
      placement: "left",
    },
    {
      target: "[data-tour=look-inside]",
      title: "3 · Look inside the ball",
      body: "This opens an exploded view — the rexine cover, impact foam, fabric lining and bladder separate so buyers can see exactly what is inside, with every thickness.",
      placement: "top",
    },
    {
      target: "[data-tour=materials]",
      title: "4 · Pick a rexine",
      body: "Each material has a photo, finish and price adjustment. Click one and the ball re-skins itself — panel by panel on vector designs.",
      placement: "left",
    },
    {
      target: "[data-tour=logo]",
      title: "5 · Apply your logo",
      body: "Buyers drop in their own logo and see it printed on the ball before they ever ask for a sample.",
      placement: "left",
    },
    {
      target: "[data-tour=price]",
      title: "Live price",
      body: "Unit price = article base price + rexine adjustment + volume tier. It recalculates with every choice.",
      placement: "left",
    },
    {
      target: "[data-tour=quote]",
      title: "6 · Request a quote",
      body: "One click packages the whole configuration — article, rexine, logo and quantity — and sends it to your sales inbox.",
      placement: "top",
    },
  ],
  admin: [
    {
      target: "[data-tour=tab-overview]",
      title: "Overview & smart insights",
      body: "The system watches how buyers interact with the catalog and surfaces suggestions — popular rexines, pricing gaps, reviews due.",
      placement: "right",
    },
    {
      target: "[data-tour=tab-articles]",
      title: "Articles",
      body: "Add unlimited designs to any category. Set prices, panel style, interior specs and attach the CorelDRAW vector panel map.",
      placement: "right",
    },
    {
      target: "[data-tour=tab-materials]",
      title: "Rexine materials",
      body: "Upload a photo of each rexine, write its detail and set its price adjustment. Only admins can do this.",
      placement: "right",
    },
    {
      target: "[data-tour=tab-design-files]",
      title: "CorelDRAW files",
      body: "Your designer's .CDR files land here. Export an SVG panel map from CorelDRAW, attach it to the article, and Panel Intelligence applies every selected rexine panel by panel.",
      placement: "right",
    },
    {
      target: "[data-tour=tab-front-page]",
      title: "Front-page samples",
      body: "Choose which articles and rexines appear in the home-page Live 3D hero. Each sample inherits its 3D model, layer photos and interior specs — including Look inside.",
      placement: "right",
    },
    {
      target: "[data-tour=tab-compliance]",
      title: "Compliance radar",
      body: "Keep FIFA Quality, REACH and ISO requirements tracked with review dates so the catalog never falls behind.",
      placement: "right",
    },
  ],
};
