import { db } from "@/db";
import { activity, articles, compliance, materials, quotes, uploads } from "@/db/schema";
import { count, desc, eq, sql } from "drizzle-orm";

export type Insight = {
  level: "good" | "info" | "warn";
  title: string;
  detail: string;
};

export type InsightsPayload = {
  generatedAt: string;
  stats: {
    liveArticles: number;
    draftArticles: number;
    activeMaterials: number;
    newQuotes: number;
    quotePipelineValue: number;
    pendingDesignFiles: number;
    selections7d: number;
    views7d: number;
  };
  insights: Insight[];
  topMaterials: Array<{ id: number; name: string; selections: number }>;
  topArticles: Array<{ id: number; name: string; views: number; quoteCount: number }>;
  compliance: Array<{
    id: number;
    title: string;
    standard: string;
    status: string;
    nextReview: string;
  }>;
};

export async function computeInsights(): Promise<InsightsPayload> {
  const [articleRows, materialRows, quoteRows, uploadRows, complianceRows, recentActivity] =
    await Promise.all([
      db.select().from(articles),
      db.select().from(materials),
      db.select().from(quotes),
      db.select().from(uploads),
      db.select().from(compliance).orderBy(compliance.sortOrder),
      db.select().from(activity).orderBy(desc(activity.createdAt)).limit(400),
    ]);

  const weekAgo = Date.now() - 7 * 24 * 3600 * 1000;
  const recent = recentActivity.filter((a) => new Date(a.createdAt).getTime() >= weekAgo);
  const selections = recent.filter((a) => a.event === "material_select");
  const views = recent.filter((a) => a.event === "article_view");

  const liveArticles = articleRows.filter((a) => a.status === "live");
  const draftArticles = articleRows.length - liveArticles.length;
  const activeMaterials = materialRows.filter((m) => m.isActive);
  const newQuotes = quoteRows.filter((q) => q.status === "new");
  const pipeline = quoteRows.reduce((s, q) => s + Number(q.total), 0);
  const pendingDesignFiles = uploadRows.filter(
    (u) => u.kind === "design-file" && (u.status === "received" || u.status === "in-review")
  );

  const selByMaterial = new Map<number, number>();
  for (const s of selections) {
    const id = Number((s.payload as Record<string, unknown>)?.materialId ?? s.refId);
    if (Number.isFinite(id)) selByMaterial.set(id, (selByMaterial.get(id) ?? 0) + 1);
  }
  const topMaterials = [...selByMaterial.entries()]
    .map(([id, s]) => ({ id, name: materialRows.find((m) => m.id === id)?.name ?? `#${id}`, selections: s }))
    .sort((a, b) => b.selections - a.selections)
    .slice(0, 5);

  const viewsByArticle = new Map<number, number>();
  for (const v of views) {
    const id = Number(v.refId);
    if (Number.isFinite(id)) viewsByArticle.set(id, (viewsByArticle.get(id) ?? 0) + 1);
  }
  const quotesByArticle = new Map<number, number>();
  for (const q of quoteRows) {
    if (q.articleId) quotesByArticle.set(q.articleId, (quotesByArticle.get(q.articleId) ?? 0) + 1);
  }
  const topArticles = [...viewsByArticle.entries()]
    .map(([id, v]) => ({
      id,
      name: articleRows.find((a) => a.id === id)?.name ?? `#${id}`,
      views: v,
      quoteCount: quotesByArticle.get(id) ?? 0,
    }))
    .sort((a, b) => b.views - a.views)
    .slice(0, 5);

  const insights: Insight[] = [];

  if (topMaterials[0]) {
    insights.push({
      level: "good",
      title: `"${topMaterials[0].name}" is the most selected rexine`,
      detail: `${topMaterials[0].selections} selections in the last 7 days. The engine has ranked it first in material pickers automatically. Consider negotiating volume pricing with the supplier.`,
    });
  }

  const viewedNoQuote = topArticles.find((a) => a.views >= 3 && a.quoteCount === 0);
  if (viewedNoQuote) {
    insights.push({
      level: "warn",
      title: `"${viewedNoQuote.name}" is viewed but never quoted`,
      detail: `${viewedNoQuote.views} views and 0 quote requests this week. The pattern suggests the base price or MOQ may be scaring buyers — review the pricing for this article.`,
    });
  }

  const imageless = activeMaterials.filter((m) => !m.textureUrl);
  if (imageless.length > 0) {
    insights.push({
      level: "warn",
      title: `${imageless.length} material${imageless.length > 1 ? "s are" : " is"} missing a texture photo`,
      detail: `Buyers pick materials visually. Upload a close-up photo for: ${imageless
        .map((m) => m.name)
        .join(", ")}.`,
    });
  }

  if (draftArticles > 0) {
    insights.push({
      level: "info",
      title: `${draftArticles} article${draftArticles > 1 ? "s" : ""} still in draft`,
      detail: "Draft articles are hidden from buyers. Publish them from the Articles tab when the design team signs off.",
    });
  }

  if (pendingDesignFiles.length > 0) {
    insights.push({
      level: "info",
      title: `${pendingDesignFiles.length} CorelDRAW file${pendingDesignFiles.length > 1 ? "s" : ""} awaiting processing`,
      detail: "Move each .CDR through review, export the 2:1 wrap artwork and attach it to the matching article to enable its 3D view.",
    });
  }

  const overdue = complianceRows.filter((c) => {
    if (!c.nextReview || c.status === "compliant") return false;
    return c.nextReview <= new Date().toISOString().slice(0, 10);
  });
  if (overdue.length > 0) {
    insights.push({
      level: "warn",
      title: `Compliance review due: ${overdue[0].title}`,
      detail: `${overdue.length} standard${overdue.length > 1 ? "s need" : " needs"} attention. The catalog footer only displays standards marked compliant.`,
    });
  } else if (complianceRows.length > 0) {
    insights.push({
      level: "good",
      title: "Compliance radar is green",
      detail: "All tracked standards (FIFA Quality, REACH, ISO 9001…) are within their review windows. The system re-checks dates daily.",
    });
  }

  insights.push({
    level: "info",
    title: "Self-tuning is active",
    detail: `The engine analysed ${recentActivity.length} recent events. Material order, featured suggestions and these recommendations update automatically from buyer behaviour — no manual reporting needed.`,
  });

  return {
    generatedAt: new Date().toISOString(),
    stats: {
      liveArticles: liveArticles.length,
      draftArticles,
      activeMaterials: activeMaterials.length,
      newQuotes: newQuotes.length,
      quotePipelineValue: pipeline,
      pendingDesignFiles: pendingDesignFiles.length,
      selections7d: selections.length,
      views7d: views.length,
    },
    insights,
    topMaterials,
    topArticles,
    compliance: complianceRows.map((c) => ({
      id: c.id,
      title: c.title,
      standard: c.standard,
      status: c.status,
      nextReview: c.nextReview,
    })),
  };
}

export async function recentFeed(limit = 14) {
  return db.select().from(activity).orderBy(desc(activity.createdAt)).limit(limit);
}

export async function tableCount(table: Parameters<typeof count>[0] extends never ? never : any) {
  const rows = await db.select({ n: count() }).from(table);
  return Number(rows[0]?.n ?? 0);
}

export { sql };
