import { db } from "@/db";
import { settings } from "@/db/schema";
import { eq } from "drizzle-orm";
import { CONTENT_SCHEMA, DEFAULT_CONTENT } from "./content-schema";

export { CONTENT_SCHEMA, DEFAULT_CONTENT };
export type { ContentField } from "./content-schema";

/**
 * Loads the public-site copy from `settings.content`, merged over the built-in
 * defaults. Server-only (touches the DB) — client components must import from
 * `@/lib/content-schema` instead.
 */
export async function getContent(): Promise<Record<string, string>> {
  try {
    const row = await db.query.settings.findFirst({ where: eq(settings.key, "content") });
    const saved = (row?.value ?? {}) as Record<string, unknown>;
    const out: Record<string, string> = { ...DEFAULT_CONTENT };
    for (const f of CONTENT_SCHEMA) {
      const v = saved[f.key];
      if (typeof v === "string") out[f.key] = v;
    }
    return out;
  } catch {
    return { ...DEFAULT_CONTENT };
  }
}
