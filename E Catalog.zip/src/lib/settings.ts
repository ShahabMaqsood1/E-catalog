import { db } from "@/db";
import { settings } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function getSetting<T>(key: string, fallback: T): Promise<T> {
  try {
    const row = await db.query.settings.findFirst({ where: eq(settings.key, key) });
    return row ? (row.value as T) : fallback;
  } catch {
    return fallback;
  }
}

export const DEFAULT_TIERS = [
  { minQty: 500, discountPct: 4 },
  { minQty: 1000, discountPct: 7 },
  { minQty: 5000, discountPct: 10 },
];
