import {
  DEFAULT_LOGO_TRANSFORM,
  type BallColors,
  type LogoTransform,
  type SeamStyle,
} from "@/db/schema";
import { loadSvgPanels } from "@/lib/svgPanels";

export type PanelStyle =
  | "classic-32"
  | "geo-24"
  | "vortex-18"
  | "stripe-14"
  | "volley-18"
  | "mini-star"
  | "medicine";

export const PANEL_STYLES: Array<{ key: PanelStyle; label: string }> = [
  { key: "classic-32", label: "Classic 32-panel hex / pent" },
  { key: "geo-24", label: "Geo 24-panel wave" },
  { key: "vortex-18", label: "Vortex 18-panel swirl" },
  { key: "stripe-14", label: "Stripe 14-panel diagonal" },
  { key: "volley-18", label: "Volleyball 18-panel arcs" },
  { key: "mini-star", label: "Mini / promo star splash" },
  { key: "medicine", label: "Medicine ball bands" },
];

export const SEAM_STYLES: Array<{ key: SeamStyle; label: string }> = [
  { key: "auto", label: "Auto (use construction default)" },
  { key: "hand", label: "Hand-stitched — open seam channel + waxed thread" },
  { key: "machine", label: "Machine-stitched — tight lock stitch" },
  { key: "bonded", label: "Thermal bonded — seamless groove" },
  { key: "hybrid", label: "Hybrid — bonded channel + stitch points" },
];

export type BallTextureMeta = {
  mode: "svg" | "artwork" | "procedural";
  panels?: number;
  seamStyle: SeamStyle;
};

export type BallTextureOptions = {
  panelStyle: PanelStyle | string;
  colors: BallColors;
  rexineUrl?: string | null;
  artworkUrl?: string | null;
  designSvgUrl?: string | null;
  logoUrl?: string | null;
  /** buyer-controlled logo placement: position on the wrap, size, rotation, badge */
  logo?: LogoTransform | null;
  label?: string;
  seamStyle?: SeamStyle | string | null;
  /** map width in px (height = half). Use 512 for list thumbnails, 2048 for the 3D viewer. */
  res?: number;
  onMeta?: (meta: BallTextureMeta) => void;
};

/** All painters work in this virtual coordinate space; the output canvas is
 *  scaled to `res` with a transform so thumbnails cost a fraction of the memory. */
const W = 2048;
const H = 1024;

/* Shared cache so repeated thumbnails never repaint (and never re-allocate). */
const canvasCache = new Map<string, HTMLCanvasElement>();
const CACHE_MAX = 24;

function cacheKey(o: BallTextureOptions): string {
  return JSON.stringify([
    o.panelStyle,
    o.colors,
    o.rexineUrl ?? "",
    o.artworkUrl ?? "",
    o.designSvgUrl ?? "",
    o.logoUrl ? `${String(o.logoUrl).length}:${String(o.logoUrl).slice(-24)}` : "",
    o.logo ?? null,
    o.label ?? "",
    o.seamStyle ?? "",
    o.res ?? 2048,
  ]);
}

/** Size (in map pixels) of one rexine grain tile — small tiles keep the
 *  pebble / weave pattern clearly visible on the finished ball. */
const GRAIN_TILE = 230;

/* ------------------------------------------------------------------ *
 * A design is always reduced to a PANEL SET: closed shapes + colours.
 * The painter then fills each panel with the selected rexine and draws
 * the seams on top — so seams are never covered by texture.
 * ------------------------------------------------------------------ */

export type Panel = { path: Path2D; fill: string };
type PanelSet = { panels: Panel[]; decor?: (ctx: CanvasRenderingContext2D) => void };

function poly(points: Array<[number, number]>): Path2D {
  const d = points
    .map(([x, y], i) => `${i === 0 ? "M" : "L"} ${x.toFixed(1)} ${y.toFixed(1)}`)
    .join(" ");
  return new Path2D(`${d} Z`);
}

function transformed(path: Path2D, matrix: DOMMatrix): Path2D {
  const out = new Path2D();
  out.addPath(path, matrix);
  return out;
}

/* ---------------- procedural panel generators ---------------- */

function genClassic32(c: BallColors): PanelSet {
  const panels: Panel[] = [];
  const r = W / 16;
  const hstep = r * 1.74;
  const vstep = r * 1.5;
  let row = 0;
  for (let y = -vstep; y < H + vstep; y += vstep, row++) {
    const off = row % 2 === 0 ? 0 : hstep / 2;
    let col = 0;
    for (let x = -hstep + off; x < W + hstep; x += hstep, col++) {
      const isPent = (row + col * 2) % 5 === 0;
      const n = isPent ? 5 : 6;
      const rad = isPent ? r * 0.92 : r;
      const pts: Array<[number, number]> = [];
      for (let i = 0; i < n; i++) {
        const a = isPent ? ((Math.PI * 2) / 5) * i - Math.PI / 2 : (Math.PI / 3) * i + Math.PI / 6;
        pts.push([x + rad * Math.cos(a), y + rad * Math.sin(a)]);
      }
      panels.push({ path: poly(pts), fill: isPent ? c.accent : c.base });
    }
  }
  return { panels };
}

function genGeo24(c: BallColors): PanelSet {
  const panels: Panel[] = [];
  const bands = 6;
  const bw = W / bands;
  for (let i = 0; i < bands; i++) {
    const x0 = i * bw;
    const pts: Array<[number, number]> = [];
    for (let y = 0; y <= H; y += 32) pts.push([x0 + Math.sin(y / 130 + i * 1.7) * 70, y]);
    for (let y = H; y >= 0; y -= 32) pts.push([x0 + bw + Math.sin(y / 130 + i * 1.7) * 70, y]);
    panels.push({ path: poly(pts), fill: i % 2 === 1 ? c.accent : c.base });
  }
  return {
    panels,
    decor: (ctx) => {
      ctx.fillStyle = c.ink;
      ctx.globalAlpha = 0.85;
      ctx.fillRect(0, H / 2 - 22, W, 44);
      ctx.globalAlpha = 1;
    },
  };
}

function genVortex18(c: BallColors): PanelSet {
  const panels: Panel[] = [];
  const swirls = 5;
  for (let s = 0; s < swirls; s++) {
    const yBase = (H / swirls) * s + H / swirls / 2;
    const pts: Array<[number, number]> = [];
    for (let x = 0; x <= W; x += 24) pts.push([x, yBase + Math.sin(x / 190 + s * 2.1) * 95]);
    for (let x = W; x >= 0; x -= 24) {
      pts.push([x, yBase + Math.sin(x / 190 + s * 2.1) * 95 + 96]);
    }
    panels.push({ path: poly(pts), fill: s % 2 === 0 ? c.accent : c.base });
  }
  return { panels };
}

function genStripe14(c: BallColors): PanelSet {
  const panels: Panel[] = [];
  const sw = 170;
  const m = new DOMMatrix()
    .translateSelf(W / 2, H / 2)
    .rotateSelf(-180 / 7)
    .translateSelf(-W / 2, -H / 2);
  let i = 0;
  for (let x = -W; x < W; x += sw * 2, i++) {
    const rect = new Path2D(`M ${x} ${-H} h ${sw} v ${H * 2} h ${-sw} Z`);
    panels.push({ path: transformed(rect, m), fill: i % 2 === 0 ? c.accent : c.base });
  }
  return { panels };
}

function genVolley18(c: BallColors): PanelSet {
  const panels: Panel[] = [];
  const rows = 3;
  const cw = W / 6;
  const rh = H / rows;
  for (let r0 = 0; r0 < rows; r0++) {
    for (let ci = 0; ci < 6; ci++) {
      const x0 = ci * cw;
      const y0 = r0 * rh;
      const d =
        `M ${x0} ${y0} Q ${x0 + cw / 2} ${y0 + rh * 0.28} ${x0 + cw} ${y0} ` +
        `L ${x0 + cw} ${y0 + rh} Q ${x0 + cw / 2} ${y0 + rh * 1.28} ${x0} ${y0 + rh} Z`;
      const mod = (r0 + ci) % 3;
      panels.push({ path: new Path2D(d), fill: mod === 0 ? c.accent : mod === 1 ? c.base : c.ink });
    }
  }
  return { panels };
}

function genMiniStar(c: BallColors): PanelSet {
  const panels: Panel[] = [];
  const spots: Array<[number, number, number]> = [
    [260, 220, 150],
    [820, 640, 190],
    [1420, 260, 160],
    [1800, 720, 140],
    [1100, 150, 110],
    [420, 820, 120],
    [1650, 140, 100],
  ];
  spots.forEach(([x, y, r], i) => {
    const pts: Array<[number, number]> = [];
    for (let k = 0; k < 10; k++) {
      const rad = k % 2 === 0 ? r : r * 0.45;
      const a = (Math.PI / 5) * k - Math.PI / 2;
      pts.push([x + rad * Math.cos(a), y + rad * Math.sin(a)]);
    }
    panels.push({ path: poly(pts), fill: i % 2 === 0 ? c.accent : c.ink });
  });
  for (let i = 0; i < 26; i++) {
    const x = (i * 733) % W;
    const y = (i * 391) % H;
    panels.push({ path: new Path2D(`M ${x - 14} ${y} a 14 14 0 1 0 28 0 a 14 14 0 1 0 -28 0 Z`), fill: c.accent });
  }
  // base field so the rexine covers the whole ball, stars sit on top
  return { panels: [{ path: new Path2D(`M 0 0 h ${W} v ${H} h ${-W} Z`), fill: c.base }, ...panels] };
}

function genMedicine(c: BallColors, label?: string): PanelSet {
  const panels: Panel[] = [
    { path: new Path2D(`M 0 0 h ${W} v ${H} h ${-W} Z`), fill: c.base },
    { path: new Path2D(`M 0 ${H * 0.12} h ${W} v ${H * 0.1} h ${-W} Z`), fill: c.accent },
    { path: new Path2D(`M 0 ${H * 0.78} h ${W} v ${H * 0.1} h ${-W} Z`), fill: c.accent },
  ];
  return {
    panels,
    decor: (ctx) => {
      ctx.fillStyle = c.ink;
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.font = "900 230px 'Archivo Variable', 'Arial Black', sans-serif";
      ctx.fillText(label || "FW", W / 2, H / 2);
      ctx.font = "700 74px 'Manrope Variable', sans-serif";
      ctx.fillText("FORWARD MEDICINE", W / 2, H / 2 + 165);
    },
  };
}

function generatePanels(panelStyle: string, c: BallColors, label?: string): PanelSet {
  switch (panelStyle) {
    case "geo-24":
      return genGeo24(c);
    case "vortex-18":
      return genVortex18(c);
    case "stripe-14":
      return genStripe14(c);
    case "volley-18":
      return genVolley18(c);
    case "mini-star":
      return genMiniStar(c);
    case "medicine":
      return genMedicine(c, label);
    default:
      return genClassic32(c);
  }
}

/* ---------------- rexine grain ---------------- */

function makeGrainPattern(
  ctx: CanvasRenderingContext2D,
  img: HTMLImageElement,
  tileScale = 1
): CanvasPattern | null {
  const pat = ctx.createPattern(img, "repeat");
  if (!pat) return null;
  if (typeof DOMMatrix !== "undefined") {
    pat.setTransform(
      new DOMMatrix().scale(
        (GRAIN_TILE * tileScale) / img.width,
        (GRAIN_TILE * tileScale) / img.height
      )
    );
  }
  return pat;
}

/** Three-pass grain so the material reads clearly: relief, tone, sheen. */
function stampGrain(
  ctx: CanvasRenderingContext2D,
  pat: CanvasPattern,
  w: number,
  h: number
) {
  const fill = () => ctx.fillRect(0, 0, w, h);
  ctx.save();
  ctx.globalCompositeOperation = "overlay";
  ctx.globalAlpha = 0.95;
  ctx.fillStyle = pat;
  fill();
  ctx.restore();
  ctx.save();
  ctx.globalCompositeOperation = "multiply";
  ctx.globalAlpha = 0.4;
  ctx.fillStyle = pat;
  fill();
  ctx.restore();
  ctx.save();
  ctx.globalCompositeOperation = "soft-light";
  ctx.globalAlpha = 0.55;
  ctx.fillStyle = pat;
  fill();
  ctx.restore();
}

/* ---------------- seam rendering (drawn LAST, never textured over) ------- */

type SeamSpec = {
  channel: number;
  channelColor: string;
  stitch: number;
  stitchColor: string;
  dash: number[];
  highlight?: number;
};

function seamSpecFor(style: SeamStyle, c: BallColors): SeamSpec {
  switch (style) {
    case "hand":
      return {
        // hand-stitched: an open channel with visible waxed thread — the "little space"
        channel: 30,
        channelColor: c.ink,
        stitch: 7,
        stitchColor: "#efe7d4",
        dash: [30, 20],
      };
    case "bonded":
      return {
        // thermal bonded: hairline fused groove, no thread
        channel: 7,
        channelColor: "rgba(0,0,0,0.55)",
        stitch: 2,
        stitchColor: "rgba(255,255,255,0.22)",
        dash: [],
      };
    case "hybrid":
      return {
        channel: 20,
        channelColor: c.ink,
        stitch: 5,
        stitchColor: "rgba(240,232,214,0.9)",
        dash: [46, 34],
      };
    case "machine":
    default:
      return {
        channel: 14,
        channelColor: c.ink,
        stitch: 4.5,
        stitchColor: "rgba(255,255,255,0.78)",
        dash: [13, 11],
      };
  }
}

function drawSeams(ctx: CanvasRenderingContext2D, panels: Panel[], spec: SeamSpec) {
  ctx.save();
  ctx.lineJoin = "round";
  ctx.lineCap = "round";
  // 1) seam channel
  ctx.setLineDash([]);
  ctx.lineWidth = spec.channel;
  ctx.strokeStyle = spec.channelColor;
  for (const p of panels) ctx.stroke(p.path);
  // 2) thread / groove highlight
  ctx.lineWidth = spec.stitch;
  ctx.strokeStyle = spec.stitchColor;
  if (spec.dash.length) ctx.setLineDash(spec.dash);
  for (const p of panels) ctx.stroke(p.path);
  ctx.restore();
}

/* ---------------- the unified painter ---------------- */

function paintPanelSet(
  ctx: CanvasRenderingContext2D,
  set: PanelSet,
  rexineImg: HTMLImageElement | null,
  c: BallColors,
  seamStyle: SeamStyle
) {
  // seam background — what shows through the channels between panels
  ctx.fillStyle = c.ink;
  ctx.fillRect(0, 0, W, H);

  const grain = rexineImg ? makeGrainPattern(ctx, rexineImg) : null;

  for (const { path, fill } of set.panels) {
    ctx.save();
    ctx.clip(path);
    if (grain) {
      // the selected rexine, tiled densely, ONLY inside this panel
      ctx.fillStyle = grain;
      ctx.fillRect(0, 0, W, H);
      stampGrain(ctx, grain, W, H);
    } else {
      ctx.fillStyle = c.base;
      ctx.fillRect(0, 0, W, H);
    }
    // keep the designer's colour blocking recognisable
    const isNeutral = !fill || fill === "none" || /^#f{3,6}$/i.test(fill) || fill.toLowerCase() === "white";
    if (!isNeutral) {
      ctx.globalCompositeOperation = "multiply";
      ctx.globalAlpha = 0.55;
      ctx.fillStyle = fill;
      ctx.fillRect(0, 0, W, H);
      ctx.globalAlpha = 1;
      ctx.globalCompositeOperation = "source-over";
    }
    ctx.restore();
  }

  // seams on top — untouched by the rexine
  drawSeams(ctx, set.panels, seamSpecFor(seamStyle, c));

  set.decor?.(ctx);
}

/* ---------------- helpers ---------------- */

function loadImage(src: string): Promise<HTMLImageElement | null> {
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => resolve(null);
    img.src = src;
  });
}

function resolveSeam(style: string | null | undefined, panelStyle: string): SeamStyle {
  if (style && style !== "auto") return style as SeamStyle;
  if (panelStyle === "volley-18" || panelStyle === "medicine" || panelStyle === "mini-star") {
    return "bonded";
  }
  return "machine";
}

/* ---------------- composer ---------------- */

export async function buildBallCanvas(opts: BallTextureOptions): Promise<HTMLCanvasElement> {
  const key = cacheKey(opts);
  const hit = canvasCache.get(key);
  if (hit) return hit;

  const res = Math.max(256, Math.min(2048, opts.res ?? 2048));
  const canvas = document.createElement("canvas");
  canvas.width = res;
  canvas.height = res / 2;
  const ctx = canvas.getContext("2d");
  if (!ctx) return canvas;
  // paint in the virtual 2048×1024 space, output at `res`
  ctx.setTransform(res / W, 0, 0, res / W, 0, 0);

  const c = opts.colors;
  const seamStyle = resolveSeam(opts.seamStyle, String(opts.panelStyle));
  const [rexineImg, artworkImg, logoImg] = await Promise.all([
    opts.rexineUrl ? loadImage(opts.rexineUrl) : Promise.resolve(null),
    opts.artworkUrl ? loadImage(opts.artworkUrl) : Promise.resolve(null),
    opts.logoUrl ? loadImage(opts.logoUrl) : Promise.resolve(null),
  ]);

  let meta: BallTextureMeta = { mode: "procedural", seamStyle };

  const svgParsed = opts.designSvgUrl ? await loadSvgPanels(opts.designSvgUrl) : null;

  if (svgParsed) {
    // Panel Intelligence: designer's vector map, scaled to the wrap
    const sx = W / svgParsed.vw;
    const sy = H / svgParsed.vh;
    const m = new DOMMatrix().scaleSelf(sx, sy);
    const panels = svgParsed.paths.map((p) => ({
      path: transformed(p.path, m),
      fill: p.fill,
    }));
    paintPanelSet(ctx, { panels }, rexineImg, c, seamStyle);
    meta = { mode: "svg", panels: svgParsed.count, seamStyle };
  } else if (artworkImg) {
    // flat bitmap wrap exported from CorelDRAW — rexine pressed over the whole thing
    ctx.drawImage(artworkImg, 0, 0, W, H);
    if (rexineImg) {
      const grain = makeGrainPattern(ctx, rexineImg);
      if (grain) stampGrain(ctx, grain, W, H);
    }
    meta = { mode: "artwork", seamStyle };
  } else {
    paintPanelSet(ctx, generatePanels(String(opts.panelStyle), c, opts.label), rexineImg, c, seamStyle);
  }

  // soft pole shading for a rounder read on the flat map
  const grad = ctx.createLinearGradient(0, 0, 0, H);
  grad.addColorStop(0, "rgba(0,0,0,0.22)");
  grad.addColorStop(0.28, "rgba(0,0,0,0)");
  grad.addColorStop(0.72, "rgba(0,0,0,0)");
  grad.addColorStop(1, "rgba(0,0,0,0.22)");
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, W, H);

  // customer logo — placed wherever the buyer dragged it (u,v on the wrap)
  if (logoImg) {
    const t: LogoTransform = { ...DEFAULT_LOGO_TRANSFORM, ...(opts.logo ?? {}) };
    const boxW = 460 * Math.max(0.2, t.scale);
    const boxH = 320 * Math.max(0.2, t.scale);
    const fit = Math.min(boxW / logoImg.width, boxH / logoImg.height);
    const lw = logoImg.width * fit;
    const lh = logoImg.height * fit;
    const cy = Math.min(H - 40, Math.max(40, t.v * H));
    const rot = (t.rotate * Math.PI) / 180;

    // draw at x, x-W and x+W so a logo near the wrap edge is not cut in half
    for (const cx of [t.u * W, t.u * W - W, t.u * W + W]) {
      if (cx < -boxW || cx > W + boxW) continue;
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(rot);
      if (t.badge) {
        const pad = 30 * Math.max(0.4, t.scale);
        ctx.shadowColor = "rgba(0,0,0,0.35)";
        ctx.shadowBlur = 22;
        ctx.fillStyle = "rgba(255,255,255,0.96)";
        ctx.beginPath();
        ctx.roundRect(-lw / 2 - pad, -lh / 2 - pad, lw + pad * 2, lh + pad * 2, 30);
        ctx.fill();
        ctx.shadowBlur = 0;
      } else {
        // subtle outline so light logos stay visible on light rexine
        ctx.shadowColor = "rgba(0,0,0,0.45)";
        ctx.shadowBlur = 14;
      }
      ctx.drawImage(logoImg, -lw / 2, -lh / 2, lw, lh);
      ctx.restore();
    }
  }

  opts.onMeta?.(meta);

  canvasCache.set(key, canvas);
  if (canvasCache.size > CACHE_MAX) {
    const oldest = canvasCache.keys().next().value;
    if (oldest !== undefined) canvasCache.delete(oldest);
  }
  return canvas;
}
