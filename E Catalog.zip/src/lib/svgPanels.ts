/**
 * Panel Intelligence — parses a vector panel map (SVG export from CorelDRAW)
 * and extracts every closed panel shape so the selected rexine can be applied
 * panel-by-panel on the 3D ball.
 */

export type ParsedPanels = {
  paths: Array<{ path: Path2D; fill: string }>;
  vw: number;
  vh: number;
  count: number;
};

const cache = new Map<string, Promise<ParsedPanels | null>>();

function elementToPathData(el: Element): string | null {
  const tag = el.tagName.toLowerCase();
  switch (tag) {
    case "path":
      return el.getAttribute("d");
    case "polygon":
    case "polyline": {
      const pts = el.getAttribute("points");
      if (!pts) return null;
      return `M ${pts.trim()} ${tag === "polygon" ? "Z" : ""}`;
    }
    case "rect": {
      const x = parseFloat(el.getAttribute("x") ?? "0");
      const y = parseFloat(el.getAttribute("y") ?? "0");
      const w = parseFloat(el.getAttribute("width") ?? "0");
      const h = parseFloat(el.getAttribute("height") ?? "0");
      if (!w || !h) return null;
      return `M ${x} ${y} h ${w} v ${h} h ${-w} Z`;
    }
    case "circle": {
      const cx = parseFloat(el.getAttribute("cx") ?? "0");
      const cy = parseFloat(el.getAttribute("cy") ?? "0");
      const r = parseFloat(el.getAttribute("r") ?? "0");
      if (!r) return null;
      return `M ${cx - r} ${cy} a ${r} ${r} 0 1 0 ${r * 2} 0 a ${r} ${r} 0 1 0 ${-r * 2} 0 Z`;
    }
    case "ellipse": {
      const cx = parseFloat(el.getAttribute("cx") ?? "0");
      const cy = parseFloat(el.getAttribute("cy") ?? "0");
      const rx = parseFloat(el.getAttribute("rx") ?? "0");
      const ry = parseFloat(el.getAttribute("ry") ?? "0");
      if (!rx || !ry) return null;
      return `M ${cx - rx} ${cy} a ${rx} ${ry} 0 1 0 ${rx * 2} 0 a ${rx} ${ry} 0 1 0 ${-rx * 2} 0 Z`;
    }
    default:
      return null;
  }
}

function parseSvgText(text: string): ParsedPanels | null {
  try {
    const doc = new DOMParser().parseFromString(text, "image/svg+xml");
    const svg = doc.querySelector("svg");
    if (!svg || doc.querySelector("parsererror")) return null;

    let vw = 0;
    let vh = 0;
    const vb = svg.getAttribute("viewBox");
    if (vb) {
      const parts = vb.trim().split(/[\s,]+/).map(Number);
      if (parts.length === 4) {
        vw = parts[2];
        vh = parts[3];
      }
    }
    if (!vw || !vh) {
      vw = parseFloat(svg.getAttribute("width") ?? "") || 2048;
      vh = parseFloat(svg.getAttribute("height") ?? "") || 1024;
    }

    const shapes: ParsedPanels["paths"] = [];
    const elements = svg.querySelectorAll("path, polygon, polyline, rect, circle, ellipse");
    for (const el of Array.from(elements)) {
      if (shapes.length >= 400) break;
      if (el.getAttribute("display") === "none") continue;
      const fill = el.getAttribute("fill") ?? "#ffffff";
      if (fill === "none") continue; // outline-only art is not a panel
      const d = elementToPathData(el);
      if (!d) continue;
      try {
        shapes.push({ path: new Path2D(d), fill });
      } catch {
        /* malformed path — skip */
      }
    }
    if (shapes.length === 0) return null;
    return { paths: shapes, vw, vh, count: shapes.length };
  } catch {
    return null;
  }
}

export function loadSvgPanels(url: string): Promise<ParsedPanels | null> {
  if (!cache.has(url)) {
    cache.set(
      url,
      (async () => {
        try {
          const res = await fetch(url);
          if (!res.ok) return null;
          const text = await res.text();
          return parseSvgText(text);
        } catch {
          return null;
        }
      })()
    );
  }
  return cache.get(url)!;
}
