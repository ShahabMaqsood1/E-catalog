import { readFile, writeFile } from "node:fs/promises";

/**
 * Server-side STL → GLB normalizer.
 *
 * Raw CAD/scan STLs are far too heavy for a browser (hundreds of thousands to
 * millions of triangles; ASCII STLs double in size as JS strings). This module
 * parses the STL ON THE SERVER, welds/decimates it to a light mesh (~20–30k
 * triangles), bakes the equirectangular UVs the web viewer expects (with the
 * back-seam duplication fix), and writes a self-contained binary .glb with no
 * materials. The browser then only ever loads the small GLB — no crashes.
 */

const TARGET_VERTS = 14000; // ≈ 28k triangles after welding — plenty for a ball
const MAX_TRIS = 6_000_000; // refuse pathological inputs

export type NormalizeResult = { triangles: number; vertices: number };

/* ---------------- parsing ---------------- */

function parseBinary(buf: Buffer): Float32Array | null {
  const count = buf.readUInt32LE(80);
  if (count === 0 || count > MAX_TRIS) return null;
  if (buf.length < 84 + count * 50) return null;
  const out = new Float32Array(count * 9);
  for (let i = 0; i < count; i++) {
    const off = 84 + i * 50 + 12; // skip normal
    for (let v = 0; v < 3; v++) {
      out[i * 9 + v * 3 + 0] = buf.readFloatLE(off + v * 12 + 0);
      out[i * 9 + v * 3 + 1] = buf.readFloatLE(off + v * 12 + 4);
      out[i * 9 + v * 3 + 2] = buf.readFloatLE(off + v * 12 + 8);
    }
  }
  return out;
}

function parseAscii(text: string): Float32Array | null {
  const nums: number[] = [];
  const re = /vertex[ \t]+(-?[\d.]+(?:[eE][+-]?\d+)?)[ \t]+(-?[\d.]+(?:[eE][+-]?\d+)?)[ \t]+(-?[\d.]+(?:[eE][+-]?\d+)?)/gi;
  let m: RegExpExecArray | null;
  while ((m = re.exec(text)) !== null) {
    nums.push(Number(m[1]), Number(m[2]), Number(m[3]));
    if (nums.length / 9 > MAX_TRIS) return null;
  }
  if (nums.length < 9) return null;
  return Float32Array.from(nums);
}

/* ---------------- GLB writing ---------------- */

function pad4(n: number) {
  return (n + 3) & ~3;
}

function writeGlb(
  dst: string,
  pos: Float32Array,
  nrm: Float32Array,
  uv: Float32Array,
  idx: Uint32Array,
  min: [number, number, number],
  max: [number, number, number]
): Promise<void> {
  const posB = Buffer.from(pos.buffer, pos.byteOffset, pos.byteLength);
  const nrmB = Buffer.from(nrm.buffer, nrm.byteOffset, nrm.byteLength);
  const uvB = Buffer.from(uv.buffer, uv.byteOffset, uv.byteLength);
  const idxB = Buffer.from(idx.buffer, idx.byteOffset, idx.byteLength);

  const oPos = 0;
  const oNrm = pad4(oPos + posB.length);
  const oUv = pad4(oNrm + nrmB.length);
  const oIdx = pad4(oUv + uvB.length);
  const binLen = pad4(oIdx + idxB.length);

  const json = {
    asset: { version: "2.0", generator: "forward-ecatalog-stl-normalizer" },
    scene: 0,
    scenes: [{ nodes: [0] }],
    nodes: [{ mesh: 0, name: "ball" }],
    meshes: [
      {
        name: "ball",
        primitives: [{ attributes: { POSITION: 0, NORMAL: 1, TEXCOORD_0: 2 }, indices: 3, mode: 4 }],
      },
    ],
    buffers: [{ byteLength: binLen }],
    bufferViews: [
      { buffer: 0, byteOffset: oPos, byteLength: posB.length },
      { buffer: 0, byteOffset: oNrm, byteLength: nrmB.length },
      { buffer: 0, byteOffset: oUv, byteLength: uvB.length },
      { buffer: 0, byteOffset: oIdx, byteLength: idxB.length },
    ],
    accessors: [
      { bufferView: 0, componentType: 5126, count: pos.length / 3, type: "VEC3", min, max },
      { bufferView: 1, componentType: 5126, count: nrm.length / 3, type: "VEC3" },
      { bufferView: 2, componentType: 5126, count: uv.length / 2, type: "VEC2" },
      { bufferView: 3, componentType: 5125, count: idx.length, type: "SCALAR" },
    ],
  };

  let jsonB = Buffer.from(JSON.stringify(json), "utf8");
  const jsonPad = pad4(jsonB.length) - jsonB.length;
  if (jsonPad) jsonB = Buffer.concat([jsonB, Buffer.alloc(jsonPad, 0x20)]);
  const binPad = binLen - idxB.length - (oIdx - pad4(oUv + uvB.length) === 0 ? 0 : 0);
  const bin = Buffer.alloc(binLen);
  posB.copy(bin, oPos);
  nrmB.copy(bin, oNrm);
  uvB.copy(bin, oUv);
  idxB.copy(bin, oIdx);
  void binPad;

  const header = Buffer.alloc(12);
  header.writeUInt32LE(0x46546c67, 0); // 'glTF'
  header.writeUInt32LE(2, 4);
  header.writeUInt32LE(12 + 8 + jsonB.length + 8 + bin.length, 8);
  const jsonHeader = Buffer.alloc(8);
  jsonHeader.writeUInt32LE(jsonB.length, 0);
  jsonHeader.writeUInt32LE(0x4e4f534a, 4); // 'JSON'
  const binHeader = Buffer.alloc(8);
  binHeader.writeUInt32LE(bin.length, 0);
  binHeader.writeUInt32LE(0x004e4942, 4); // 'BIN'

  return writeFile(dst, Buffer.concat([header, jsonHeader, jsonB, binHeader, bin]));
}

/* ---------------- main ---------------- */

export async function normalizeStlToGlb(src: string, dst: string): Promise<NormalizeResult | null> {
  const buf = await readFile(src);
  let tris: Float32Array | null = null;

  if (buf.length >= 84) {
    const declared = buf.readUInt32LE(80);
    if (buf.length === 84 + declared * 50) tris = parseBinary(buf);
  }
  if (!tris) tris = parseAscii(buf.toString("latin1"));
  if (!tris || tris.length < 9) return null;

  const triCount = tris.length / 9;

  // bounding box
  let minX = Infinity, minY = Infinity, minZ = Infinity;
  let maxX = -Infinity, maxY = -Infinity, maxZ = -Infinity;
  for (let i = 0; i < tris.length; i += 3) {
    const x = tris[i], y = tris[i + 1], z = tris[i + 2];
    if (x < minX) minX = x;
    if (y < minY) minY = y;
    if (z < minZ) minZ = z;
    if (x > maxX) maxX = x;
    if (y > maxY) maxY = y;
    if (z > maxZ) maxZ = z;
  }
  const maxDim = Math.max(maxX - minX, maxY - minY, maxZ - minZ) || 1;
  const cx = (minX + maxX) / 2;
  const cy = (minY + maxY) / 2;
  const cz = (minZ + maxZ) / 2;
  const r = maxDim / 2;

  // weld / decimate by spatial quantisation
  const cell = maxDim * Math.sqrt(Math.PI / TARGET_VERTS);
  const weld = new Map<string, number>();
  const sums: number[] = []; // x,y,z,count per welded vertex
  const weldedTris: number[] = [];
  const q = (v: number) => Math.round(v / cell);

  const weldIndex = (x: number, y: number, z: number): number => {
    const key = `${q(x - minX)},${q(y - minY)},${q(z - minZ)}`;
    let id = weld.get(key);
    if (id === undefined) {
      id = sums.length / 4;
      weld.set(key, id);
      sums.push(x, y, z, 1);
    } else {
      sums[id * 4 + 0] += x;
      sums[id * 4 + 1] += y;
      sums[id * 4 + 2] += z;
      sums[id * 4 + 3] += 1;
    }
    return id;
  };

  for (let t = 0; t < triCount; t++) {
    const o = t * 9;
    const a = weldIndex(tris[o], tris[o + 1], tris[o + 2]);
    const b = weldIndex(tris[o + 3], tris[o + 4], tris[o + 5]);
    const c = weldIndex(tris[o + 6], tris[o + 7], tris[o + 8]);
    if (a === b || b === c || a === c) continue; // degenerate after welding
    weldedTris.push(a, b, c);
  }
  if (weldedTris.length < 9) return null;

  const weldedCount = sums.length / 4;
  const wpos = new Float32Array(weldedCount * 3);
  for (let i = 0; i < weldedCount; i++) {
    const n = sums[i * 4 + 3] || 1;
    wpos[i * 3 + 0] = sums[i * 4 + 0] / n;
    wpos[i * 3 + 1] = sums[i * 4 + 1] / n;
    wpos[i * 3 + 2] = sums[i * 4 + 2] / n;
  }

  // base normals (radial) + base equirect UVs per welded vertex
  const wnrm = new Float32Array(weldedCount * 3);
  const wuv = new Float32Array(weldedCount * 2);
  for (let i = 0; i < weldedCount; i++) {
    const x = wpos[i * 3] - cx;
    const y = wpos[i * 3 + 1] - cy;
    const z = wpos[i * 3 + 2] - cz;
    const len = Math.hypot(x, y, z) || 1;
    wnrm[i * 3] = x / len;
    wnrm[i * 3 + 1] = y / len;
    wnrm[i * 3 + 2] = z / len;
    wuv[i * 2] = 0.5 - Math.atan2(y, x) / (2 * Math.PI);
    wuv[i * 2 + 1] = 0.5 + Math.asin(Math.max(-1, Math.min(1, z / r))) / Math.PI;
  }

  // final buffers with seam duplication (u+1 on the low side of crossing polys)
  const fpos: number[] = [];
  const fnrm: number[] = [];
  const fuv: number[] = [];
  const finalIds = new Map<number, number>();
  const indices: number[] = [];

  const finalIndex = (w: number, off: number): number => {
    const key = w * 2 + off;
    let id = finalIds.get(key);
    if (id === undefined) {
      id = fpos.length / 3;
      finalIds.set(key, id);
      fpos.push(wpos[w * 3], wpos[w * 3 + 1], wpos[w * 3 + 2]);
      fnrm.push(wnrm[w * 3], wnrm[w * 3 + 1], wnrm[w * 3 + 2]);
      fuv.push(wuv[w * 2] + off, wuv[w * 2 + 1]);
    }
    return id;
  };

  for (let t = 0; t < weldedTris.length; t += 3) {
    const corner = [weldedTris[t], weldedTris[t + 1], weldedTris[t + 2]];
    const us = corner.map((w) => wuv[w * 2]);
    const crosses = Math.max(...us) - Math.min(...us) > 0.5;
    for (const w of corner) {
      const off = crosses && wuv[w * 2] < 0.5 ? 1 : 0;
      indices.push(finalIndex(w, off));
    }
  }

  await writeGlb(
    dst,
    Float32Array.from(fpos),
    Float32Array.from(fnrm),
    Float32Array.from(fuv),
    Uint32Array.from(indices),
    [minX, minY, minZ],
    [maxX, maxY, maxZ]
  );

  return { triangles: indices.length / 3, vertices: fpos.length / 3 };
}
