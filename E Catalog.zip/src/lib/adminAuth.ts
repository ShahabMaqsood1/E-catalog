import { createHash } from "crypto";
import { cookies } from "next/headers";

export const ADMIN_COOKIE = "fs_admin_token";
export const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "forward2026";
export const DEMO_MODE = !process.env.ADMIN_PASSWORD;

export function tokenFor(password: string) {
  return createHash("sha256").update(`forward:${password}`).digest("hex");
}

export async function isAdmin(): Promise<boolean> {
  const store = await cookies();
  return store.get(ADMIN_COOKIE)?.value === tokenFor(ADMIN_PASSWORD);
}
