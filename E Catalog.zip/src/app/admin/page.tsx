import { isAdmin } from "@/lib/adminAuth";
import AdminLogin from "@/components/admin/AdminLogin";
import AdminStudio from "@/components/admin/AdminStudio";

export const dynamic = "force-dynamic";

export default async function AdminPage() {
  const authed = await isAdmin();
  if (!authed) return <AdminLogin />;
  return <AdminStudio />;
}
