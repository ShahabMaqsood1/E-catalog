import type { Metadata } from "next";
import type { ReactNode } from "react";
import "@fontsource-variable/archivo";
import "@fontsource-variable/manrope";
import "@fontsource-variable/dm-sans";
import "./globals.css";
import { TourProvider } from "@/components/Tour";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { getSetting } from "@/lib/settings";
import { DEFAULT_BRAND, type BrandCfg } from "@/lib/content-schema";

export async function generateMetadata(): Promise<Metadata> {
  const brand = await getSetting<BrandCfg>("brand", {});
  return {
    title: "Forward Sports — Product Catalog | The Soccer Expert",
    description:
      "Official product catalog of Forward Sports, Sialkot — configure hand-stitched, machine-stitched, thermal-bonded, hybrid, mini, volleyball and medicine balls in live 3D with real rexine materials. Company profile, facilities and team: forward.pk.",
    icons: { icon: brand.favicon || DEFAULT_BRAND.favicon! },
  };
}

export default async function RootLayout({ children }: { children: ReactNode }) {
  const brand: BrandCfg = { ...DEFAULT_BRAND, ...(await getSetting<BrandCfg>("brand", {})) };
  return (
    <html lang="en">
      <body className="bg-paper text-ink-900 font-ui antialiased">
        <TourProvider>
          <Header logoUrl={brand.logo} />
          {children}
          <Footer />
        </TourProvider>
      </body>
    </html>
  );
}
