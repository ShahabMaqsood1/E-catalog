import { db } from "@/db";
import { activity, quotes } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  try {
    const b = await req.json();
    const customerName = String(b.customerName ?? "").trim();
    const email = String(b.email ?? "").trim();
    const quantity = Number(b.quantity ?? 0);
    const unitPrice = Number(b.unitPrice ?? 0);
    const total = Number(b.total ?? 0);

    if (!customerName || customerName.length < 2)
      return Response.json({ error: "Please provide your name." }, { status: 400 });
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))
      return Response.json({ error: "Please provide a valid business email." }, { status: 400 });
    if (!Number.isFinite(quantity) || quantity < 1)
      return Response.json({ error: "Quantity must be at least 1." }, { status: 400 });
    if (!Number.isFinite(unitPrice) || unitPrice < 0)
      return Response.json({ error: "Invalid pricing payload." }, { status: 400 });

    const ref = `FSQ-${Date.now().toString(36).toUpperCase()}${Math.floor(Math.random() * 90 + 10)}`;

    await db.insert(quotes).values({
      ref,
      articleId: b.articleId ? Number(b.articleId) : null,
      materialId: b.materialId ? Number(b.materialId) : null,
      customerName,
      company: String(b.company ?? "").trim(),
      email,
      quantity: Math.round(quantity),
      unitPrice: unitPrice.toFixed(2),
      total: (Number.isFinite(total) ? total : unitPrice * quantity).toFixed(2),
      logoName: b.logoName ? String(b.logoName).slice(0, 200) : null,
      message: String(b.message ?? "").slice(0, 2000),
    });

    await db.insert(activity).values({
      event: "quote_request",
      refId: b.articleId ? String(b.articleId) : null,
      payload: { ref, quantity: Math.round(quantity), email },
    });

    return Response.json({ ok: true, ref });
  } catch (err) {
    console.error("[quote]", err);
    return Response.json({ error: "Could not submit the request. Please try again." }, { status: 500 });
  }
}
