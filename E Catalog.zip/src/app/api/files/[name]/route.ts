import { readFile } from "fs/promises";
import path from "path";

export const dynamic = "force-dynamic";

const TYPES: Record<string, string> = {
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".webp": "image/webp",
  ".svg": "image/svg+xml",
  ".pdf": "application/pdf",
  ".cdr": "application/octet-stream",
  ".ai": "application/octet-stream",
  ".eps": "application/octet-stream",
  ".glb": "model/gltf-binary",
  ".gltf": "model/gltf+json",
  ".obj": "model/obj",
  ".stl": "model/stl",
};

export async function GET(_req: Request, ctx: { params: Promise<{ name: string }> }) {
  const { name } = await ctx.params;
  const safe = path.basename(name);
  if (!safe || safe !== name || name.includes("..")) {
    return Response.json({ error: "Invalid file name." }, { status: 400 });
  }
  try {
    const filePath = path.join(process.cwd(), "storage", "uploads", safe);
    const buf = await readFile(filePath);
    const type = TYPES[path.extname(safe).toLowerCase()] ?? "application/octet-stream";
    return new Response(buf, {
      headers: {
        "Content-Type": type,
        "Cache-Control": "public, max-age=31536000, immutable",
      },
    });
  } catch {
    return Response.json({ error: "File not found." }, { status: 404 });
  }
}
