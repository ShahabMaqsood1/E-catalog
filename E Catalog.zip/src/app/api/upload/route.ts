import { mkdir, writeFile } from "fs/promises";
import path from "path";
import { isAdmin } from "@/lib/adminAuth";
import { db } from "@/db";
import { uploads } from "@/db/schema";

export const dynamic = "force-dynamic";

const DESIGN_EXTS = new Set(["cdr", "ai", "eps", "pdf", "svg"]);
const MODEL_EXTS = new Set(["glb", "gltf", "obj", "stl"]);
const IMAGE_EXTS = new Set(["png", "jpg", "jpeg", "webp"]);
const UPLOAD_DIR = path.join(process.cwd(), "storage", "uploads");

export async function POST(req: Request) {
  if (!(await isAdmin())) {
    return Response.json({ error: "Admin access required." }, { status: 401 });
  }
  try {
    const form = await req.formData();
    const file = form.get("file");
    if (!(file instanceof File)) {
      return Response.json({ error: "No file provided." }, { status: 400 });
    }
    if (file.size > 25 * 1024 * 1024) {
      return Response.json({ error: "File must be under 25 MB." }, { status: 400 });
    }
    const ext = (file.name.split(".").pop() || "").toLowerCase();
    if (!DESIGN_EXTS.has(ext) && !IMAGE_EXTS.has(ext) && !MODEL_EXTS.has(ext)) {
      return Response.json(
        {
          error:
            "Allowed files: CorelDRAW (.cdr), .ai, .eps, .pdf, .svg, 3D models (.glb/.gltf/.obj/.stl) or images (png/jpg/webp).",
        },
        { status: 400 }
      );
    }

    await mkdir(UPLOAD_DIR, { recursive: true });
    const storedName = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
    const filePath = path.join(UPLOAD_DIR, storedName);
    const buf = Buffer.from(await file.arrayBuffer());
    await writeFile(filePath, buf);

    // STL files are far too heavy for browsers — convert to a light, UV-mapped
    // GLB on the server right away. The article stores the GLB, not the STL.
    let derivedUrl: string | null = null;
    if (ext === "stl") {
      try {
        const { normalizeStlToGlb } = await import("@/lib/stlNormalize");
        const glbName = `${storedName.replace(/\.stl$/i, "")}.glb`;
        const stats = await normalizeStlToGlb(filePath, path.join(UPLOAD_DIR, glbName));
        if (stats) {
          derivedUrl = `/api/files/${glbName}`;
          console.log(`[stl-normalize] ${file.name}: ${stats.triangles} tris -> ${glbName}`);
        }
      } catch (err) {
        console.warn("[stl-normalize] skipped:", (err as Error).message?.slice(0, 160));
      }
    }

    const [row] = await db
      .insert(uploads)
      .values({
        originalName: file.name,
        storedName,
        kind: MODEL_EXTS.has(ext) ? "model" : DESIGN_EXTS.has(ext) ? "design-file" : "image",
        size: file.size,
        status: "received",
        note: derivedUrl ? "normalized to glb on upload" : "",
      })
      .returning();

    return Response.json({
      ok: true,
      upload: { ...row, url: `/api/files/${storedName}` },
      derivedUrl,
    });
  } catch (err) {
    console.error("[upload]", err);
    return Response.json({ error: "Upload failed." }, { status: 500 });
  }
}
