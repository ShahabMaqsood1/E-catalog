import { db } from "@/db";
import { activity } from "@/db/schema";

export const dynamic = "force-dynamic";

const EVENTS = new Set([
  "article_view",
  "category_visit",
  "material_select",
  "logo_upload",
  "quote_request",
]);

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const event = String(body.event ?? "");
    if (!EVENTS.has(event)) return Response.json({ ok: false }, { status: 400 });
    await db.insert(activity).values({
      event,
      refId: body.refId ? String(body.refId).slice(0, 64) : null,
      payload: (body.payload && typeof body.payload === "object" ? body.payload : {}) as Record<
        string,
        unknown
      >,
    });
    return Response.json({ ok: true });
  } catch {
    return Response.json({ ok: false }, { status: 500 });
  }
}
