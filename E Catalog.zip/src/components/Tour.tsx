"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { usePathname } from "next/navigation";
import { Compass, X } from "lucide-react";
import { TOURS, TOUR_META, type TourId } from "@/lib/tour-steps";
import { cn } from "@/lib/utils";

type TourContextValue = {
  startTour: (id: TourId) => void;
  isActive: boolean;
};

const TourContext = createContext<TourContextValue>({
  startTour: () => {},
  isActive: false,
});

export function useTour() {
  return useContext(TourContext);
}

function tourForPath(pathname: string): TourId {
  if (pathname.startsWith("/admin")) return "admin";
  if (pathname.startsWith("/catalog")) return "catalog";
  return "home";
}

function seenKey(id: TourId) {
  return `fs-tour-seen-${id}`;
}

export function TourProvider({ children }: { children: ReactNode }) {
  const pathname = usePathname();
  const [tourId, setTourId] = useState<TourId | null>(null);
  const [steps, setSteps] = useState(TOURS.home);
  const [stepIdx, setStepIdx] = useState(0);
  const [rect, setRect] = useState<DOMRect | null>(null);
  const [nudgeVisible, setNudgeVisible] = useState(false);
  const introRef = useRef(false);

  const startTour = useCallback((id: TourId) => {
    const available = TOURS[id].filter((s) => document.querySelector(s.target));
    if (available.length === 0) return;
    setSteps(available);
    setStepIdx(0);
    setTourId(id);
    setNudgeVisible(false);
  }, []);

  // First-visit nudge
  useEffect(() => {
    const id = tourForPath(pathname);
    try {
      if (localStorage.getItem(seenKey(id))) return;
      const t = setTimeout(() => setNudgeVisible(true), 1200);
      return () => clearTimeout(t);
    } catch {
      return;
    }
  }, [pathname]);

  const finish = useCallback(() => {
    if (tourId) {
      try {
        localStorage.setItem(seenKey(tourId), "1");
      } catch {
        /* noop */
      }
    }
    setTourId(null);
    setRect(null);
  }, [tourId]);

  // Measure current target
  useEffect(() => {
    if (!tourId) return;
    const step = steps[stepIdx];
    if (!step) return;
    const measure = () => {
      const el = document.querySelector(step.target);
      if (!el) {
        // target vanished — skip forward
        setStepIdx((i) => Math.min(i + 1, steps.length - 1));
        return;
      }
      setRect(el.getBoundingClientRect());
    };
    measure();
    const el = document.querySelector(step.target);
    el?.scrollIntoView({ block: "center", behavior: "smooth" });
    window.addEventListener("resize", measure);
    window.addEventListener("scroll", measure, { passive: true });
    return () => {
      window.removeEventListener("resize", measure);
      window.removeEventListener("scroll", measure);
    };
  }, [tourId, steps, stepIdx]);

  const next = () => {
    if (stepIdx >= steps.length - 1) finish();
    else setStepIdx((i) => i + 1);
  };
  const back = () => setStepIdx((i) => Math.max(0, i - 1));

  useEffect(() => {
    if (!tourId) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") finish();
      if (e.key === "ArrowRight") next();
      if (e.key === "ArrowLeft") back();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tourId, stepIdx, steps.length]);

  const meta = tourId ? TOUR_META[tourId] : null;
  const step = steps[stepIdx];

  const tipStyle = useMemo(() => {
    if (!rect) return { top: "50%", left: "50%", transform: "translate(-50%,-50%)" };
    const vw = typeof window !== "undefined" ? window.innerWidth : 1200;
    const vh = typeof window !== "undefined" ? window.innerHeight : 800;
    const tipW = 340;
    let top = 0;
    let left = 0;
    const placement = step?.placement ?? "bottom";
    if (placement === "bottom") {
      top = rect.bottom + 14;
      left = rect.left + rect.width / 2 - tipW / 2;
    } else if (placement === "top") {
      top = rect.top - 14 - 210;
      left = rect.left + rect.width / 2 - tipW / 2;
    } else if (placement === "left") {
      top = rect.top + rect.height / 2 - 105;
      left = rect.left - tipW - 14;
    } else {
      top = rect.top + rect.height / 2 - 105;
      left = rect.right + 14;
    }
    left = Math.max(12, Math.min(left, vw - tipW - 12));
    top = Math.max(12, Math.min(top, vh - 230));
    return { top, left };
  }, [rect, step]);

  const value = useMemo(
    () => ({ startTour, isActive: !!tourId }),
    [startTour, tourId]
  );

  return (
    <TourContext.Provider value={value}>
      {children}

      {/* First-visit nudge */}
      {nudgeVisible && !tourId && (
        <div className="fixed bottom-5 left-5 z-[90] anim-fade-up">
          <div className="flex items-center gap-3 rounded-xl border border-line bg-ink-950 px-4 py-3 text-white shadow-2xl">
            <Compass className="h-5 w-5 text-brand-400" />
            <div>
              <p className="font-display text-sm font-bold">New to the e-catalog?</p>
              <p className="text-xs text-white/60">Take the 60-second guided tour.</p>
            </div>
            <button
              onClick={() => startTour(tourForPath(pathname))}
              className="ml-2 rounded-lg bg-brand-600 px-3 py-2 text-xs font-bold uppercase tracking-wide hover:bg-brand-500"
            >
              Start
            </button>
            <button
              onClick={() => setNudgeVisible(false)}
              aria-label="Dismiss"
              className="text-white/50 hover:text-white"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>
      )}

      {/* Tour overlay */}
      {tourId && meta && step && (
        <div className="fixed inset-0 z-[100]">
          {/* spotlight */}
          {rect ? (
            <div
              className="pointer-events-none fixed rounded-xl transition-all duration-300"
              style={{
                top: rect.top - 6,
                left: rect.left - 6,
                width: rect.width + 12,
                height: rect.height + 12,
                boxShadow: "0 0 0 9999px rgba(16,14,12,0.66)",
                outline: "2px solid rgba(203,0,0,0.9)",
              }}
            />
          ) : (
            <div className="fixed inset-0 bg-ink-950/66" />
          )}

          <div
            className="fixed z-[101] w-[340px] rounded-xl border border-line bg-card p-5 shadow-2xl anim-fade-up"
            style={tipStyle}
          >
            <div className="mb-2 flex items-center justify-between">
              <span className="rounded bg-brand-600/10 px-2 py-0.5 font-display text-[11px] font-extrabold uppercase tracking-widest text-brand-700">
                Tour · {stepIdx + 1}/{steps.length}
              </span>
              <button onClick={finish} aria-label="Close tour" className="text-ink-400 hover:text-ink-700">
                <X className="h-4 w-4" />
              </button>
            </div>
            <h3 className="font-display text-base font-extrabold text-ink-950">{step.title}</h3>
            <p className="mt-1.5 text-[13px] leading-relaxed text-ink-600">{step.body}</p>
            <div className="mt-4 flex items-center justify-between">
              <button onClick={finish} className="text-xs font-semibold text-ink-400 hover:text-ink-700">
                Skip tour
              </button>
              <div className="flex gap-2">
                <button
                  onClick={back}
                  disabled={stepIdx === 0}
                  className="rounded-lg border border-line px-3 py-1.5 text-xs font-bold text-ink-700 hover:bg-paper disabled:opacity-40"
                >
                  Back
                </button>
                <button
                  onClick={next}
                  className="rounded-lg bg-brand-600 px-4 py-1.5 text-xs font-bold text-white hover:bg-brand-500"
                >
                  {stepIdx === steps.length - 1 ? "Finish" : "Next"}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </TourContext.Provider>
  );
}
