"use client";

import { useEffect, useRef } from "react";
import { buildBallCanvas } from "@/lib/ballTexture";
import type { BallColors } from "@/db/schema";
import { cn } from "@/lib/utils";

export default function BallThumb({
  panelStyle,
  colors,
  rexineUrl,
  artworkUrl,
  designSvgUrl,
  seamStyle,
  label,
  size = 112,
  className,
}: {
  panelStyle: string;
  colors: BallColors;
  rexineUrl?: string | null;
  artworkUrl?: string | null;
  designSvgUrl?: string | null;
  seamStyle?: string | null;
  label?: string;
  size?: number;
  className?: string;
}) {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    let live = true;
    buildBallCanvas({
      panelStyle,
      colors,
      rexineUrl,
      artworkUrl,
      designSvgUrl,
      seamStyle,
      label,
      res: 512,
    }).then((src) => {
      if (!live || !ref.current) return;
      const canvas = ref.current;
      const ctx = canvas.getContext("2d");
      if (!ctx) return;
      const S = canvas.width;
      const SW = src.width;
      const SH = src.height;
      ctx.clearRect(0, 0, S, S);
      ctx.save();
      ctx.beginPath();
      ctx.arc(S / 2, S / 2, S / 2 - 1, 0, Math.PI * 2);
      ctx.clip();
      // show the logo-facing band of the equirect map (proportional crop)
      ctx.drawImage(src, SW * 0.22, SH * 0.1, SW * 0.56, SH * 0.8, -S * 0.1, 0, S * 1.2, S);
      // spherical shading
      const grad = ctx.createRadialGradient(S * 0.36, S * 0.32, S * 0.08, S / 2, S / 2, S * 0.62);
      grad.addColorStop(0, "rgba(255,255,255,0.34)");
      grad.addColorStop(0.55, "rgba(255,255,255,0)");
      grad.addColorStop(1, "rgba(0,0,0,0.42)");
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, S, S);
      ctx.restore();
    });
    return () => {
      live = false;
    };
  }, [panelStyle, colors, rexineUrl, artworkUrl, designSvgUrl, seamStyle, label]);

  return (
    <canvas
      ref={ref}
      width={224}
      height={224}
      style={{ width: size, height: size }}
      className={cn("shrink-0", className)}
      aria-hidden
    />
  );
}
