"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import { Compass, ExternalLink, Menu, X } from "lucide-react";
import { useTour } from "@/components/Tour";
import { cn } from "@/lib/utils";

const NAV = [
  { href: "/", label: "Home" },
  { href: "/catalog", label: "Catalog" },
  { href: "/catalog#thermal-bonded", label: "Thermal Bonded" },
  { href: "/catalog#hand-stitched", label: "Hand-Stitched" },
];

export default function Header({ logoUrl }: { logoUrl?: string }) {
  const pathname = usePathname();
  const { startTour, isActive } = useTour();
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 border-b border-white/10 bg-ink-950/95 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-4 px-4 sm:px-6">
        <Link href="/" data-tour="brand" className="flex items-center gap-3">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={logoUrl || "/brand/forward-logo-white.png"} alt="Forward Sports" className="h-9 w-auto" />
          <span className="hidden leading-none sm:block">
            <span className="block font-display text-[13px] font-black uppercase tracking-[0.18em] text-white">
              Forward Sports
            </span>
            <span className="mt-0.5 block text-[10px] font-bold uppercase tracking-[0.28em] text-brand-400">
              Product Catalog
            </span>
          </span>
        </Link>

        <nav className="hidden items-center gap-1 lg:flex">
          {NAV.map((n) => (
            <Link
              key={n.href}
              href={n.href}
              className={cn(
                "rounded-lg px-3 py-2 text-sm font-semibold text-white/65 transition hover:bg-white/10 hover:text-white",
                pathname === n.href ? "bg-white/10 text-white" : ""
              )}
            >
              {n.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <a
            href="https://forward.pk"
            target="_blank"
            rel="noopener noreferrer"
            className="hidden items-center gap-1.5 rounded-lg bg-brand-600 px-3.5 py-2 font-display text-xs font-extrabold uppercase tracking-wider text-white transition hover:bg-brand-500 sm:flex"
            title="Company website — facilities, team, certifications"
          >
            forward.pk
            <ExternalLink className="h-3.5 w-3.5" />
          </a>
          <button
            data-tour="tour-button"
            onClick={() =>
              startTour(pathname.startsWith("/admin") ? "admin" : pathname.startsWith("/catalog") ? "catalog" : "home")
            }
            disabled={isActive}
            className="hidden items-center gap-1.5 rounded-lg border border-white/15 bg-white/5 px-3 py-2 text-xs font-bold uppercase tracking-wide text-white/80 transition hover:border-brand-400 hover:text-white sm:flex"
          >
            <Compass className="h-3.5 w-3.5" />
            Tour
          </button>
          <button
            className="rounded-lg border border-white/15 p-2 text-white/80 lg:hidden"
            onClick={() => setOpen((v) => !v)}
            aria-label="Menu"
          >
            {open ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
          </button>
        </div>
      </div>

      {open && (
        <div className="border-t border-white/10 bg-ink-950 px-4 py-3 lg:hidden">
          {NAV.map((n) => (
            <Link
              key={n.href}
              href={n.href}
              onClick={() => setOpen(false)}
              className="block rounded-lg px-3 py-2.5 text-sm font-semibold text-white/75 hover:bg-white/10"
            >
              {n.label}
            </Link>
          ))}
          <a
            href="https://forward.pk"
            target="_blank"
            rel="noopener noreferrer"
            className="mt-1 flex items-center gap-2 rounded-lg px-3 py-2.5 text-sm font-semibold text-brand-400"
          >
            <ExternalLink className="h-4 w-4" /> forward.pk — company website
          </a>
          <button
            onClick={() => {
              setOpen(false);
              startTour(pathname.startsWith("/catalog") ? "catalog" : "home");
            }}
            className="mt-1 flex w-full items-center gap-2 rounded-lg px-3 py-2.5 text-sm font-semibold text-white/80"
          >
            <Compass className="h-4 w-4" /> Start the guided tour
          </button>
        </div>
      )}
    </header>
  );
}
