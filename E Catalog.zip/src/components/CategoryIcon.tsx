import {
  Flame,
  Hexagon,
  Dumbbell,
  Layers,
  Network,
  Sparkles,
  Volleyball,
} from "lucide-react";

export function CategoryIcon({ iconKey, className }: { iconKey: string; className?: string }) {
  const props = { className, strokeWidth: 1.8 };
  switch (iconKey) {
    case "needle":
      return <Hexagon {...props} />;
    case "machine":
      return <Network {...props} />;
    case "flame":
      return <Flame {...props} />;
    case "hybrid":
      return <Layers {...props} />;
    case "mini":
      return <Sparkles {...props} />;
    case "volley":
      return <Volleyball {...props} />;
    case "medicine":
      return <Dumbbell {...props} />;
    default:
      return <Hexagon {...props} />;
  }
}
