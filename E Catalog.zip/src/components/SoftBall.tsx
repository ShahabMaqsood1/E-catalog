"use client";

import { useEffect, useRef } from "react";
import { buildBallCanvas } from "@/lib/ballTexture";
import type { BallColors, BallSpecs, SeamStyle } from "@/db/schema";
import type { LayerKey, LayerLabel } from "@/components/BallViewer";
import { cn } from "@/lib/utils";

export type SoftBallProps = {
  panelStyle: string;
  colors: BallColors;
  rexineUrl?: string | null;
  artworkUrl?: string | null;
  designSvgUrl?: string | null;
  seamStyle?: SeamStyle | string | null;
  label?: string;
  autoRotate?: boolean;
  closeUp?: boolean;
  exploded?: boolean;
  specs?: BallSpecs | null;
  layerNames?: Partial<Record<LayerKey, LayerLabel>>;
  focusLayer?: LayerKey | null;
  className?: string;
};

const LAYERS: LayerKey[] = ["cover", "foam", "lining", "bladder"];
const RADII = [1, 0.8, 0.63, 0.48]; // matches the WebGL exploded rig
const OFFX = [0.95, 0.35, -0.25, -0.78]; // matches EXPLODE_OFFSET
const WEDGE = Math.PI / 4; // half of the 90° cut that faces the camera

const ihash = (x: number, y: number, s: number) => {
  let h = (Math.imul(x, 374761393) + Math.imul(y, 668265263) + Math.imul(s, 1442695041)) | 0;
  h = (h ^ (h >>> 13)) | 0;
  h = Math.imul(h, 1274126177);
  return ((h ^ (h >>> 16)) >>> 0) / 4294967295;
};

/**
 * WebGL-FREE software renderer (SafeBoundary fallback) — v2.
 * Ray-marches a shaded sphere pixel-by-pixel on a plain 2D canvas from the
 * SAME procedural wrap painter (`buildBallCanvas`) that powers the real 3D
 * viewer, and ALSO implements the two studio modes without any GPU:
 *  - Close-up  → damped zoom of the sphere.
 *  - Look inside → 4-layer exploded construction (wedge-cut cover/foam/
 *    lining + full bladder, depth-sorted per pixel, cut-edge shading,
 *    on-canvas layer labels, focus dimming) mirroring the WebGL rig.
 * Buyers on blocked/absent WebGL never lose a feature or see a dead panel.
 */
export default function SoftBall({
  panelStyle,
  colors,
  rexineUrl,
  artworkUrl,
  designSvgUrl,
  seamStyle,
  label,
  autoRotate = true,
  closeUp = false,
  exploded = false,
  specs = null,
  layerNames,
  focusLayer = null,
  className,
}: SoftBallProps) {
  const ref = useRef<HTMLCanvasElement | null>(null);
  const colorsKey = JSON.stringify(colors);

  // live props read by the animation loop without re-triggering the effect
  const stateRef = useRef({ exploded, closeUp, focusLayer, autoRotate });
  stateRef.current = { exploded, closeUp, focusLayer, autoRotate };
  const infoRef = useRef({ specs, layerNames });
  infoRef.current = { specs, layerNames };

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const out = canvas.getContext("2d");
    if (!out) return;

    let live = true;
    let raf = 0;
    let wrap: ImageData | null = null;
    let W = 1024;
    let H = 512;
    let S = canvas.width;
    let slowFrames = 0;
    let needsFirst = true;

    // light + half-vector against view (0,0,1)
    const lv = Math.sqrt(0.42 * 0.42 + 0.62 * 0.62 + 0.66 * 0.66);
    const LX = 0.42 / lv, LY = 0.62 / lv, LZ = 0.66 / lv;
    const hv = Math.sqrt(LX * LX + LY * LY + (LZ + 1) * (LZ + 1));
    const HX = LX / hv, HY = LY / hv, HZ = (LZ + 1) / hv;

    const layerLabels = (): Array<{ name: string; detail: string }> => {
      const sp = infoRef.current.specs;
      const ln = infoRef.current.layerNames ?? {};
      return [
        ln.cover ?? { name: "Rexine cover", detail: "1.05 mm" },
        ln.foam ?? { name: "Impact foam", detail: `${sp?.foamMm ?? 2} mm EVA` },
        ln.lining ?? { name: "Fabric lining", detail: sp?.lining ?? "Cotton-poly winding" },
        ln.bladder ?? { name: "Bladder", detail: sp?.bladder ?? "Butyl" },
      ];
    };

    const drawLabels = (spread: number, R0: number) => {
      const c = S / 2;
      const fs = Math.max(9, Math.round(S * 0.034));
      const labs = layerLabels();
      const focus = stateRef.current.focusLayer;
      out.font = `700 ${fs}px ui-sans-serif, system-ui, sans-serif`;
      out.textBaseline = "middle";
      for (let li = 0; li < 4; li++) {
        const lx = c + OFFX[li] * spread;
        const ly = c - R0 * RADII[li] * 0.86;
        const nm = labs[li].name.toUpperCase();
        const det = labs[li].detail.slice(0, 30);
        const wNm = out.measureText(nm).width;
        out.font = `600 ${Math.round(fs * 0.84)}px ui-sans-serif, system-ui, sans-serif`;
        const wDet = out.measureText(det).width;
        const w = Math.max(wNm, wDet) + 16;
        const h = fs * 3.1;
        let rx = lx - w / 2;
        rx = Math.max(3, Math.min(S - w - 3, rx));
        let ry = ly - h / 2;
        ry = Math.max(3, Math.min(S - h - 3, ry));
        const dim = focus && LAYERS[li] !== focus;
        out.globalAlpha = dim ? 0.35 : 1;
        out.beginPath();
        if (typeof (out as CanvasRenderingContext2D & { roundRect?: unknown }).roundRect === "function") {
          out.roundRect(rx, ry, w, h, 5);
        } else {
          out.rect(rx, ry, w, h);
        }
        out.fillStyle = "rgba(9,10,12,0.85)";
        out.fill();
        out.strokeStyle = "rgba(255,255,255,0.16)";
        out.lineWidth = 1;
        out.stroke();
        out.fillStyle = "#ffffff";
        out.font = `700 ${fs}px ui-sans-serif, system-ui, sans-serif`;
        out.fillText(nm, rx + 8, ry + fs * 0.95);
        out.fillStyle = "#f0b25c";
        out.font = `600 ${Math.round(fs * 0.84)}px ui-sans-serif, system-ui, sans-serif`;
        out.fillText(det, rx + 8, ry + fs * 2.1);
        out.globalAlpha = 1;
      }
    };

    const drawBall = (angle: number, zoom: number) => {
      const img = out.createImageData(S, S);
      const d = img.data;
      const R = (S / 2 - 2) * zoom;
      const c = S / 2;
      const cosA = Math.cos(angle);
      const sinA = Math.sin(angle);
      const data = wrap?.data ?? null;
      for (let y = 0; y < S; y++) {
        const ny = -(y - c) / R;
        for (let x = 0; x < S; x++) {
          const nx = (x - c) / R;
          const r2 = nx * nx + ny * ny;
          const o = (y * S + x) * 4;
          if (r2 > 1) {
            d[o + 3] = 0;
            continue;
          }
          const nz = Math.sqrt(1 - r2);
          const rx = nx * cosA + nz * sinA;
          const rz = -nx * sinA + nz * cosA;
          let u = 0.5 + Math.atan2(rz, rx) / (Math.PI * 2);
          u -= Math.floor(u);
          const vy = ny > 1 ? 1 : ny < -1 ? -1 : ny;
          const v = 0.5 - Math.asin(vy) / Math.PI;
          let cr = 217, cg = 213, cb = 203;
          if (data) {
            const si = (((v * H) | 0) * W + Math.min(W - 1, (u * W) | 0)) * 4;
            cr = data[si];
            cg = data[si + 1];
            cb = data[si + 2];
          }
          const lam = nx * LX + ny * LY + nz * LZ;
          const dif = 0.38 + 0.72 * (lam > 0 ? lam : 0);
          let sp = nx * HX + ny * HY + nz * HZ;
          sp = sp > 0 ? Math.pow(sp, 42) * 0.38 : 0;
          const one = 1 - nz;
          const add = 255 * (sp + one * one * one * 0.14);
          d[o] = cr * dif + add;
          d[o + 1] = cg * dif + add;
          d[o + 2] = cb * dif + add;
          d[o + 3] = 255;
        }
      }
      out.clearRect(0, 0, S, S);
      out.putImageData(img, 0, 0);
    };

    const drawExploded = (t: number, angle: number) => {
      const img = out.createImageData(S, S);
      const d = img.data;
      const c = S / 2;
      const R0 = (S / 2 - 2) * 0.72;
      const spread = t * 0.14 * S;
      const cosA = Math.cos(angle);
      const sinA = Math.sin(angle);
      const data = wrap?.data ?? null;
      const latex = (infoRef.current.specs?.bladder ?? "").toLowerCase().includes("latex");
      const focus = stateRef.current.focusLayer;
      for (let y = 0; y < S; y++) {
        const py = -(y - c);
        for (let x = 0; x < S; x++) {
          const o = (y * S + x) * 4;
          let bestZ = -1;
          let bl = -1;
          let bnx = 0, bny = 0, bnz = 0, baz = 0;
          for (let li = 0; li < 4; li++) {
            const Rl = R0 * RADII[li];
            const nx = (x - c - OFFX[li] * spread) / Rl;
            const ny = py / Rl;
            const r2 = nx * nx + ny * ny;
            if (r2 > 1) continue;
            const nz = Math.sqrt(1 - r2);
            let az = 0;
            if (li < 3) {
              az = Math.atan2(nx, nz);
              if (az > -WEDGE && az < WEDGE) continue; // camera-facing cut
            }
            const z = nz * Rl;
            if (z > bestZ) {
              bestZ = z;
              bl = li;
              bnx = nx;
              bny = ny;
              bnz = nz;
              baz = az;
            }
          }
          if (bl < 0) {
            d[o + 3] = 0;
            continue;
          }
          let cr: number, cg: number, cb: number;
          if (bl === 0) {
            if (data) {
              const rx = bnx * cosA + bnz * sinA;
              const rz = -bnx * sinA + bnz * cosA;
              let u = 0.5 + Math.atan2(rz, rx) / (Math.PI * 2);
              u -= Math.floor(u);
              const vy = bny > 1 ? 1 : bny < -1 ? -1 : bny;
              const v = 0.5 - Math.asin(vy) / Math.PI;
              const si = (((v * H) | 0) * W + Math.min(W - 1, (u * W) | 0)) * 4;
              cr = data[si];
              cg = data[si + 1];
              cb = data[si + 2];
            } else {
              cr = 217; cg = 213; cb = 203;
            }
          } else if (bl === 1) {
            const n = ihash(x, y, 11) * 0.09;
            cr = 239 * (1 - n); cg = 231 * (1 - n); cb = 210 * (1 - n);
          } else if (bl === 2) {
            const g = x % 9 < 2 || y % 9 < 2;
            cr = g ? 150 : 189; cg = g ? 133 : 172; cb = g ? 110 : 157;
          } else {
            if (latex) { cr = 217; cg = 201; cb = 162; } else { cr = 46; cg = 39; cb = 33; }
          }
          // darken the wedge cut edge so the section reads clearly
          if (bl < 3) {
            const edge = Math.abs(baz) - WEDGE;
            if (edge < 0.14) {
              const f = 1 - 0.5 * (1 - Math.max(0, edge) / 0.14);
              cr *= f; cg *= f; cb *= f;
            }
          }
          const lam = Math.max(0, bnx * LX + bny * LY + bnz * LZ);
          const dif = 0.42 + 0.68 * lam;
          let sp = bnx * HX + bny * HY + bnz * HZ;
          sp = sp > 0 ? Math.pow(sp, bl === 3 ? 64 : 42) * (bl === 3 ? 0.5 : 0.34) : 0;
          const one = 1 - bnz;
          const add = 255 * (sp + one * one * one * 0.12);
          const dim = focus && LAYERS[bl] !== focus ? 0.32 : 1;
          d[o] = cr * dif * dim + add;
          d[o + 1] = cg * dif * dim + add;
          d[o + 2] = cb * dif * dim + add;
          d[o + 3] = 255;
        }
      }
      out.clearRect(0, 0, S, S);
      out.putImageData(img, 0, 0);
      if (t > 0.35) drawLabels(spread, R0);
    };

    let angle = -Math.PI / 2;
    let tCur = 0;
    let zoom = 1;
    let last = performance.now();

    const tick = (now: number) => {
      if (!live) return;
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      const st = stateRef.current;
      const tTgt = st.exploded ? 1 : 0;
      const zTgt = st.closeUp && !st.exploded ? 1.5 : 1;
      let dirty = needsFirst;
      if (st.autoRotate && !st.exploded && !document.hidden) {
        angle += dt * 0.45;
        dirty = true;
      }
      if (Math.abs(tCur - tTgt) > 0.002) {
        tCur += (tTgt - tCur) * Math.min(1, dt * 3.4);
        dirty = true;
      } else if (tCur !== tTgt) {
        tCur = tTgt;
        dirty = true;
      }
      if (Math.abs(zoom - zTgt) > 0.002) {
        zoom += (zTgt - zoom) * Math.min(1, dt * 5);
        dirty = true;
      } else if (zoom !== zTgt) {
        zoom = zTgt;
        dirty = true;
      }
      if (dirty && !document.hidden) {
        const t0 = performance.now();
        if (tCur > 0.02) drawExploded(tCur, angle);
        else drawBall(angle, zoom);
        needsFirst = false;
        // adaptive quality: step down if the device struggles
        if (performance.now() - t0 > 34) {
          slowFrames++;
          if (slowFrames > 12 && S > 160) {
            S = S > 224 ? 224 : 160;
            canvas.width = S;
            canvas.height = S;
            slowFrames = 0;
          }
        } else if (slowFrames > 0) {
          slowFrames--;
        }
      }
      raf = requestAnimationFrame(tick);
    };

    const opts = {
      panelStyle,
      colors: JSON.parse(colorsKey) as BallColors,
      rexineUrl,
      artworkUrl,
      designSvgUrl,
      seamStyle,
      label,
      res: 1024,
    };
    buildBallCanvas(opts)
      .then((wc) => {
        if (!live) return;
        W = wc.width;
        H = wc.height;
        const ctx = wc.getContext("2d", { willReadFrequently: true });
        if (ctx) wrap = ctx.getImageData(0, 0, W, H);
        needsFirst = true;
      })
      .catch(() => {
        needsFirst = true;
      });

    raf = requestAnimationFrame(tick);
    return () => {
      live = false;
      cancelAnimationFrame(raf);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [panelStyle, colorsKey, rexineUrl, artworkUrl, designSvgUrl, seamStyle, label]);

  return (
    <div className={cn("relative grid h-full w-full place-items-center", className)}>
      <canvas
        ref={ref}
        width={320}
        height={320}
        className="max-h-full w-auto max-w-full"
        role="img"
        aria-label="Ball preview (software rendered — WebGL unavailable)"
      />
      <span className="pointer-events-none absolute bottom-2 left-1/2 -translate-x-1/2 rounded bg-black/55 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-white/70 backdrop-blur">
        Software preview · WebGL unavailable
      </span>
    </div>
  );
}
