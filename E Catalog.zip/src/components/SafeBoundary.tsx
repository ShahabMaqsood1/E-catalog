"use client";

import { Component, type ErrorInfo, type ReactNode } from "react";

type Reason = "webgl" | "engine" | null;

/**
 * Keeps a failing 3D/canvas subtree from taking the whole page down.
 * v3: on failure it
 *  (a) PROBES the browser live — can a WebGL context be created at all, and
 *      on which GPU/renderer — and shows that as a diagnostics line so the
 *      exact blocker (iframe policy vs. drivers vs. a code error) is visible
 *      without opening dev tools,
 *  (b) AUTO-RETRIES once after 2.5 s (GPU process / lazily loaded chunks can
 *      come up late — e.g. right after enabling graphics acceleration),
 *  (c) offers "Open in a new tab" (embedded preview frames frequently block
 *      WebGL via permissions policy), and
 *  (d) renders the caller's `fallback` (the WebGL-free <SoftBall/>) so the
 *      buyer still gets a full software preview instead of a dead panel.
 */
export default class SafeBoundary extends Component<
  { children: ReactNode; label?: string; height?: string; fallback?: ReactNode },
  { failed: boolean; reason: Reason; detail: string }
> {
  state = { failed: false, reason: null as Reason, detail: "" };
  private retried = false;
  private retryTimer: ReturnType<typeof setTimeout> | null = null;

  static getDerivedStateFromError() {
    return { failed: true };
  }

  componentWillUnmount() {
    if (this.retryTimer) clearTimeout(this.retryTimer);
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    let reason: Reason = "engine";
    let detail = error.message;
    try {
      const c = document.createElement("canvas");
      const gl = (c.getContext("webgl2") ?? c.getContext("webgl")) as WebGLRenderingContext | null;
      if (!gl) {
        reason = "webgl";
        detail = "this window/frame could not create ANY WebGL context — it is blocked here (iframe permissions policy, disabled graphics acceleration, or no GPU/driver)";
      } else {
        const dbg = gl.getExtension("WEBGL_debug_renderer_info") as
          | { UNMASKED_RENDERER_WEBGL: GLenum }
          | null;
        const renderer = dbg ? String(gl.getParameter(dbg.UNMASKED_RENDERER_WEBGL)) : "unknown renderer";
        detail = `WebGL works in this window (${renderer.slice(0, 90)}) — the 3D engine itself errored: ${error.message}`;
        gl.getExtension("WEBGL_lose_context")?.loseContext();
      }
    } catch {
      reason = "webgl";
      detail = `WebGL probe failed: ${error.message}`;
    }
    this.setState({ reason, detail: detail.slice(0, 340) });
    console.warn(
      `[SafeBoundary:${this.props.label ?? "viewer"}] ${reason === "webgl" ? "WebGL unavailable" : "engine error"} —`,
      error.message,
      info.componentStack
    );
    // one automatic retry — context/chunk may appear shortly after first failure
    if (!this.retried) {
      this.retried = true;
      this.retryTimer = setTimeout(() => {
        this.setState({ failed: false, reason: null, detail: "" });
      }, 2500);
    }
  }

  render() {
    if (this.state.failed) {
      const webglBlocked = this.state.reason !== "engine";
      return (
        <div
          className="flex flex-col overflow-hidden rounded-xl border border-line bg-card"
          style={{ minHeight: this.props.height ?? "260px", height: this.props.height }}
        >
          <div className="px-6 pt-5 text-center">
            <p className="font-display text-sm font-extrabold uppercase tracking-widest text-ink-700">
              3D preview unavailable
            </p>
            <p className="mx-auto mt-2 max-w-md text-xs leading-relaxed text-ink-500">
              {webglBlocked
                ? "Real-time 3D is blocked in THIS window. If you are viewing inside an embedded preview, click “Open in a new tab” — previews often block WebGL even after you enable graphics acceleration."
                : "The 3D engine hit an error on this device. The software preview below is fully functional meanwhile."}
            </p>
            {this.state.detail && (
              <p className="mx-auto mt-2 max-w-md break-words rounded-md border border-line bg-paper px-3 py-2 text-left font-mono text-[10px] leading-relaxed text-ink-500">
                <b className="text-ink-700">Diagnostics: </b>
                {this.state.detail}
              </p>
            )}
            <details className="mx-auto mt-3 max-w-md text-left">
              <summary className="cursor-pointer text-center text-xs font-bold text-brand-700 hover:text-brand-800">
                How to enable WebGL
              </summary>
              <ol className="mt-2 list-decimal space-y-1.5 pl-5 text-[11px] leading-relaxed text-ink-500">
                <li>
                  Click <b>Open in a new tab</b> below — embedded preview frames frequently block
                  WebGL even when the browser supports it.
                </li>
                <li>
                  Chrome / Edge: <b>Settings → System → “Use graphics acceleration when
                  available”</b> → toggle ON → <b>Relaunch</b> (a normal reload is not enough —
                  the browser must fully restart).
                </li>
                <li>
                  Verify at <b>chrome://gpu</b> — the “WebGL2” row should read{" "}
                  <i>Hardware accelerated</i>.
                </li>
                <li>
                  No GPU (VM / remote desktop)? Enable <b>chrome://flags → “Enable unsafe
                  SwiftShader”</b> to run WebGL in software — the full 3D studio will work
                  (slower, but real).
                </li>
                <li>Update your graphics driver, or try Firefox / Safari.</li>
              </ol>
            </details>
            <div className="mt-3 flex flex-wrap items-center justify-center gap-2">
              <button
                onClick={() => this.setState({ failed: false, reason: null, detail: "" })}
                className="rounded-lg border border-line px-4 py-2 text-xs font-bold text-ink-700 hover:bg-paper"
              >
                Try again
              </button>
              <button
                onClick={() => window.open(window.location.href, "_blank", "noopener")}
                className="rounded-lg bg-brand-600 px-4 py-2 text-xs font-bold text-white hover:bg-brand-700"
              >
                Open in a new tab
              </button>
            </div>
            {this.props.fallback && (
              <p className="mt-3 text-[11px] font-semibold text-ink-400">
                The preview below is software-rendered — every feature (spin, close-up, look
                inside) still works.
              </p>
            )}
          </div>
          {this.props.fallback ? (
            <div className="min-h-0 flex-1 p-3">{this.props.fallback}</div>
          ) : (
            <div className="flex-1" />
          )}
        </div>
      );
    }
    return this.props.children;
  }
}
