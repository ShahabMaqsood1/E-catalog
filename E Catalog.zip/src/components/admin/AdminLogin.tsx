"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { KeyRound, ShieldCheck } from "lucide-react";

export default function AdminLogin() {
  const router = useRouter();
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const res = await fetch("/api/admin/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Login failed");
      router.refresh();
    } catch (err) {
      setError((err as Error).message);
      setBusy(false);
    }
  };

  return (
    <main className="mx-auto grid min-h-[70vh] max-w-7xl place-items-center px-4 py-16">
      <div className="w-full max-w-md">
        <div className="rounded-2xl border border-line bg-card p-8 shadow-sm">
          <span className="grid h-12 w-12 place-items-center rounded-xl bg-ink-950 text-white">
            <ShieldCheck className="h-6 w-6" />
          </span>
          <h1 className="mt-5 font-display text-2xl font-black uppercase tracking-tight text-ink-950">
            Admin studio
          </h1>
          <p className="mt-1.5 text-sm text-ink-500">
            Restricted area — catalog editors and the design team only.
          </p>
          <form onSubmit={submit} className="mt-6 space-y-4">
            <label className="block">
              <span className="mb-1 block text-[11px] font-extrabold uppercase tracking-wider text-ink-500">
                Password
              </span>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                autoFocus
                className="w-full rounded-lg border border-line bg-paper px-3 py-2.5 text-sm outline-none focus:border-brand-500"
                placeholder="••••••••••"
              />
            </label>
            {error && <p className="text-xs font-bold text-danger">{error}</p>}
            <button
              type="submit"
              disabled={busy}
              className="flex w-full items-center justify-center gap-2 rounded-xl bg-brand-600 px-5 py-3 font-display text-sm font-extrabold uppercase tracking-widest text-white transition hover:bg-brand-500 disabled:opacity-60"
            >
              <KeyRound className="h-4 w-4" />
              {busy ? "Checking…" : "Enter dashboard"}
            </button>
          </form>
        </div>
      </div>
    </main>
  );
}
