"use client";

import { useEffect, useMemo, useState } from "react";
import { RotateCcw, Save } from "lucide-react";
import { CONTENT_SCHEMA, DEFAULT_BRAND, DEFAULT_CONTENT, type BrandCfg } from "@/lib/content-schema";
import { api, inputCls, uploadFile } from "@/components/admin/ui";
import { cn } from "@/lib/utils";

type Notify = (msg: string, kind?: "ok" | "err") => void;

/** Edits every visible string on the public site — grouped, searchable, live-saved to settings */
export default function ContentTab({ notify }: { notify: Notify }) {
  const [values, setValues] = useState<Record<string, string>>({ ...DEFAULT_CONTENT });
  const [loaded, setLoaded] = useState(false);
  const [saving, setSaving] = useState(false);
  const [filter, setFilter] = useState("");
  const [brand, setBrand] = useState<BrandCfg>({});
  const [brandBusy, setBrandBusy] = useState<"logo" | "favicon" | null>(null);

  useEffect(() => {
    api<Record<string, unknown>>("GET", "settings")
      .then((rows) => {
        const saved = (rows.content ?? {}) as Record<string, unknown>;
        setBrand((rows.brand ?? {}) as BrandCfg);
        const next: Record<string, string> = { ...DEFAULT_CONTENT };
        for (const f of CONTENT_SCHEMA) {
          const v = saved[f.key];
          if (typeof v === "string") next[f.key] = v;
        }
        setValues(next);
        setLoaded(true);
      })
      .catch((e) => {
        notify((e as Error).message, "err");
        setLoaded(true);
      });
  }, [notify]);

  const groups = useMemo(() => {
    const q = filter.trim().toLowerCase();
    const fields = CONTENT_SCHEMA.filter(
      (f) => !q || f.label.toLowerCase().includes(q) || f.group.toLowerCase().includes(q) || values[f.key].toLowerCase().includes(q)
    );
    const map = new Map<string, typeof CONTENT_SCHEMA>();
    for (const f of fields) {
      const arr = map.get(f.group) ?? [];
      arr.push(f);
      map.set(f.group, arr);
    }
    return [...map.entries()];
  }, [filter, values]);

  const dirty = useMemo(
    () => CONTENT_SCHEMA.some((f) => values[f.key] !== DEFAULT_CONTENT[f.key]),
    [values]
  );

  /** Uploads a new logo/favicon and saves settings.brand instantly (live on site). */
  const uploadBrand = (field: "logo" | "favicon") => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept =
      field === "favicon"
        ? "image/png,image/x-icon,image/vnd.microsoft.icon,image/jpeg"
        : "image/png,image/jpeg,image/svg+xml";
    input.onchange = async () => {
      const file = input.files?.[0];
      if (!file) return;
      setBrandBusy(field);
      try {
        const up = await uploadFile(file);
        const next = { ...brand, [field]: up.url };
        setBrand(next);
        await api("POST", "settings", { key: "brand", value: next });
        notify(`${field === "logo" ? "Logo" : "Favicon"} updated — live across the site`);
      } catch (e) {
        notify((e as Error).message, "err");
      } finally {
        setBrandBusy(null);
      }
    };
    input.click();
  };

  const save = async () => {
    setSaving(true);
    try {
      await api("POST", "settings", { key: "content", value: values });
      notify("Site content saved — every page updated");
    } catch (e) {
      notify((e as Error).message, "err");
    } finally {
      setSaving(false);
    }
  };

  if (!loaded) {
    return <div className="animate-pulse rounded-xl border border-line bg-card p-10 text-sm text-ink-400">Loading site content…</div>;
  }

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl font-black uppercase tracking-tight text-ink-950">Site content</h1>
          <p className="max-w-2xl text-sm text-ink-500">
            Every heading, paragraph, button and footer line on the public site — editable here, live on save.
            Nothing is hard-coded: if a field is cleared it falls back to the built-in default.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setValues({ ...DEFAULT_CONTENT })}
            className="flex items-center gap-2 rounded-xl border border-line px-4 py-2.5 text-sm font-bold text-ink-600 hover:bg-card"
          >
            <RotateCcw className="h-4 w-4" /> Reset to defaults
          </button>
          <button
            onClick={save}
            disabled={saving}
            className={cn(
              "flex items-center gap-2 rounded-xl px-5 py-2.5 font-display text-sm font-extrabold uppercase tracking-widest text-white",
              dirty ? "bg-brand-600 hover:bg-brand-500" : "bg-ink-300"
            )}
          >
            <Save className="h-4 w-4" /> {saving ? "Saving…" : "Save content"}
          </button>
        </div>
      </div>

      <input
        value={filter}
        onChange={(e) => setFilter(e.target.value)}
        placeholder="Search fields or current text…"
        className={cn(inputCls, "max-w-md")}
      />

      <section className="rounded-2xl border border-line bg-card p-5">
        <h2 className="font-display text-sm font-extrabold uppercase tracking-[0.18em] text-ink-950">
          Branding — logo &amp; favicon
        </h2>
        <p className="mt-1.5 max-w-2xl text-xs leading-relaxed text-ink-500">
          The logo shows in the dark header and footer site-wide; the favicon is the browser-tab
          icon. Uploads save instantly (no rebuild) and live in <code>storage/uploads</code> —
          they ship with the project files. Defaults: <code>public/brand/</code> (downloaded from
          forward.pk).
        </p>
        <div className="mt-4 grid gap-4 sm:grid-cols-2">
          <div className="rounded-xl border border-line p-4">
            <p className="text-[11px] font-extrabold uppercase tracking-wider text-ink-400">
              Site logo (white/transparent — shown on dark)
            </p>
            <div className="mt-2 grid h-20 place-items-center rounded-lg bg-ink-950 px-3">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={brand.logo || DEFAULT_BRAND.logo!}
                alt="Current logo"
                className="max-h-12 w-auto"
              />
            </div>
            <button
              onClick={() => uploadBrand("logo")}
              disabled={brandBusy !== null}
              className="mt-3 rounded-lg border border-line px-3 py-1.5 text-xs font-bold text-ink-700 hover:bg-paper disabled:opacity-50"
            >
              {brandBusy === "logo" ? "Uploading…" : "Replace logo"}
            </button>
          </div>
          <div className="rounded-xl border border-line p-4">
            <p className="text-[11px] font-extrabold uppercase tracking-wider text-ink-400">
              Favicon (browser tab icon)
            </p>
            <div className="mt-2 grid h-20 place-items-center rounded-lg bg-paper-deep">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={brand.favicon || DEFAULT_BRAND.favicon!}
                alt="Current favicon"
                className="h-8 w-8"
              />
            </div>
            <button
              onClick={() => uploadBrand("favicon")}
              disabled={brandBusy !== null}
              className="mt-3 rounded-lg border border-line px-3 py-1.5 text-xs font-bold text-ink-700 hover:bg-paper disabled:opacity-50"
            >
              {brandBusy === "favicon" ? "Uploading…" : "Replace favicon"}
            </button>
          </div>
        </div>
      </section>

      {groups.length === 0 ? (
        <div className="rounded-xl border border-line bg-card p-10 text-center text-sm text-ink-400">
          No fields match “{filter}”.
        </div>
      ) : (
        groups.map(([group, fields]) => (
          <section key={group} className="rounded-2xl border border-line bg-card p-5">
            <h2 className="font-display text-sm font-extrabold uppercase tracking-[0.18em] text-ink-950">{group}</h2>
            <div className="mt-4 grid gap-4 lg:grid-cols-2">
              {fields.map((f) => (
                <label key={f.key} className="block">
                  <span className="mb-1 flex items-baseline justify-between text-[11px] font-extrabold uppercase tracking-wider text-ink-500">
                    {f.label}
                    {values[f.key] !== DEFAULT_CONTENT[f.key] && (
                      <span className="text-brand-700">edited</span>
                    )}
                  </span>
                  {f.multiline ? (
                    <textarea
                      rows={3}
                      className={inputCls}
                      value={values[f.key]}
                      onChange={(e) => setValues((v) => ({ ...v, [f.key]: e.target.value }))}
                    />
                  ) : (
                    <input
                      className={inputCls}
                      value={values[f.key]}
                      onChange={(e) => setValues((v) => ({ ...v, [f.key]: e.target.value }))}
                    />
                  )}
                </label>
              ))}
            </div>
          </section>
        ))
      )}
    </div>
  );
}
