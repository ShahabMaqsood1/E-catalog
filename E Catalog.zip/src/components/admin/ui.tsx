"use client";

import { X } from "lucide-react";
import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export const inputCls =
  "w-full rounded-lg border border-line bg-paper px-3 py-2 text-sm text-ink-900 outline-none transition focus:border-brand-500";

export function Field({ label, children, hint }: { label: string; children: ReactNode; hint?: string }) {
  return (
    <label className="block">
      <span className="mb-1 block text-[11px] font-extrabold uppercase tracking-wider text-ink-500">
        {label}
      </span>
      {children}
      {hint && <span className="mt-1 block text-[11px] text-ink-400">{hint}</span>}
    </label>
  );
}

export function Modal({
  title,
  onClose,
  children,
  wide,
}: {
  title: string;
  onClose: () => void;
  children: ReactNode;
  wide?: boolean;
}) {
  return (
    <div className="fixed inset-0 z-[70] grid place-items-center overflow-y-auto bg-ink-950/60 p-4 backdrop-blur-sm">
      <div
        className={cn(
          "my-8 w-full rounded-2xl border border-line bg-card shadow-2xl anim-fade-up",
          wide ? "max-w-2xl" : "max-w-lg"
        )}
      >
        <div className="flex items-center justify-between border-b border-line bg-paper px-6 py-4">
          <h3 className="font-display text-lg font-black text-ink-950">{title}</h3>
          <button onClick={onClose} className="text-ink-400 hover:text-ink-700" aria-label="Close">
            <X className="h-5 w-5" />
          </button>
        </div>
        <div className="px-6 py-5">{children}</div>
      </div>
    </div>
  );
}

export function Badge({ tone, children }: { tone: "ok" | "warn" | "danger" | "neutral" | "brand"; children: ReactNode }) {
  const cls =
    tone === "ok"
      ? "bg-ok-soft text-ok"
      : tone === "warn"
        ? "bg-warn-soft text-warn"
        : tone === "danger"
          ? "bg-danger-soft text-danger"
          : tone === "brand"
            ? "bg-brand-600/10 text-brand-700"
            : "bg-ink-100 text-ink-600";
  return (
    <span className={cn("inline-flex items-center rounded-md px-2 py-0.5 text-[11px] font-extrabold", cls)}>
      {children}
    </span>
  );
}

export function Toggle({ checked, onChange, label }: { checked: boolean; onChange: (v: boolean) => void; label?: string }) {
  return (
    <button
      type="button"
      onClick={() => onChange(!checked)}
      className="flex items-center gap-2.5"
      aria-pressed={checked}
    >
      <span
        className={cn(
          "relative h-6 w-11 rounded-full transition",
          checked ? "bg-ok" : "bg-ink-200"
        )}
      >
        <span
          className={cn(
            "absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all",
            checked ? "left-[22px]" : "left-0.5"
          )}
        />
      </span>
      {label && <span className="text-sm font-semibold text-ink-700">{label}</span>}
    </button>
  );
}

export function StatCard({ label, value, sub, accent }: { label: string; value: string; sub?: string; accent?: boolean }) {
  return (
    <div className={cn("rounded-xl border p-4", accent ? "border-brand-600/25 bg-brand-600/5" : "border-line bg-card")}>
      <p className="text-[10px] font-extrabold uppercase tracking-[0.18em] text-ink-400">{label}</p>
      <p className={cn("mt-1.5 font-display text-2xl font-black", accent ? "text-brand-700" : "text-ink-950")}>
        {value}
      </p>
      {sub && <p className="mt-0.5 text-[11px] font-semibold text-ink-400">{sub}</p>}
    </div>
  );
}

export async function api<T = unknown>(
  method: "GET" | "POST" | "PATCH" | "DELETE",
  resource: string,
  body?: unknown
): Promise<T> {
  const res = await fetch(`/api/admin/${resource}`, {
    method,
    headers: body !== undefined ? { "Content-Type": "application/json" } : undefined,
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error((data as { error?: string }).error || "Request failed");
  return data as T;
}

export async function uploadFile(file: File): Promise<{ url: string; id: number; derivedUrl: string | null }> {
  const fd = new FormData();
  fd.append("file", file);
  const res = await fetch("/api/upload", { method: "POST", body: fd });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error((data as { error?: string }).error || "Upload failed");
  const d = data as { upload: { url?: string; id: number }; derivedUrl?: string | null };
  return { url: d.upload.url ?? "", id: d.upload.id, derivedUrl: d.derivedUrl ?? null };
}

export function bytes(n: number) {
  if (n > 1024 * 1024) return `${(n / 1024 / 1024).toFixed(1)} MB`;
  if (n > 1024) return `${Math.round(n / 1024)} KB`;
  return `${n} B`;
}
