"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { Download, FilePlus2, Pencil, Plus, Trash2, UploadCloud } from "lucide-react";
import type { BallColors } from "@/db/schema";
import { PANEL_STYLES, SEAM_STYLES } from "@/lib/ballTexture";
import { cn, formatMoney } from "@/lib/utils";
import dynamic from "next/dynamic";
import BallThumb from "@/components/BallThumb";
import SafeBoundary from "@/components/SafeBoundary";
import SoftBall from "@/components/SoftBall";
import { api, Badge, bytes, Field, inputCls, Modal, Toggle, uploadFile } from "@/components/admin/ui";

const BallViewer = dynamic(() => import("@/components/BallViewer"), { ssr: false });

export type CategoryRow = {
  id: number;
  slug: string;
  name: string;
  shortName: string;
  tagline: string;
  description: string;
  iconKey: string;
  sortOrder: number;
  isActive: boolean;
};

export type ArticleRow = {
  id: number;
  categoryId: number;
  articleNo: string;
  name: string;
  description: string;
  panelStyle: string;
  panelCount: number;
  basePrice: string;
  moq: number;
  colors: BallColors;
  featured: boolean;
  status: string;
  artworkUrl: string | null;
  designSvgUrl: string | null;
  modelUrl: string | null;
  modelAdjust: { rotY: number; offsetX: number; offsetY: number; scale: number } | null;
  renderUrl: string | null;
  seamStyle: string;
  layerImages: { cover?: string | null; foam?: string | null; lining?: string | null; bladder?: string | null } | null;
  specs: { bladder: string; lining: string; foamMm: number; cover?: string } | null;
  cdrUploadId: number | null;
  defaultMaterialCode: string | null;
};

export type MaterialRow = {
  id: number;
  code: string;
  name: string;
  finish: string;
  description: string;
  textureUrl: string;
  priceDelta: string;
  thickness: string;
  weightGsm: number | null;
  isActive: boolean;
  sortOrder: number;
};

export type UploadRow = {
  id: number;
  originalName: string;
  storedName: string;
  kind: string;
  size: number;
  articleId: number | null;
  status: string;
  note: string;
  createdAt: string;
};

export type ComplianceRow = {
  id: number;
  title: string;
  standard: string;
  detail: string;
  status: string;
  nextReview: string;
  sortOrder: number;
};

type Notify = (msg: string, kind?: "ok" | "err") => void;

/* ================= ARTICLES ================= */

const EMPTY_ARTICLE: ArticleRow = {
  id: 0,
  categoryId: 0,
  articleNo: "",
  name: "",
  description: "",
  panelStyle: "classic-32",
  panelCount: 32,
  basePrice: "10.00",
  moq: 300,
  colors: { base: "#f4f2ec", accent: "#cb0000", ink: "#26221f" },
  featured: false,
  status: "live",
  artworkUrl: null,
  designSvgUrl: null,
  modelUrl: null,
  defaultMaterialCode: null,
  modelAdjust: { rotY: 0, offsetX: 0, offsetY: 0, scale: 1 },
  renderUrl: null,
  seamStyle: "auto",
  layerImages: {},
  specs: { bladder: "Butyl valve bladder", lining: "Cotton-poly winding", foamMm: 2, cover: "" },
  cdrUploadId: null,
};

export function ArticlesTab({ notify }: { notify: Notify }) {
  const [rows, setRows] = useState<ArticleRow[]>([]);
  const [cats, setCats] = useState<CategoryRow[]>([]);
  const [cdrs, setCdrs] = useState<UploadRow[]>([]);
  const [editing, setEditing] = useState<ArticleRow | null>(null);
  const [isNew, setIsNew] = useState(false);

  const load = useCallback(() => {
    api<{ rows: ArticleRow[] }>("GET", "articles").then((d) => setRows(d.rows));
    api<{ rows: CategoryRow[] }>("GET", "categories").then((d) => setCats(d.rows));
    api<{ rows: UploadRow[] }>("GET", "uploads")
      .then((d) => setCdrs(d.rows.filter((u) => u.kind === "design-file")))
      .catch(() => {});
  }, []);
  useEffect(load, [load]);

  const save = async (a: ArticleRow) => {
    const body = { ...a, basePrice: Number(a.basePrice), moq: Number(a.moq), panelCount: Number(a.panelCount) };
    try {
      if (isNew) await api("POST", "articles", body);
      else await api("PATCH", "articles", { id: a.id, data: body });
      notify(isNew ? "Article created" : "Article saved");
      setEditing(null);
      load();
    } catch (e) {
      notify((e as Error).message, "err");
    }
  };

  const remove = async (a: ArticleRow) => {
    if (!confirm(`Delete article ${a.articleNo}? This cannot be undone.`)) return;
    try {
      await api("DELETE", "articles", { id: a.id });
      notify("Article deleted");
      load();
    } catch (e) {
      notify((e as Error).message, "err");
    }
  };

  const catName = (id: number) => cats.find((c) => c.id === id)?.shortName ?? `#${id}`;

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl font-black uppercase tracking-tight text-ink-950">Articles</h1>
          <p className="text-sm text-ink-500">Add unlimited designs to any category — they appear in the catalog instantly.</p>
        </div>
        <button
          onClick={() => {
            setEditing({ ...EMPTY_ARTICLE, categoryId: cats[0]?.id ?? 0, articleNo: `FS-${Date.now().toString().slice(-6)}` });
            setIsNew(true);
          }}
          className="flex items-center gap-2 rounded-xl bg-brand-600 px-4 py-2.5 text-sm font-extrabold text-white hover:bg-brand-500"
        >
          <Plus className="h-4 w-4" /> New article
        </button>
      </div>

      <div className="overflow-x-auto rounded-2xl border border-line bg-card">
        <table className="w-full min-w-[960px] text-left text-sm">
          <thead>
            <tr className="border-b border-line bg-paper text-[10px] uppercase tracking-wider text-ink-400">
              {["Preview", "Article", "Section", "Base price", "MOQ", "Panels", "Flags", ""].map((h, i) => (
                <th key={i} className="px-4 py-3 font-extrabold">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-line">
            {rows.map((a) => (
              <tr key={a.id} className="hover:bg-paper/60">
                <td className="px-4 py-2.5">
                  <BallThumb panelStyle={a.panelStyle} colors={a.colors} artworkUrl={a.artworkUrl} size={46} />
                </td>
                <td className="px-4 py-2.5">
                  <p className="font-bold text-ink-900">{a.name}</p>
                  <p className="font-mono text-[11px] text-ink-400">{a.articleNo}</p>
                </td>
                <td className="px-4 py-2.5 text-xs font-semibold text-ink-600">{catName(a.categoryId)}</td>
                <td className="px-4 py-2.5 font-semibold">{formatMoney(a.basePrice)}</td>
                <td className="px-4 py-2.5 text-xs">{a.moq}</td>
                <td className="px-4 py-2.5 text-xs">{a.panelCount}</td>
                <td className="px-4 py-2.5">
                  <div className="flex flex-wrap gap-1.5">
                    <Badge tone={a.status === "live" ? "ok" : "neutral"}>{a.status}</Badge>
                    {a.featured && <Badge tone="brand">featured</Badge>}
                    {a.artworkUrl && <Badge tone="neutral">artwork</Badge>}
                    {a.designSvgUrl && <Badge tone="brand">vector panels</Badge>}
                    {a.modelUrl && <Badge tone="ok">3D model</Badge>}
                    {!a.modelUrl && a.renderUrl && <Badge tone="neutral">3D render</Badge>}
                    {a.cdrUploadId && <Badge tone="neutral">CDR</Badge>}
                  </div>
                </td>
                <td className="px-4 py-2.5">
                  <div className="flex justify-end gap-1.5">
                    <button onClick={() => { setEditing(a); setIsNew(false); }} className="rounded-lg border border-line p-2 text-ink-500 hover:text-ink-900" title="Edit">
                      <Pencil className="h-3.5 w-3.5" />
                    </button>
                    <button onClick={() => remove(a)} className="rounded-lg border border-line p-2 text-ink-500 hover:text-danger" title="Delete">
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {editing && (
        <ArticleForm
          article={editing}
          cats={cats}
          cdrs={cdrs}
          isNew={isNew}
          onCancel={() => setEditing(null)}
          onSave={save}
        />
      )}
    </div>
  );
}

function ArticleForm({
  article,
  cats,
  cdrs,
  isNew,
  onCancel,
  onSave,
}: {
  article: ArticleRow;
  cats: CategoryRow[];
  cdrs: UploadRow[];
  isNew: boolean;
  onCancel: () => void;
  onSave: (a: ArticleRow) => void;
}) {
  const [draft, setDraft] = useState<ArticleRow>({ ...article, colors: { ...article.colors } });
  const [matOpts, setMatOpts] = useState<MaterialRow[]>([]);
  useEffect(() => {
    api<{ rows: MaterialRow[] }>("GET", "materials")
      .then((d) => setMatOpts(d.rows))
      .catch(() => setMatOpts([]));
  }, []);
  const [uploading, setUploading] = useState(false);
  const set = <K extends keyof ArticleRow>(k: K, v: ArticleRow[K]) => setDraft((d) => ({ ...d, [k]: v }));

  const pickArtwork = async (file: File | undefined) => {
    if (!file) return;
    setUploading(true);
    try {
      const { url } = await uploadFile(file);
      set("artworkUrl", url);
    } catch (e) {
      alert((e as Error).message);
    } finally {
      setUploading(false);
    }
  };

  const pickSvg = async (file: File | undefined) => {
    if (!file) return;
    setUploading(true);
    try {
      const { url } = await uploadFile(file);
      set("designSvgUrl", url);
    } catch (e) {
      alert((e as Error).message);
    } finally {
      setUploading(false);
    }
  };

  /** Generic single-file picker used by the 3D model, render and layer photos.
   *  `apply` receives the stored URL plus any server-derived URL (STL→GLB). */
  const pickInto = async (
    file: File | undefined,
    apply: (url: string, derived?: string | null) => void
  ) => {
    if (!file) return;
    // Guard: refuse files the server would reject anyway
    if (file.size > 25 * 1024 * 1024) {
      alert("File is larger than 25 MB. Decimate it in Blender first (see BLENDER_MCP_PROMPT.md).");
      return;
    }
    setUploading(true);
    try {
      const { url, derivedUrl } = await uploadFile(file);
      apply(url, derivedUrl);
    } catch (e) {
      alert((e as Error).message);
    } finally {
      setUploading(false);
    }
  };

  const layerImagesDraft = draft.layerImages ?? {};
  const setLayerImage = (key: "cover" | "foam" | "lining" | "bladder", url: string | null) =>
    set("layerImages", { ...layerImagesDraft, [key]: url });

  const adjust = draft.modelAdjust ?? { rotY: 0, offsetX: 0, offsetY: 0, scale: 1 };
  const setAdjust = (patch: Partial<typeof adjust>) => set("modelAdjust", { ...adjust, ...patch });

  const specsDraft = draft.specs ?? { bladder: "", lining: "", foamMm: 2 };

  return (
    <Modal title={isNew ? "New article" : `Edit ${article.articleNo}`} onClose={onCancel} wide>
      <div className="grid gap-5 sm:grid-cols-[1fr_190px]">
        <div className="space-y-3.5">
          <div className="grid gap-3.5 sm:grid-cols-2">
            <Field label="Article number">
              <input className={inputCls} value={draft.articleNo} onChange={(e) => set("articleNo", e.target.value)} />
            </Field>
            <Field label="Section">
              <select className={inputCls} value={draft.categoryId} onChange={(e) => set("categoryId", Number(e.target.value))}>
                {cats.map((c) => (
                  <option key={c.id} value={c.id}>{c.shortName}</option>
                ))}
              </select>
            </Field>
          </div>
          <Field label="Name">
            <input className={inputCls} value={draft.name} onChange={(e) => set("name", e.target.value)} />
          </Field>
          <Field label="Description" hint="Shown to buyers next to the 3D preview.">
            <textarea rows={2} className={inputCls} value={draft.description} onChange={(e) => set("description", e.target.value)} />
          </Field>
          <div className="grid gap-3.5 sm:grid-cols-3">
            <Field label="Panel style">
              <select className={inputCls} value={draft.panelStyle} onChange={(e) => set("panelStyle", e.target.value)}>
                {PANEL_STYLES.map((p) => (
                  <option key={p.key} value={p.key}>{p.label}</option>
                ))}
              </select>
            </Field>
            <Field label="Panel count">
              <input type="number" className={inputCls} value={draft.panelCount} onChange={(e) => set("panelCount", Number(e.target.value))} />
            </Field>
            <Field label="MOQ (pcs)">
              <input type="number" className={inputCls} value={draft.moq} onChange={(e) => set("moq", Number(e.target.value))} />
            </Field>
          </div>
          <Field
            label="Default rexine"
            hint="This article's own material — pre-selected for buyers in the configurator (they can still switch)."
          >
            <select
              className={inputCls}
              value={draft.defaultMaterialCode ?? ""}
              onChange={(e) => set("defaultMaterialCode", e.target.value || null)}
            >
              <option value="">— first active material —</option>
              {matOpts.map((m) => (
                <option key={m.code} value={m.code}>
                  {m.code} · {m.name}
                </option>
              ))}
            </select>
          </Field>
          <div className="grid gap-3.5 sm:grid-cols-2">
            <Field label="Base price (USD)" hint="Final price = base + rexine adjustment.">
              <input type="number" step="0.05" className={inputCls} value={draft.basePrice} onChange={(e) => set("basePrice", e.target.value)} />
            </Field>
            <Field label="Status">
              <select className={inputCls} value={draft.status} onChange={(e) => set("status", e.target.value)}>
                <option value="live">live — visible in catalog</option>
                <option value="draft">draft — hidden</option>
              </select>
            </Field>
          </div>
          <div className="grid grid-cols-3 gap-3.5">
            <Field label="Base colour">
              <input type="color" value={draft.colors.base} onChange={(e) => set("colors", { ...draft.colors, base: e.target.value })} />
            </Field>
            <Field label="Accent colour">
              <input type="color" value={draft.colors.accent} onChange={(e) => set("colors", { ...draft.colors, accent: e.target.value })} />
            </Field>
            <Field label="Seam / ink">
              <input type="color" value={draft.colors.ink} onChange={(e) => set("colors", { ...draft.colors, ink: e.target.value })} />
            </Field>
          </div>
          <div className="rounded-xl border border-brand-200 bg-brand-50/50 p-4">
            <p className="font-display text-[11px] font-extrabold uppercase tracking-widest text-brand-700">
              Panel Intelligence — vector panel map
            </p>
            <p className="mt-1 text-xs leading-relaxed text-ink-500">
              Export the design from CorelDRAW as SVG (File → Export → SVG, 2:1 ratio, curves outlined). The engine
              auto-detects every panel shape and applies whichever rexine the buyer selects — panel by panel, in 3D.
            </p>
            <div className="mt-3 flex flex-wrap items-center gap-3">
              <label className="flex cursor-pointer items-center gap-2 rounded-lg border border-line bg-card px-3 py-2 text-xs font-bold text-ink-700 hover:border-brand-300">
                <UploadCloud className="h-4 w-4" />
                {uploading ? "Uploading…" : draft.designSvgUrl ? "Replace SVG panel map" : "Upload SVG panel map"}
                <input type="file" accept=".svg,image/svg+xml" className="hidden" onChange={(e) => pickSvg(e.target.files?.[0])} />
              </label>
              {draft.designSvgUrl && (
                <>
                  <span className="text-[11px] font-bold text-ok">Vector map attached</span>
                  <button type="button" onClick={() => set("designSvgUrl", null)} className="text-xs font-bold text-danger">
                    Remove
                  </button>
                </>
              )}
            </div>
          </div>
          <Field
            label="Seam / construction look"
            hint="Controls how the panel seams are drawn: hand-stitched shows the open channel with waxed thread, thermal bonded shows a seamless fused groove."
          >
            <select className={inputCls} value={draft.seamStyle} onChange={(e) => set("seamStyle", e.target.value)}>
              {SEAM_STYLES.map((s) => (
                <option key={s.key} value={s.key}>{s.label}</option>
              ))}
            </select>
          </Field>

          <div className="rounded-xl border border-line bg-paper p-4">
            <p className="font-display text-[11px] font-extrabold uppercase tracking-widest text-ink-700">
              3D shape of this ball
            </p>
            <p className="mt-1 text-xs leading-relaxed text-ink-500">
              Each construction sits differently on the ball (hand-stitched panels have a visible gap, bonded panels
              are flush). Upload this article&apos;s own 3D shape and it replaces the generated sphere — the live rexine
              is still wrapped onto it. Priority: <b>3D model</b> → <b>static render</b> → generated 3D ball.
            </p>
            <div className="mt-3 grid gap-3 sm:grid-cols-2">
              <div className="rounded-lg border border-line bg-card p-3">
                <p className="text-[11px] font-extrabold uppercase tracking-wider text-ink-500">
                  3D model (.glb / .gltf / .obj / .stl)
                </p>
                <div className="mt-2 flex flex-wrap items-center gap-2">
                  <label className="flex cursor-pointer items-center gap-2 rounded-lg border border-line bg-paper px-3 py-2 text-xs font-bold text-ink-700 hover:border-brand-300">
                    <UploadCloud className="h-4 w-4" />
                    {draft.modelUrl ? "Replace model" : "Upload 3D model"}
                    <input
                      type="file"
                      accept=".glb,.gltf,.obj,.stl,model/gltf-binary,model/stl"
                      className="hidden"
                      onChange={(e) =>
                        pickInto(e.target.files?.[0], (url, derived) => set("modelUrl", derived ?? url))
                      }
                    />
                  </label>
                  {draft.modelUrl && (
                    <button type="button" onClick={() => set("modelUrl", null)} className="text-xs font-bold text-danger">
                      Remove
                    </button>
                  )}
                </div>
                {draft.modelUrl && <p className="mt-2 text-[11px] font-bold text-ok">3D model attached</p>}
              </div>
              <div className="rounded-lg border border-line bg-card p-3">
                <p className="text-[11px] font-extrabold uppercase tracking-wider text-ink-500">
                  Static 3D render (png / jpg)
                </p>
                <div className="mt-2 flex flex-wrap items-center gap-2">
                  <label className="flex cursor-pointer items-center gap-2 rounded-lg border border-line bg-paper px-3 py-2 text-xs font-bold text-ink-700 hover:border-brand-300">
                    <UploadCloud className="h-4 w-4" />
                    {draft.renderUrl ? "Replace render" : "Upload render image"}
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={(e) => pickInto(e.target.files?.[0], (url) => set("renderUrl", url))}
                    />
                  </label>
                  {draft.renderUrl && (
                    <button type="button" onClick={() => set("renderUrl", null)} className="text-xs font-bold text-danger">
                      Remove
                    </button>
                  )}
                </div>
                {draft.renderUrl && (
                  <div className="mt-2 overflow-hidden rounded-md border border-line bg-paper">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={draft.renderUrl} alt="render" className="h-20 w-full object-contain" />
                  </div>
                )}
              </div>
            </div>
          </div>

          {(draft.modelUrl || draft.renderUrl) && (
            <div className="rounded-xl border border-line bg-paper p-4">
              <p className="font-display text-[11px] font-extrabold uppercase tracking-widest text-ink-700">
                Align the design on this 3D shape
              </p>
              <p className="mt-1 text-xs leading-relaxed text-ink-500">
                STL / GLB files carry geometry only — no artwork coordinates. Use these sliders to line your panel
                map up with the model&apos;s own panel seams. The preview updates live; the same values are used on the
                public catalog.
              </p>
              <div className="mt-3 grid gap-4 lg:grid-cols-[240px_1fr]">
                <div className="space-y-3">
                  <label className="block">
                    <span className="mb-1 flex justify-between text-[11px] font-bold uppercase tracking-wider text-ink-500">
                      Rotate model <span className="text-ink-700">{Math.round(adjust.rotY)}°</span>
                    </span>
                    <input
                      type="range"
                      min={-180}
                      max={180}
                      step={1}
                      value={adjust.rotY}
                      onChange={(e) => setAdjust({ rotY: Number(e.target.value) })}
                      className="w-full accent-brand-600"
                    />
                  </label>
                  <label className="block">
                    <span className="mb-1 flex justify-between text-[11px] font-bold uppercase tracking-wider text-ink-500">
                      Shift design ↔ <span className="text-ink-700">{adjust.offsetX.toFixed(2)}</span>
                    </span>
                    <input
                      type="range"
                      min={-0.5}
                      max={0.5}
                      step={0.01}
                      value={adjust.offsetX}
                      onChange={(e) => setAdjust({ offsetX: Number(e.target.value) })}
                      className="w-full accent-brand-600"
                    />
                  </label>
                  <label className="block">
                    <span className="mb-1 flex justify-between text-[11px] font-bold uppercase tracking-wider text-ink-500">
                      Shift design ↕ <span className="text-ink-700">{adjust.offsetY.toFixed(2)}</span>
                    </span>
                    <input
                      type="range"
                      min={-0.5}
                      max={0.5}
                      step={0.01}
                      value={adjust.offsetY}
                      onChange={(e) => setAdjust({ offsetY: Number(e.target.value) })}
                      className="w-full accent-brand-600"
                    />
                  </label>
                  <label className="block">
                    <span className="mb-1 flex justify-between text-[11px] font-bold uppercase tracking-wider text-ink-500">
                      Design scale <span className="text-ink-700">{adjust.scale.toFixed(2)}×</span>
                    </span>
                    <input
                      type="range"
                      min={0.5}
                      max={2}
                      step={0.05}
                      value={adjust.scale}
                      onChange={(e) => setAdjust({ scale: Number(e.target.value) })}
                      className="w-full accent-brand-600"
                    />
                  </label>
                  <button
                    type="button"
                    onClick={() => setAdjust({ rotY: 0, offsetX: 0, offsetY: 0, scale: 1 })}
                    className="text-[11px] font-bold text-ink-500 hover:text-brand-700"
                  >
                    Reset alignment
                  </button>
                </div>
                <div className="blueprint-grid h-60 overflow-hidden rounded-lg border border-ink-800 bg-ink-950">
                  <SafeBoundary
                    label="article-3d-preview"
                    height="100%"
                    fallback={
                      <SoftBall
                        className="h-full w-full"
                        panelStyle={draft.panelStyle}
                        colors={draft.colors}
                        artworkUrl={draft.artworkUrl}
                        designSvgUrl={draft.designSvgUrl}
                        seamStyle={draft.seamStyle}
                        label={`${draft.panelCount}`}
                        autoRotate={false}
                      />
                    }
                  >
                  <BallViewer
                    className="h-full w-full"
                    panelStyle={draft.panelStyle}
                    colors={draft.colors}
                    artworkUrl={draft.artworkUrl}
                    designSvgUrl={draft.designSvgUrl}
                    modelUrl={draft.modelUrl}
                    modelAdjust={adjust}
                    renderUrl={draft.renderUrl}
                    seamStyle={draft.seamStyle}
                    label={`${draft.panelCount}`}
                    autoRotate={false}
                  />
                  </SafeBoundary>
                </div>
              </div>
            </div>
          )}

          <div className="rounded-xl border border-line bg-paper p-4">
            <p className="font-display text-[11px] font-extrabold uppercase tracking-widest text-ink-700">
              “Look inside” layer photos
            </p>
            <p className="mt-1 text-xs leading-relaxed text-ink-500">
              Add your own photos of the real components. When a buyer clicks <b>Look inside</b>, each exploded layer
              shows <b>this exact picture</b> with the description you write below it. Leave a photo empty to use the
              generated material look instead.
            </p>
            <div className="mt-3 grid gap-3 sm:grid-cols-2">
              {([
                ["cover", "Rexine cover (outside)"],
                ["foam", "Impact foam"],
                ["lining", "Fabric lining"],
                ["bladder", "Bladder"],
              ] as const).map(([key, title]) => (
                <div key={key} className="flex items-center gap-3 rounded-lg border border-line bg-card p-2.5">
                  <span className="grid h-12 w-12 shrink-0 place-items-center overflow-hidden rounded-md border border-line bg-paper text-[10px] font-bold text-ink-400">
                    {layerImagesDraft[key] ? (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img src={layerImagesDraft[key]!} alt={title} className="h-full w-full object-cover" />
                    ) : (
                      "none"
                    )}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="text-[11px] font-extrabold uppercase tracking-wider text-ink-600">{title}</p>
                    <div className="mt-1 flex items-center gap-2">
                      <label className="flex cursor-pointer items-center gap-1.5 rounded-md border border-line bg-paper px-2 py-1 text-[11px] font-bold text-ink-700 hover:border-brand-300">
                        <UploadCloud className="h-3 w-3" />
                        Upload
                        <input
                          type="file"
                          accept="image/*"
                          className="hidden"
                          onChange={(e) => pickInto(e.target.files?.[0], (url) => setLayerImage(key, url))}
                        />
                      </label>
                      {layerImagesDraft[key] && (
                        <button type="button" onClick={() => setLayerImage(key, null)} className="text-[11px] font-bold text-danger">
                          Remove
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="grid gap-3.5 sm:grid-cols-2">
            <Field label="Bladder description" hint="Shown on the exploded “Look inside” view.">
              <input
                className={inputCls}
                value={specsDraft.bladder}
                onChange={(e) => set("specs", { ...specsDraft, bladder: e.target.value })}
              />
            </Field>
            <Field label="Fabric lining description">
              <input
                className={inputCls}
                value={specsDraft.lining}
                onChange={(e) => set("specs", { ...specsDraft, lining: e.target.value })}
              />
            </Field>
            <Field label="Foam thickness (mm)">
              <input
                type="number"
                step="0.1"
                className={inputCls}
                value={specsDraft.foamMm}
                onChange={(e) => set("specs", { ...specsDraft, foamMm: Number(e.target.value) || 0 })}
              />
            </Field>
            <Field label="Cover note (optional)" hint="e.g. “1.05 mm gloss PU, 4-back lamination”.">
              <input
                className={inputCls}
                value={specsDraft.cover ?? ""}
                onChange={(e) => set("specs", { ...specsDraft, cover: e.target.value })}
              />
            </Field>
          </div>
          <div className="grid gap-3.5 sm:grid-cols-2">
            <Field label="CorelDRAW source file" hint="Attach the .CDR this design came from.">
              <select className={inputCls} value={draft.cdrUploadId ?? ""} onChange={(e) => set("cdrUploadId", e.target.value ? Number(e.target.value) : null)}>
                <option value="">— none —</option>
                {cdrs.map((u) => (
                  <option key={u.id} value={u.id}>{u.originalName}</option>
                ))}
              </select>
            </Field>
            <Field label="Status flags">
              <div className="pt-1.5">
                <Toggle checked={draft.featured} onChange={(v) => set("featured", v)} label="Featured on home page" />
              </div>
            </Field>
          </div>
          <Field label="Full-wrap artwork (export from CorelDRAW)" hint="Optional 2:1 image that wraps the whole ball — overrides the generated panel design.">
            <div className="flex items-center gap-3">
              <label className="flex cursor-pointer items-center gap-2 rounded-lg border border-line bg-paper px-3 py-2 text-xs font-bold text-ink-700 hover:border-brand-300">
                <UploadCloud className="h-4 w-4" />
                {uploading ? "Uploading…" : draft.artworkUrl ? "Replace artwork" : "Upload artwork image"}
                <input type="file" accept="image/*" className="hidden" onChange={(e) => pickArtwork(e.target.files?.[0])} />
              </label>
              {draft.artworkUrl && (
                <button onClick={() => set("artworkUrl", null)} className="text-xs font-bold text-danger">
                  Remove
                </button>
              )}
            </div>
          </Field>
        </div>

        <div className="space-y-3">
          <p className="text-[11px] font-extrabold uppercase tracking-wider text-ink-500">Live preview</p>
          <div className="grid place-items-center rounded-xl bg-paper p-4">
            <BallThumb
              panelStyle={draft.panelStyle}
              colors={draft.colors}
              artworkUrl={draft.artworkUrl}
              designSvgUrl={draft.designSvgUrl}
              seamStyle={draft.seamStyle}
              size={150}
            />
          </div>
          <p className="text-[11px] leading-relaxed text-ink-400">
            Buyers see this design in full 3D with every rexine material. The preview updates as you edit.
          </p>
        </div>
      </div>
      <div className="mt-6 flex justify-end gap-2 border-t border-line pt-4">
        <button onClick={onCancel} className="rounded-lg border border-line px-4 py-2.5 text-sm font-bold text-ink-600 hover:bg-paper">
          Cancel
        </button>
        <button
          onClick={() => onSave(draft)}
          className="rounded-lg bg-brand-600 px-5 py-2.5 text-sm font-extrabold text-white hover:bg-brand-500"
        >
          {isNew ? "Create article" : "Save changes"}
        </button>
      </div>
    </Modal>
  );
}

/* ================= MATERIALS ================= */

const EMPTY_MATERIAL: MaterialRow = {
  id: 0,
  code: "",
  name: "",
  finish: "Gloss PU",
  description: "",
  textureUrl: "",
  priceDelta: "0.00",
  thickness: "1.00 mm",
  weightGsm: 420,
  isActive: true,
  sortOrder: 99,
};

export function MaterialsTab({ notify }: { notify: Notify }) {
  const [rows, setRows] = useState<MaterialRow[]>([]);
  const [editing, setEditing] = useState<MaterialRow | null>(null);
  const [isNew, setIsNew] = useState(false);

  const load = useCallback(() => {
    api<{ rows: MaterialRow[] }>("GET", "materials").then((d) => setRows(d.rows));
  }, []);
  useEffect(load, [load]);

  const save = async (m: MaterialRow) => {
    const body = { ...m, priceDelta: Number(m.priceDelta), weightGsm: m.weightGsm ? Number(m.weightGsm) : null };
    try {
      if (isNew) await api("POST", "materials", body);
      else await api("PATCH", "materials", { id: m.id, data: body });
      notify(isNew ? "Material added to the library" : "Material saved");
      setEditing(null);
      load();
    } catch (e) {
      notify((e as Error).message, "err");
    }
  };

  const remove = async (m: MaterialRow) => {
    if (!confirm(`Delete material "${m.name}"?`)) return;
    await api("DELETE", "materials", { id: m.id });
    notify("Material deleted");
    load();
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl font-black uppercase tracking-tight text-ink-950">Rexine materials</h1>
          <p className="text-sm text-ink-500">Photos, details and price adjustments — only admins can change these.</p>
        </div>
        <button
          onClick={() => { setEditing({ ...EMPTY_MATERIAL, code: `FS-RX-${String(rows.length + 1).padStart(2, "0")}` }); setIsNew(true); }}
          className="flex items-center gap-2 rounded-xl bg-brand-600 px-4 py-2.5 text-sm font-extrabold text-white hover:bg-brand-500"
        >
          <Plus className="h-4 w-4" /> New material
        </button>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {rows.map((m) => (
          <div key={m.id} className={cn("overflow-hidden rounded-2xl border bg-card", m.isActive ? "border-line" : "border-line opacity-60")}>
            <div className="relative h-28 bg-ink-100">
              {m.textureUrl ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={m.textureUrl} alt={m.name} className="h-full w-full object-cover" />
              ) : (
                <div className="grid h-full place-items-center text-xs font-bold text-ink-400">No photo yet</div>
              )}
              <span className="absolute right-2 top-2 rounded-md bg-black/60 px-2 py-1 text-[11px] font-extrabold text-white">
                +{formatMoney(m.priceDelta)}
              </span>
            </div>
            <div className="p-4">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <h3 className="text-sm font-extrabold text-ink-950">{m.name}</h3>
                  <p className="font-mono text-[11px] text-ink-400">{m.code}</p>
                </div>
                <Badge tone={m.isActive ? "ok" : "neutral"}>{m.isActive ? "active" : "hidden"}</Badge>
              </div>
              <p className="mt-1.5 text-xs text-ink-500">{m.finish} · {m.thickness}{m.weightGsm ? ` · ${m.weightGsm} gsm` : ""}</p>
              <div className="mt-3 flex gap-1.5">
                <button onClick={() => { setEditing(m); setIsNew(false); }} className="flex flex-1 items-center justify-center gap-1.5 rounded-lg border border-line py-2 text-xs font-bold text-ink-700 hover:border-ink-300">
                  <Pencil className="h-3.5 w-3.5" /> Edit
                </button>
                <button onClick={() => remove(m)} className="rounded-lg border border-line px-3 py-2 text-xs font-bold text-ink-500 hover:text-danger">
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {editing && (
        <MaterialForm material={editing} isNew={isNew} onCancel={() => setEditing(null)} onSave={save} />
      )}
    </div>
  );
}

function MaterialForm({
  material,
  isNew,
  onCancel,
  onSave,
}: {
  material: MaterialRow;
  isNew: boolean;
  onCancel: () => void;
  onSave: (m: MaterialRow) => void;
}) {
  const [draft, setDraft] = useState<MaterialRow>({ ...material });
  const [uploading, setUploading] = useState(false);
  const set = <K extends keyof MaterialRow>(k: K, v: MaterialRow[K]) => setDraft((d) => ({ ...d, [k]: v }));

  const pickTexture = async (file: File | undefined) => {
    if (!file) return;
    setUploading(true);
    try {
      const { url } = await uploadFile(file);
      set("textureUrl", url);
    } catch (e) {
      alert((e as Error).message);
    } finally {
      setUploading(false);
    }
  };

  return (
    <Modal title={isNew ? "New rexine material" : `Edit ${material.name}`} onClose={onCancel} wide>
      <div className="grid gap-5 sm:grid-cols-[1fr_190px]">
        <div className="space-y-3.5">
          <div className="grid gap-3.5 sm:grid-cols-2">
            <Field label="Code">
              <input className={inputCls} value={draft.code} onChange={(e) => set("code", e.target.value)} />
            </Field>
            <Field label="Name">
              <input className={inputCls} value={draft.name} onChange={(e) => set("name", e.target.value)} />
            </Field>
          </div>
          <Field label="Finish">
            <input className={inputCls} value={draft.finish} onChange={(e) => set("finish", e.target.value)} placeholder="Gloss PU / Matte TPU / Dimple grip…" />
          </Field>
          <Field label="Detail for buyers" hint="Shown under the material picker in the catalog.">
            <textarea rows={3} className={inputCls} value={draft.description} onChange={(e) => set("description", e.target.value)} />
          </Field>
          <div className="grid gap-3.5 sm:grid-cols-3">
            <Field label="Price adjustment (USD)" hint="Added to every article price.">
              <input type="number" step="0.05" className={inputCls} value={draft.priceDelta} onChange={(e) => set("priceDelta", e.target.value)} />
            </Field>
            <Field label="Thickness">
              <input className={inputCls} value={draft.thickness} onChange={(e) => set("thickness", e.target.value)} />
            </Field>
            <Field label="Weight (gsm)">
              <input type="number" className={inputCls} value={draft.weightGsm ?? ""} onChange={(e) => set("weightGsm", e.target.value ? Number(e.target.value) : null)} />
            </Field>
          </div>
          <div className="flex flex-wrap items-center gap-5">
            <Toggle checked={draft.isActive} onChange={(v) => set("isActive", v)} label="Active in catalog" />
            <label className="flex cursor-pointer items-center gap-2 rounded-lg border border-line bg-paper px-3 py-2 text-xs font-bold text-ink-700 hover:border-brand-300">
              <UploadCloud className="h-4 w-4" />
              {uploading ? "Uploading…" : "Upload texture photo"}
              <input type="file" accept="image/*" className="hidden" onChange={(e) => pickTexture(e.target.files?.[0])} />
            </label>
          </div>
        </div>
        <div>
          <p className="mb-2 text-[11px] font-extrabold uppercase tracking-wider text-ink-500">Texture preview</p>
          <div className="h-36 overflow-hidden rounded-xl border border-line bg-paper-deep">
            {draft.textureUrl ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={draft.textureUrl} alt="texture" className="h-full w-full object-cover" />
            ) : (
              <div className="grid h-full place-items-center text-xs text-ink-400">No photo</div>
            )}
          </div>
          <p className="mt-2 text-[11px] leading-relaxed text-ink-400">
            Macro close-ups work best — this image is wrapped onto the 3D ball as well.
          </p>
        </div>
      </div>
      <div className="mt-6 flex justify-end gap-2 border-t border-line pt-4">
        <button onClick={onCancel} className="rounded-lg border border-line px-4 py-2.5 text-sm font-bold text-ink-600 hover:bg-paper">Cancel</button>
        <button onClick={() => onSave(draft)} className="rounded-lg bg-brand-600 px-5 py-2.5 text-sm font-extrabold text-white hover:bg-brand-500">
          {isNew ? "Add material" : "Save changes"}
        </button>
      </div>
    </Modal>
  );
}

/* ================= DESIGN FILES (CDR) ================= */

export function DesignFilesTab({ notify }: { notify: Notify }) {
  const [rows, setRows] = useState<UploadRow[]>([]);
  const [articlesRows, setArticlesRows] = useState<ArticleRow[]>([]);
  const [dragOver, setDragOver] = useState(false);
  const [busy, setBusy] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const load = useCallback(() => {
    api<{ rows: UploadRow[] }>("GET", "uploads").then((d) => setRows(d.rows));
    api<{ rows: ArticleRow[] }>("GET", "articles").then((d) => setArticlesRows(d.rows));
  }, []);
  useEffect(load, [load]);

  const handleFiles = async (files: FileList | null) => {
    if (!files || files.length === 0) return;
    setBusy(true);
    try {
      for (const f of Array.from(files)) {
        await uploadFile(f);
      }
      notify("Design file received — added to the pipeline");
      load();
    } catch (e) {
      notify((e as Error).message, "err");
    } finally {
      setBusy(false);
    }
  };

  const patch = async (id: number, data: Record<string, unknown>) => {
    await api("PATCH", "uploads", { id, data });
    load();
  };

  const remove = async (u: UploadRow) => {
    if (!confirm(`Delete ${u.originalName}?`)) return;
    await api("DELETE", "uploads", { id: u.id });
    notify("File deleted");
    load();
  };

  const designFiles = rows.filter((u) => u.kind === "design-file");

  return (
    <div className="space-y-5">
      <div>
        <h1 className="font-display text-2xl font-black uppercase tracking-tight text-ink-950">CorelDRAW files</h1>
        <p className="text-sm text-ink-500">Your designer&apos;s artwork pipeline — from raw .CDR to live 3D in the catalog.</p>
      </div>

      <div className="grid gap-3 rounded-2xl border border-line bg-card p-5 text-xs text-ink-500 sm:grid-cols-3">
        {[
          ["1 · Upload", "Drop the .CDR (or .AI / .EPS / .PDF) here. It is stored safely and tracked with a status."],
          ["2 · Export wrap", "Export a 2:1 full-wrap artwork (PNG/JPG) from CorelDRAW and attach it to the article in the Articles tab."],
          ["3 · Goes live", "The moment artwork is attached, buyers see that exact design wrapped around the ball in 3D."],
        ].map(([t, b]) => (
          <div key={t}>
            <p className="font-display text-[11px] font-extrabold uppercase tracking-widest text-brand-700">{t}</p>
            <p className="mt-1 leading-relaxed">{b}</p>
          </div>
        ))}
      </div>

      <div
        onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
        onDragLeave={() => setDragOver(false)}
        onDrop={(e) => { e.preventDefault(); setDragOver(false); handleFiles(e.dataTransfer.files); }}
        className={cn(
          "flex cursor-pointer flex-col items-center justify-center gap-2 rounded-2xl border-2 border-dashed px-6 py-10 text-center transition",
          dragOver ? "border-brand-500 bg-brand-50" : "border-ink-200 bg-card hover:border-brand-300"
        )}
        onClick={() => inputRef.current?.click()}
      >
        <FilePlus2 className="h-7 w-7 text-brand-600" />
        <p className="text-sm font-extrabold text-ink-900">{busy ? "Uploading…" : "Drop CorelDRAW files here or click to browse"}</p>
        <p className="text-[11px] text-ink-400">.cdr · .ai · .eps · .pdf — up to 25 MB each</p>
        <input ref={inputRef} type="file" multiple accept=".cdr,.ai,.eps,.pdf" className="hidden" onChange={(e) => handleFiles(e.target.files)} />
      </div>

      {designFiles.length === 0 ? (
        <p className="rounded-xl border border-line bg-card p-8 text-center text-sm text-ink-400">
          No design files yet. Upload the first .CDR above.
        </p>
      ) : (
        <div className="overflow-x-auto rounded-2xl border border-line bg-card">
          <table className="w-full min-w-[860px] text-left text-sm">
            <thead>
              <tr className="border-b border-line bg-paper text-[10px] uppercase tracking-wider text-ink-400">
                {["File", "Size", "Status", "Linked article", ""].map((h, i) => (
                  <th key={i} className="px-4 py-3 font-extrabold">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-line">
              {designFiles.map((u) => (
                <tr key={u.id} className="hover:bg-paper/60">
                  <td className="px-4 py-3">
                    <p className="font-bold text-ink-900">{u.originalName}</p>
                    <p className="text-[11px] text-ink-400">{new Date(u.createdAt).toLocaleString()}</p>
                  </td>
                  <td className="px-4 py-3 text-xs">{bytes(u.size)}</td>
                  <td className="px-4 py-3">
                    <select
                      value={u.status}
                      onChange={(e) => patch(u.id, { status: e.target.value })}
                      className={cn(
                        "rounded-lg border px-2 py-1.5 text-xs font-bold outline-none",
                        u.status === "received" && "border-line bg-paper text-ink-700",
                        u.status === "in-review" && "border-warn/40 bg-warn-soft text-warn",
                        (u.status === "ready" || u.status === "linked") && "border-ok/40 bg-ok-soft text-ok"
                      )}
                    >
                      {["received", "in-review", "ready", "linked"].map((s) => (
                        <option key={s} value={s}>{s}</option>
                      ))}
                    </select>
                  </td>
                  <td className="px-4 py-3">
                    <select
                      value={u.articleId ?? ""}
                      onChange={(e) => patch(u.id, { articleId: e.target.value ? Number(e.target.value) : null })}
                      className="w-48 rounded-lg border border-line bg-paper px-2 py-1.5 text-xs font-bold text-ink-700 outline-none"
                    >
                      <option value="">— not linked —</option>
                      {articlesRows.map((a) => (
                        <option key={a.id} value={a.id}>{a.articleNo} · {a.name}</option>
                      ))}
                    </select>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex justify-end gap-1.5">
                      <a href={`/api/files/${u.storedName}`} download className="rounded-lg border border-line p-2 text-ink-500 hover:text-ink-900" title="Download">
                        <Download className="h-3.5 w-3.5" />
                      </a>
                      <button onClick={() => remove(u)} className="rounded-lg border border-line p-2 text-ink-500 hover:text-danger" title="Delete">
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

/* ================= COMPLIANCE ================= */

export function ComplianceTab({ notify }: { notify: Notify }) {
  const [rows, setRows] = useState<ComplianceRow[]>([]);
  const [editing, setEditing] = useState<ComplianceRow | null>(null);
  const [isNew, setIsNew] = useState(false);

  const load = useCallback(() => {
    api<{ rows: ComplianceRow[] }>("GET", "compliance").then((d) => setRows(d.rows));
  }, []);
  useEffect(load, [load]);

  const save = async (c: ComplianceRow) => {
    try {
      if (isNew) await api("POST", "compliance", c);
      else await api("PATCH", "compliance", { id: c.id, data: c });
      notify("Compliance record saved");
      setEditing(null);
      load();
    } catch (e) {
      notify((e as Error).message, "err");
    }
  };

  const quickStatus = async (c: ComplianceRow, status: string) => {
    await api("PATCH", "compliance", { id: c.id, data: { status } });
    load();
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl font-black uppercase tracking-tight text-ink-950">Compliance radar</h1>
          <p className="text-sm text-ink-500">Standards the catalog shows buyers — with review dates so nothing goes stale.</p>
        </div>
        <button
          onClick={() => {
            setEditing({ id: 0, title: "", standard: "", detail: "", status: "in-progress", nextReview: "", sortOrder: rows.length + 1 });
            setIsNew(true);
          }}
          className="flex items-center gap-2 rounded-xl bg-brand-600 px-4 py-2.5 text-sm font-extrabold text-white hover:bg-brand-500"
        >
          <Plus className="h-4 w-4" /> Add standard
        </button>
      </div>

      <div className="space-y-3">
        {rows.map((c) => (
          <div key={c.id} className="flex flex-wrap items-center gap-4 rounded-xl border border-line bg-card p-4">
            <span
              className={cn(
                "h-2.5 w-2.5 shrink-0 rounded-full",
                c.status === "compliant" ? "bg-ok" : c.status === "attention" ? "bg-danger" : "bg-warn"
              )}
            />
            <div className="min-w-0 flex-1">
              <p className="text-sm font-extrabold text-ink-950">{c.title}</p>
              <p className="text-xs text-ink-400">{c.standard}{c.nextReview ? ` · next review ${c.nextReview}` : ""}</p>
            </div>
            <select
              value={c.status}
              onChange={(e) => quickStatus(c, e.target.value)}
              className="rounded-lg border border-line bg-paper px-2 py-1.5 text-xs font-bold text-ink-700 outline-none"
            >
              {["compliant", "in-progress", "attention"].map((s) => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>
            <button onClick={() => { setEditing(c); setIsNew(false); }} className="rounded-lg border border-line p-2 text-ink-500 hover:text-ink-900">
              <Pencil className="h-3.5 w-3.5" />
            </button>
            <button
              onClick={async () => {
                if (!confirm(`Delete "${c.title}"?`)) return;
                await api("DELETE", "compliance", { id: c.id });
                load();
              }}
              className="rounded-lg border border-line p-2 text-ink-500 hover:text-danger"
            >
              <Trash2 className="h-3.5 w-3.5" />
            </button>
          </div>
        ))}
      </div>

      {editing && (
        <Modal title={isNew ? "Add compliance standard" : "Edit standard"} onClose={() => setEditing(null)}>
          <div className="space-y-3.5">
            <Field label="Title">
              <input className={inputCls} value={editing.title} onChange={(e) => setEditing({ ...editing, title: e.target.value })} />
            </Field>
            <div className="grid gap-3.5 sm:grid-cols-2">
              <Field label="Standard">
                <input className={inputCls} value={editing.standard} onChange={(e) => setEditing({ ...editing, standard: e.target.value })} />
              </Field>
              <Field label="Next review (YYYY-MM-DD)">
                <input type="date" className={inputCls} value={editing.nextReview} onChange={(e) => setEditing({ ...editing, nextReview: e.target.value })} />
              </Field>
            </div>
            <Field label="Detail" hint="Test parameters, audit scope — what a buyer or auditor should know.">
              <textarea rows={3} className={inputCls} value={editing.detail} onChange={(e) => setEditing({ ...editing, detail: e.target.value })} />
            </Field>
            <div className="flex justify-end gap-2 border-t border-line pt-4">
              <button onClick={() => setEditing(null)} className="rounded-lg border border-line px-4 py-2.5 text-sm font-bold text-ink-600 hover:bg-paper">Cancel</button>
              <button onClick={() => save(editing)} className="rounded-lg bg-brand-600 px-5 py-2.5 text-sm font-extrabold text-white hover:bg-brand-500">Save</button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}
