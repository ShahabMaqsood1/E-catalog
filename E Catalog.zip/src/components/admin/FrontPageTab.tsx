"use client";

import { useCallback, useEffect, useState } from "react";
import { ArrowDown, ArrowUp, Plus, Trash2 } from "lucide-react";
import BallThumb from "@/components/BallThumb";
import { api, Field, inputCls } from "@/components/admin/ui";
import type { ArticleRow, MaterialRow } from "@/components/admin/AdminEditors";

type Preset = { label: string; articleNo: string; materialCode: string };

type Notify = (msg: string, kind?: "ok" | "err") => void;

/** Admin control for the three samples shown in the home-page Live 3D hero */
export default function FrontPageTab({ notify }: { notify: Notify }) {
  const [presets, setPresets] = useState<Preset[]>([]);
  const [arts, setArts] = useState<ArticleRow[]>([]);
  const [mats, setMats] = useState<MaterialRow[]>([]);
  const [loaded, setLoaded] = useState(false);
  const [saving, setSaving] = useState(false);

  const load = useCallback(() => {
    Promise.all([
      api<Record<string, unknown>>("GET", "settings"),
      api<{ rows: ArticleRow[] }>("GET", "articles"),
      api<{ rows: MaterialRow[] }>("GET", "materials"),
    ])
      .then(([settings, a, m]) => {
        const raw = (settings.heroPresets as Preset[] | undefined) ?? [];
        setPresets(
          raw.map((p) => ({
            label: String(p.label ?? ""),
            articleNo: String(p.articleNo ?? ""),
            materialCode: String(p.materialCode ?? ""),
          }))
        );
        setArts(a.rows.filter((r) => r.status === "live"));
        setMats(m.rows);
        setLoaded(true);
      })
      .catch((e) => {
        notify((e as Error).message, "err");
        setLoaded(true);
      });
  }, [notify]);

  useEffect(() => {
    load();
  }, [load]);

  const update = (i: number, patch: Partial<Preset>) =>
    setPresets((list) => list.map((p, idx) => (idx === i ? { ...p, ...patch } : p)));
  const move = (i: number, dir: -1 | 1) =>
    setPresets((list) => {
      const next = [...list];
      const j = i + dir;
      if (j < 0 || j >= next.length) return list;
      [next[i], next[j]] = [next[j], next[i]];
      return next;
    });

  const save = async () => {
    setSaving(true);
    try {
      await api("POST", "settings", { key: "heroPresets", value: presets });
      notify("Front-page samples saved — live on the home page");
    } catch (e) {
      notify((e as Error).message, "err");
    } finally {
      setSaving(false);
    }
  };

  if (!loaded) {
    return <div className="animate-pulse rounded-xl border border-line bg-card p-10 text-sm text-ink-400">Loading…</div>;
  }

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl font-black uppercase tracking-tight text-ink-950">Front-page samples</h1>
          <p className="text-sm text-ink-500">
            The balls shown in the home-page Live 3D hero (Match White, Carbon Edition, Lava TPU…). Each sample is a
            real article + rexine combination, so the hero always matches the catalog.
          </p>
        </div>
        <button
          onClick={() =>
            setPresets((p) => [
              ...p,
              { label: "New sample", articleNo: arts[0]?.articleNo ?? "", materialCode: mats[0]?.code ?? "" },
            ])
          }
          className="flex items-center gap-2 rounded-xl bg-brand-600 px-4 py-2.5 text-sm font-extrabold text-white hover:bg-brand-500"
        >
          <Plus className="h-4 w-4" /> Add sample
        </button>
      </div>

      {presets.length === 0 ? (
        <div className="rounded-xl border border-line bg-card p-10 text-center text-sm text-ink-400">
          No samples yet — add your first one. The hero falls back to a default ball until then.
        </div>
      ) : (
        <div className="space-y-3">
          {presets.map((p, i) => {
            const art = arts.find((a) => a.articleNo === p.articleNo);
            const mat = mats.find((m) => m.code === p.materialCode);
            return (
              <div key={i} className="flex flex-wrap items-center gap-4 rounded-2xl border border-line bg-card p-4">
                <div className="grid h-20 w-20 shrink-0 place-items-center rounded-xl bg-paper">
                  {art ? (
                    <BallThumb
                      panelStyle={art.panelStyle}
                      colors={art.colors}
                      artworkUrl={art.artworkUrl}
                      designSvgUrl={art.designSvgUrl}
                      seamStyle={art.seamStyle}
                      rexineUrl={mat?.textureUrl}
                      size={72}
                    />
                  ) : (
                    <span className="text-[10px] font-bold text-ink-400">pick article</span>
                  )}
                </div>
                <div className="min-w-[220px] flex-1 space-y-2.5">
                  <Field label={`Sample ${i + 1} — button label`}>
                    <input className={inputCls} value={p.label} onChange={(e) => update(i, { label: e.target.value })} />
                  </Field>
                  <div className="grid gap-2.5 sm:grid-cols-2">
                    <Field label="Article">
                      <select
                        className={inputCls}
                        value={p.articleNo}
                        onChange={(e) => update(i, { articleNo: e.target.value })}
                      >
                        <option value="">— select —</option>
                        {arts.map((a) => (
                          <option key={a.id} value={a.articleNo}>
                            {a.articleNo} · {a.name}
                          </option>
                        ))}
                      </select>
                    </Field>
                    <Field label="Rexine shown">
                      <select
                        className={inputCls}
                        value={p.materialCode}
                        onChange={(e) => update(i, { materialCode: e.target.value })}
                      >
                        <option value="">— select —</option>
                        {mats.map((m) => (
                          <option key={m.id} value={m.code}>
                            {m.code} · {m.name}
                          </option>
                        ))}
                      </select>
                    </Field>
                  </div>
                </div>
                <div className="flex shrink-0 items-center gap-1.5">
                  <button onClick={() => move(i, -1)} className="rounded-lg border border-line p-2 text-ink-500 hover:text-ink-900" title="Move up">
                    <ArrowUp className="h-3.5 w-3.5" />
                  </button>
                  <button onClick={() => move(i, 1)} className="rounded-lg border border-line p-2 text-ink-500 hover:text-ink-900" title="Move down">
                    <ArrowDown className="h-3.5 w-3.5" />
                  </button>
                  <button
                    onClick={() => setPresets((list) => list.filter((_, idx) => idx !== i))}
                    className="rounded-lg border border-line p-2 text-ink-500 hover:text-danger"
                    title="Remove"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <div className="flex items-center justify-between gap-3 rounded-xl border border-line bg-card p-4">
        <p className="text-xs text-ink-500">
          Each sample inherits the article&apos;s 3D model / render, vector panel map, seam style, interior specs and
          layer photos — including the <b>Look inside</b> button on the home page.
        </p>
        <button
          onClick={save}
          disabled={saving}
          className="shrink-0 rounded-xl bg-brand-600 px-6 py-3 font-display text-sm font-extrabold uppercase tracking-widest text-white hover:bg-brand-500 disabled:opacity-60"
        >
          {saving ? "Saving…" : "Save samples"}
        </button>
      </div>
    </div>
  );
}
