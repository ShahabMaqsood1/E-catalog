export type TourDemo =
  | "open-studio" // mobile: open the configurator drawer
  | "select-featured" // load a featured article into the 3D studio
  | "next-article" // jump to the next article in the list
  | "cycle-material" // switch to the next rexine material
  | "look-inside" // exploded construction view ON
  | "close-up" // damped close-up zoom ON
  | "reset-view" // back to the normal studio view
  | "hero-next"; // home hero: rotate to the next sample

export type TourStep = {
  target: string; // CSS selector of the anchor element
  title: string;
  body: string;
  placement?: "top" | "bottom" | "left" | "right";
  /** "Try it yourself" hint shown under the body */
  tip?: string;
  /** Action the app performs when this step opens — the tour DEMONSTRATES itself */
  demo?: TourDemo;
  /** Chapter label shown in the tour overview list */
  chapter?: string;
};

export type TourId = "home" | "catalog" | "contact" | "admin";

export const TOUR_META: Record<TourId, { title: string; intro: string; minutes: string }> = {
  home: {
    title: "Welcome to the Forward Sports e-catalog",
    intro:
      "This site is the digital showroom for the Forward Sports ball range: live 3D previews, real rexine materials and instant FOB pricing. The full company profile — factory, team, certifications — lives at forward.pk.",
    minutes: "2 min",
  },
  catalog: {
    title: "Configure a ball in 3D",
    intro:
      "One page, every construction. The tour drives the configurator for you: it loads an article, opens the ball up, swaps the rexine and shows the live price — then you take over.",
    minutes: "3 min",
  },
  contact: {
    title: "Talk to the sales team",
    intro:
      "Every enquiry and quote request goes straight to the Forward Sports sales inbox. Here is how the form works and what happens after you press send.",
    minutes: "1 min",
  },
  admin: {
    title: "Admin studio",
    intro:
      "Everything on the public site is edited here: articles and 3D models, rexine materials and photos, the front page, every line of copy, the sales inbox, the mail server and the media folders that hold your files.",
    minutes: "4 min",
  },
};

export const TOURS: Record<TourId, TourStep[]> = {
  home: [
    {
      target: "[data-tour=brand]",
      chapter: "Who we are",
      title: "Forward Sports — product catalog",
      body: "This is the catalog site only: articles, materials, 3D previews and quotes. The red forward.pk button opens the main company website with the factory, the team, certifications and CSR.",
      tip: "Click forward.pk any time to see the full company profile.",
      placement: "bottom",
    },
    {
      target: "[data-tour=hero-ball]",
      chapter: "Live 3D",
      title: "The 3D hero — real geometry, real materials",
      body: "Each sample here is rendered live in your browser from the article's own 3D model, with its own rexine material. Drag to spin it, scroll to zoom into the grain, and use the studio buttons to open the ball up.",
      tip: "Drag the ball now — it keeps spinning where you let go.",
      placement: "left",
      demo: "hero-next",
    },
    {
      target: "[data-tour=categories]",
      chapter: "The range",
      title: "Seven construction families",
      body: "Thermal bonded, hand-stitched, machine-stitched, hybrid, AMB / mini, volleyballs and medicine balls. Every article in the catalog belongs to one of them, each with its own panel construction, specs and price band.",
      placement: "top",
    },
    {
      target: "[data-tour=featured]",
      chapter: "Featured",
      title: "Featured articles",
      body: "Articles marked Featured in the dashboard appear here AND rotate in the 3D hero above — that is the fastest way to push a new design to the front of the catalog.",
      placement: "top",
    },
    {
      target: "[data-tour=how-it-works]",
      chapter: "How to buy",
      title: "Pick → configure → quote",
      body: "Open the catalog, choose an article, select the rexine and quantity, then send the quote request. It lands directly with the sales team with your whole configuration attached.",
      placement: "top",
    },
    {
      target: "[data-tour=tour-button]",
      chapter: "Replay",
      title: "Replay the tour any time",
      body: "This button starts the guided tour on every page — and on the catalog page it actually operates the 3D studio while it explains each control.",
      placement: "bottom",
    },
  ],

  catalog: [
    {
      target: "[data-tour=article-list]",
      chapter: "1 · The list",
      title: "Every article, on one page",
      body: "The left column is the whole catalog grouped by construction family — article number, panel count, MOQ, description and the FOB price range for that article. Use the chips at the top to jump to a family.",
      tip: "This column scrolls on its own; the 3D studio on the right stays exactly where it is.",
      placement: "right",
      demo: "open-studio",
    },
    {
      target: "[data-tour=studio-rail]",
      chapter: "2 · The studio",
      title: "The 3D studio is pinned on the right",
      body: "The right column never scrolls away with the page. It holds the live 3D view, the rexine picker, the logo placement, the price and the quote button. Put your cursor inside it and scroll to move through its controls.",
      tip: "Watch: the tour is loading a featured article into the studio now.",
      placement: "left",
      demo: "select-featured",
    },
    {
      target: "[data-tour=viewer]",
      chapter: "3 · The 3D view",
      title: "Drag, zoom, spin",
      body: "The ball renders from its own 3D model with the designer's artwork baked in, plus the selected rexine's grain, sheen and colour. Drag to rotate, scroll to zoom right into the texture, and pause the turntable whenever you want.",
      tip: "Drag it — the spin pauses while you hold it and resumes after a second.",
      placement: "left",
      demo: "close-up",
    },
    {
      target: "[data-tour=look-inside]",
      chapter: "4 · Look inside",
      title: "Exploded construction view",
      body: "This separates the ball into its four real layers — rexine cover, impact foam, fabric lining and bladder — with the thickness of each. Click a layer to focus it; the others dim so buyers can see exactly what they are buying.",
      tip: "The tour just opened it. Click a layer label to focus that layer.",
      placement: "top",
      demo: "look-inside",
    },
    {
      target: "[data-tour=materials]",
      chapter: "5 · Rexine materials",
      title: "Pick a material — the ball changes",
      body: "Each material has its own photo, finish, thickness, weight and price adjustment. Selecting one re-skins the ball: the grain relief, the sheen and the colour all come from your photo of that exact material, and the price updates instantly.",
      tip: "Watch the grain and colour change as the tour switches material.",
      placement: "left",
      demo: "cycle-material",
    },
    {
      target: "[data-tour=logo]",
      chapter: "6 · Your logo",
      title: "Logo placement",
      body: "Type a buyer's logo or brand name and choose where it sits on the wrap — the preview prints it on the ball so they can approve the look before sampling.",
      placement: "left",
      demo: "reset-view",
    },
    {
      target: "[data-tour=price]",
      chapter: "7 · Live price",
      title: "FOB pricing recalculates constantly",
      body: "Unit price = article base price + the rexine adjustment, then the volume discount tier for the quantity entered. Everything updates the moment a buyer changes any choice.",
      placement: "left",
    },
    {
      target: "[data-tour=quote]",
      chapter: "8 · Request a quote",
      title: "One click packages the whole configuration",
      body: "The quote request carries the article, the rexine, the quantity, the logo and the buyer's details straight to the sales team's inbox — and it is stored in the dashboard so nothing is ever lost.",
      tip: "Press it to see the form; nothing is sent until you submit.",
      placement: "top",
    },
  ],

  contact: [
    {
      target: "[data-tour=contact-details]",
      chapter: "Who you reach",
      title: "Direct to the sales team",
      body: "Both addresses below are real Forward Sports sales contacts, and the phone number rings the factory in Sialkot. Every message from this site is delivered to both e-mail addresses at once.",
      placement: "left",
    },
    {
      target: "[data-tour=contact-form]",
      chapter: "The form",
      title: "Send an enquiry",
      body: "Name, e-mail and a message are enough. Add a phone number or company if you want a call back, and mention the article number if you already know it — the configurator's quote button fills that in for you.",
      tip: "Fill it in and press send; you get a confirmation reference immediately.",
      placement: "left",
    },
    {
      target: "[data-tour=contact-after]",
      chapter: "What happens next",
      title: "Stored, then answered",
      body: "Each message is written to the dashboard inbox first and e-mailed second, so even if the mail server is being set up nothing is lost. Sales answers within one working day with pricing, sampling options and lead times.",
      placement: "top",
    },
  ],

  admin: [
    {
      target: "[data-tour=tab-overview]",
      chapter: "Overview",
      title: "Overview & insights",
      body: "Live counters plus suggestions generated from buyer behaviour — popular rexines, pricing gaps and reviews that are due.",
      placement: "right",
    },
    {
      target: "[data-tour=tab-articles]",
      chapter: "Articles",
      title: "Articles & 3D models",
      body: "Add or edit any article: price, MOQ, panel style, colours, interior specs, layer photos and the baked-artwork 3D model (.glb). Uploading a model here makes it live in the catalog immediately.",
      placement: "right",
    },
    {
      target: "[data-tour=tab-materials]",
      chapter: "Rexine",
      title: "Rexine materials",
      body: "Upload a photo of each real material, set the finish, thickness, weight and price adjustment. That single photo drives the picker chip, the 3D grain and the colour of the ball.",
      placement: "right",
    },
    {
      target: "[data-tour=tab-front-page]",
      chapter: "Front page",
      title: "Front-page hero samples",
      body: "Choose which articles and rexines rotate in the home-page 3D hero. Anything marked Featured is added automatically.",
      placement: "right",
    },
    {
      target: "[data-tour=tab-content]",
      chapter: "Copy",
      title: "Every line of text on the site",
      body: "Headings, paragraphs, buttons and footer lines — all editable here and live on save. Clear a field to fall back to the built-in default.",
      placement: "right",
    },
    {
      target: "[data-tour=tab-inbox]",
      chapter: "Inbox & mail",
      title: "Sales inbox, contacts and the mail server",
      body: "Every contact message and quote request lands here. This tab is also where the two sales e-mail addresses, the phone number and the outgoing SMTP mailbox (for example no-reply@forward.pk) are configured — no code changes needed.",
      placement: "right",
    },
    {
      target: "[data-tour=tab-media]",
      chapter: "Media & files",
      title: "Your files live inside the project",
      body: "Rexine photos, 3D models, renders, layer photos and design files are stored in separate folders inside the project (public/media/…). You can upload here, or paste an external link and the system downloads a copy into the project so it never depends on another website.",
      placement: "right",
    },
    {
      target: "[data-tour=tab-settings]",
      chapter: "Settings & security",
      title: "Settings, currency and dashboard security",
      body: "Company details, currency, MOQ, volume tiers — and the dashboard password. The password is stored hashed, must be strong, and changing it signs every device out.",
      placement: "right",
    },
  ],
};
