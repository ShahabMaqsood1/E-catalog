import { createHash, randomBytes, scryptSync, timingSafeEqual } from "crypto";
import { cookies } from "next/headers";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { settings } from "@/db/schema";

/**
 * Admin authentication — strong password, hashed at rest, changeable from the
 * dashboard, with brute-force lockout.
 *
 * The password is NEVER stored in plain text: a `settings.adminCredential` row
 * holds `{salt, hash(scrypt), epoch, updatedAt, source}`. The session cookie is
 * derived from salt+hash+epoch, so changing the password (or pressing "sign out
 * everywhere") instantly invalidates every existing session.
 *
 * Bootstrap: on first boot the credential is created from `ADMIN_PASSWORD` in
 * `.env` when that value is strong enough; otherwise a strong password is
 * generated and printed ONCE in the server log. Either way it can be changed
 * afterwards in Admin → Settings → Dashboard security (stored in the DB, so it
 * survives restarts and does not need the env file).
 */

export const ADMIN_COOKIE = "fs_admin_token";
export const MIN_PASSWORD_LENGTH = 12;
export const MAX_FAILS = 6;
export const LOCK_MINUTES = 15;

/** Legacy export kept for compatibility — the real source of truth is the DB. */
export const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "";
export const DEMO_MODE = false;

export type AdminCredential = {
  salt: string;
  hash: string;
  epoch: number;
  updatedAt: string;
  source: string;
};

type LoginGuard = { fails: number; lockedUntil: string | null; lastFailAt: string | null; lastOkAt: string | null };

const GUARD_KEY = "loginGuard";
const CRED_KEY = "adminCredential";

/* ------------------------------------------------------------ helpers ---- */

async function readSetting<T>(key: string): Promise<T | null> {
  try {
    const row = await db.query.settings.findFirst({ where: eq(settings.key, key) });
    return row ? (row.value as T) : null;
  } catch {
    return null;
  }
}

async function writeSetting(key: string, value: unknown) {
  await db
    .insert(settings)
    .values({ key, value: value as never })
    .onConflictDoUpdate({ target: settings.key, set: { value: value as never } });
}

function scrypt(password: string, salt: string): string {
  return scryptSync(password, salt, 32, { N: 16384, r: 8, p: 1 }).toString("hex");
}

export function sessionToken(cred: AdminCredential): string {
  return createHash("sha256").update(`fs-admin|${cred.salt}|${cred.hash}|${cred.epoch}`).digest("hex");
}

/** Kept for any legacy caller — not used for sessions any more. */
export function tokenFor(password: string): string {
  return createHash("sha256").update(`forward:${password}`).digest("hex");
}

export function generateStrongPassword(): string {
  const upper = "ABCDEFGHJKLMNPQRSTUVWXYZ";
  const lower = "abcdefghijkmnopqrstuvwxyz";
  const digits = "23456789";
  const symbols = "!@#$%&*+-?";
  const all = upper + lower + digits + symbols;
  const pick = (s: string, n: number) => {
    let out = "";
    const bytes = randomBytes(n);
    for (let i = 0; i < n; i++) out += s[bytes[i] % s.length];
    return out;
  };
  const chars = (pick(upper, 3) + pick(lower, 6) + pick(digits, 3) + pick(symbols, 2) + pick(all, 6)).split("");
  // shuffle
  const rnd = randomBytes(chars.length);
  for (let i = chars.length - 1; i > 0; i--) {
    const j = rnd[i] % (i + 1);
    [chars[i], chars[j]] = [chars[j], chars[i]];
  }
  return chars.join("");
}

/** Rule list used by both the API and the dashboard strength meter. */
export function passwordIssues(pw: string): string[] {
  const issues: string[] = [];
  if (pw.length < MIN_PASSWORD_LENGTH) issues.push(`at least ${MIN_PASSWORD_LENGTH} characters (currently ${pw.length})`);
  if (!/[A-Z]/.test(pw)) issues.push("an uppercase letter");
  if (!/[a-z]/.test(pw)) issues.push("a lowercase letter");
  if (!/\d/.test(pw)) issues.push("a number");
  if (!/[^A-Za-z0-9]/.test(pw)) issues.push("a symbol (!@#$… )");
  if (/^(forward|catalog|admin|password|12345)/i.test(pw)) issues.push("not start with an obvious word (forward/admin/password…)");
  return issues;
}

export function passwordStrength(pw: string): { score: number; label: string; issues: string[] } {
  const issues = passwordIssues(pw);
  let score = 0;
  if (pw.length >= MIN_PASSWORD_LENGTH) score++;
  if (pw.length >= 18) score++;
  if (/[A-Z]/.test(pw) && /[a-z]/.test(pw)) score++;
  if (/\d/.test(pw)) score++;
  if (/[^A-Za-z0-9]/.test(pw)) score++;
  const label = issues.length ? "too weak" : score >= 5 ? "excellent" : score >= 4 ? "strong" : "acceptable";
  return { score, label, issues };
}

/* ------------------------------------------------------- credential mgmt ---- */

/** Returns the stored credential, creating it on first boot (env or generated). */
export async function getCredential(): Promise<AdminCredential | null> {
  const existing = await readSetting<AdminCredential>(CRED_KEY);
  if (existing?.salt && existing?.hash) return existing;

  const env = (process.env.ADMIN_PASSWORD || "").trim();
  let password = env;
  let source = "env";
  if (!password || passwordIssues(password).length) {
    password = generateStrongPassword();
    source = "generated";
    console.warn(
      `[admin-security] ADMIN_PASSWORD in .env is missing or too weak (needs ${MIN_PASSWORD_LENGTH}+ chars, upper/lower/number/symbol).\n` +
        `[admin-security] Generated a strong dashboard password: ${password}\n` +
        `[admin-security] Sign in at /admin and change it under Settings → Dashboard security.`
    );
  }
  const salt = randomBytes(16).toString("hex");
  const cred: AdminCredential = {
    salt,
    hash: scrypt(password, salt),
    epoch: 1,
    updatedAt: new Date().toISOString(),
    source,
  };
  try {
    await writeSetting(CRED_KEY, cred);
  } catch (err) {
    console.warn("[admin-security] could not persist credential:", (err as Error).message?.slice(0, 120));
    return null;
  }
  return cred;
}

export async function credentialInfo() {
  const cred = await getCredential();
  const guard = (await readSetting<LoginGuard>(GUARD_KEY)) ?? { fails: 0, lockedUntil: null, lastFailAt: null, lastOkAt: null };
  return {
    configured: !!cred,
    source: cred?.source ?? "unknown",
    updatedAt: cred?.updatedAt ?? "",
    epoch: cred?.epoch ?? 1,
    fails: guard.fails,
    lockedUntil: guard.lockedUntil && new Date(guard.lockedUntil).getTime() > Date.now() ? guard.lockedUntil : null,
    lastOkAt: guard.lastOkAt,
    minLength: MIN_PASSWORD_LENGTH,
  };
}

async function readGuard(): Promise<LoginGuard> {
  const g = await readSetting<LoginGuard>(GUARD_KEY);
  return g ?? { fails: 0, lockedUntil: null, lastFailAt: null, lastOkAt: null };
}

function safeEqual(a: string, b: string) {
  const ba = Buffer.from(a);
  const bb = Buffer.from(b);
  if (ba.length !== bb.length) return false;
  return timingSafeEqual(ba, bb);
}

export type LoginResult = { ok: true; token: string } | { ok: false; error: string; status: number; retryAfter?: number };

/** Verifies a password attempt with lockout protection. */
export async function verifyLogin(password: string): Promise<LoginResult> {
  const guard = await readGuard();
  if (guard.lockedUntil) {
    const until = new Date(guard.lockedUntil).getTime();
    if (until > Date.now()) {
      const mins = Math.ceil((until - Date.now()) / 60000);
      return {
        ok: false,
        status: 429,
        retryAfter: mins * 60,
        error: `Too many failed attempts. Dashboard locked for ${mins} more minute${mins === 1 ? "" : "s"}.`,
      };
    }
  }
  const cred = await getCredential();
  if (!cred) {
    return { ok: false, status: 503, error: "Dashboard credential unavailable — the database is not reachable." };
  }
  const candidate = scrypt(String(password ?? ""), cred.salt);
  if (safeEqual(candidate, cred.hash)) {
    await writeSetting(GUARD_KEY, { fails: 0, lockedUntil: null, lastFailAt: guard.lastFailAt, lastOkAt: new Date().toISOString() });
    return { ok: true, token: sessionToken(cred) };
  }
  const fails = guard.fails + 1;
  const locked = fails >= MAX_FAILS;
  await writeSetting(GUARD_KEY, {
    fails: locked ? 0 : fails,
    lockedUntil: locked ? new Date(Date.now() + LOCK_MINUTES * 60_000).toISOString() : null,
    lastFailAt: new Date().toISOString(),
    lastOkAt: guard.lastOkAt,
  });
  if (locked) {
    return { ok: false, status: 429, retryAfter: LOCK_MINUTES * 60, error: `Too many failed attempts. Locked for ${LOCK_MINUTES} minutes.` };
  }
  return {
    ok: false,
    status: 401,
    error: `Incorrect password. ${MAX_FAILS - fails} attempt${MAX_FAILS - fails === 1 ? "" : "s"} left before a ${LOCK_MINUTES}-minute lock.`,
  };
}

export async function changePassword(current: string, next: string): Promise<{ ok: true } | { ok: false; error: string }> {
  const cred = await getCredential();
  if (!cred) return { ok: false, error: "Dashboard credential unavailable." };
  const issues = passwordIssues(next);
  if (issues.length) return { ok: false, error: `New password needs ${issues.join(", ")}.` };
  if (!safeEqual(scrypt(String(current ?? ""), cred.salt), cred.hash)) {
    return { ok: false, error: "Current password is incorrect." };
  }
  const salt = randomBytes(16).toString("hex");
  await writeSetting(CRED_KEY, {
    salt,
    hash: scrypt(next, salt),
    epoch: cred.epoch + 1, // invalidates every existing session
    updatedAt: new Date().toISOString(),
    source: "dashboard",
  });
  return { ok: true };
}

/** Signs every device out (rotates the epoch) without changing the password. */
export async function revokeAllSessions(): Promise<{ ok: boolean }> {
  const cred = await getCredential();
  if (!cred) return { ok: false };
  await writeSetting(CRED_KEY, { ...cred, epoch: cred.epoch + 1, updatedAt: new Date().toISOString() });
  await writeSetting(GUARD_KEY, { fails: 0, lockedUntil: null, lastFailAt: null, lastOkAt: null });
  return { ok: true };
}

export async function isAdmin(): Promise<boolean> {
  try {
    const store = await cookies();
    const token = store.get(ADMIN_COOKIE)?.value;
    if (!token) return false;
    const cred = await getCredential();
    if (!cred) return false;
    return safeEqual(token, sessionToken(cred));
  } catch {
    return false;
  }
}
