/**
 * Public-site copy registry. Kept free of any database imports so it can be
 * used safely from client components (the admin Site content editor).
 * `src/lib/content.ts` adds the server-side loader on top of this.
 */

export type ContentField = {
  key: string;
  label: string;
  group: string;
  multiline?: boolean;
};

export const CONTENT_SCHEMA: ContentField[] = [
  // Home — hero
  { key: "home.badge", label: "Hero badge line", group: "Home · hero" },
  { key: "home.title1", label: "Hero title — line 1", group: "Home · hero" },
  { key: "home.title2", label: "Hero title — line 2 (red)", group: "Home · hero" },
  { key: "home.intro", label: "Hero paragraph", group: "Home · hero", multiline: true },
  { key: "home.ctaPrimary", label: "Hero primary button", group: "Home · hero" },
  { key: "home.ctaSecondary", label: "Hero secondary button", group: "Home · hero" },
  { key: "home.stat1", label: "Stat 1 label", group: "Home · hero" },
  { key: "home.stat2", label: "Stat 2 label", group: "Home · hero" },
  { key: "home.stat3", label: "Stat 3 label", group: "Home · hero" },
  // Home — sections
  { key: "home.capacityTitle", label: "Capacity card title", group: "Home · sections" },
  { key: "home.capacityBody", label: "Capacity card text", group: "Home · sections", multiline: true },
  { key: "home.capacityFoot", label: "Capacity card footnote", group: "Home · sections" },
  { key: "home.constructionsEyebrow", label: "Sections eyebrow", group: "Home · sections" },
  { key: "home.constructionsTitle", label: "Sections heading", group: "Home · sections" },
  { key: "home.featuredEyebrow", label: "Featured eyebrow", group: "Home · sections" },
  { key: "home.featuredTitle", label: "Featured heading", group: "Home · sections" },
  // Home — process
  { key: "home.processEyebrow", label: "Process eyebrow", group: "Home · process" },
  { key: "home.processTitle", label: "Process heading", group: "Home · process" },
  { key: "home.processIntro", label: "Process paragraph", group: "Home · process", multiline: true },
  { key: "home.processChips", label: "Capability chips (comma separated)", group: "Home · process" },
  { key: "home.step1Label", label: "Step 1 label", group: "Home · process" },
  { key: "home.step1Title", label: "Step 1 title", group: "Home · process" },
  { key: "home.step1Body", label: "Step 1 text", group: "Home · process", multiline: true },
  { key: "home.step2Label", label: "Step 2 label", group: "Home · process" },
  { key: "home.step2Title", label: "Step 2 title", group: "Home · process" },
  { key: "home.step2Body", label: "Step 2 text", group: "Home · process", multiline: true },
  { key: "home.step3Label", label: "Step 3 label", group: "Home · process" },
  { key: "home.step3Title", label: "Step 3 title", group: "Home · process" },
  { key: "home.step3Body", label: "Step 3 text", group: "Home · process", multiline: true },
  // Home — compliance + CTA
  { key: "home.complianceTitle", label: "Compliance heading", group: "Home · compliance & CTA" },
  { key: "home.complianceBody", label: "Compliance paragraph", group: "Home · compliance & CTA", multiline: true },
  { key: "home.ctaTitle", label: "Closing CTA heading", group: "Home · compliance & CTA" },
  { key: "home.ctaBody", label: "Closing CTA paragraph", group: "Home · compliance & CTA", multiline: true },
  { key: "home.ctaPrimary2", label: "Closing CTA primary button", group: "Home · compliance & CTA" },
  { key: "home.ctaSecondary2", label: "Closing CTA secondary button", group: "Home · compliance & CTA" },
  // Catalog
  { key: "catalog.eyebrow", label: "Catalog eyebrow", group: "Catalog page" },
  { key: "catalog.title", label: "Catalog heading", group: "Catalog page" },
  { key: "catalog.intro", label: "Catalog paragraph", group: "Catalog page", multiline: true },
  // Configurator (studio labels)
  { key: "config.materialsTitle", label: "Studio: materials heading", group: "Catalog studio" },
  { key: "config.insideTitle", label: "Studio: “Inside this ball” heading", group: "Catalog studio" },
  { key: "config.logoTitle", label: "Studio: logo heading", group: "Catalog studio" },
  { key: "config.priceTitle", label: "Studio: price heading", group: "Catalog studio" },
  { key: "config.priceSub", label: "Studio: price sub-line", group: "Catalog studio" },
  { key: "config.quoteCta", label: "Studio: quote button", group: "Catalog studio" },
  { key: "config.lookInside", label: "Studio: look-inside button", group: "Catalog studio" },
  { key: "config.closeUp", label: "Studio: close-up button", group: "Catalog studio" },
  { key: "config.mobileCta", label: "Mobile bar button", group: "Catalog studio" },
  // Footer
  { key: "footer.about", label: "Footer: about paragraph", group: "Footer", multiline: true },
  { key: "footer.complianceNote", label: "Footer: compliance note", group: "Footer", multiline: true },
  { key: "footer.copyright", label: "Footer: copyright line", group: "Footer" },
  { key: "footer.craftLine", label: "Footer: right-hand line", group: "Footer" },
];

export const DEFAULT_CONTENT: Record<string, string> = {
  "home.badge": "Forward Sports · The Soccer Expert · Product Catalog",
  "home.title1": "Configure every ball.",
  "home.title2": "Panel by panel.",
  "home.intro":
    "The official Forward Sports product catalog. Browse construction families, switch rexine materials in live 3D, drop your own logo on the ball and get an FOB price before you ever pick up the phone. Company profile, facilities and team: forward.pk.",
  "home.ctaPrimary": "Browse the catalog",
  "home.ctaSecondary": "See constructions",
  "home.stat1": "Construction families",
  "home.stat2": "Articles in catalog",
  "home.stat3": "Rexine materials",
  "home.capacityTitle": "Everything else lives at forward.pk",
  "home.capacityBody":
    "This website is the catalog only. Our factories, equipment, the 360° virtual tour, our team, certifications, CSR and environment reports are all on the company website.",
  "home.capacityFoot": "forward.pk — The Soccer Expert",
  "home.constructionsEyebrow": "The catalogue",
  "home.constructionsTitle": "Every way we build a ball",
  "home.featuredEyebrow": "Featured articles",
  "home.featuredTitle": "Flagship builds this season",
  "home.processEyebrow": "How this catalog works",
  "home.processTitle": "Browse, configure, quote — three steps",
  "home.processIntro":
    "No company brochure here — this site does one job: let you configure our balls and price them in minutes. Who we are, how we build and what we stand for lives on forward.pk.",
  "home.processChips": "Live 3D studio, 15 articles, 15 rexine materials, Look inside, Logo placement, Live FOB price",
  "home.step1Label": "Step 01",
  "home.step1Title": "Pick your article",
  "home.step1Body":
    "Browse the construction families — thermal-bonded, hand-stitched, machine-stitched, hybrid, mini, volley and medicine balls — and open any article in the live 3D studio.",
  "home.step2Label": "Step 02",
  "home.step2Title": "Configure it in 3D",
  "home.step2Body":
    "Switch rexine materials and watch the grain and sheen change, place your club or brand logo on the panel, and open the ball to inspect cover, foam, lining and bladder.",
  "home.step3Label": "Step 03",
  "home.step3Title": "Price it & request a quote",
  "home.step3Body":
    "Live USD FOB pricing updates as you configure. Send the build to our sales desk — company details, audits and references are on forward.pk.",
  "home.complianceTitle": "Equipment, staff & facilities? That's forward.pk",
  "home.complianceBody":
    "Inspect our machinery, meet the team behind every ball, review certifications or take the aerial 360° factory tour on our main website. This site stays focused on the products.",
  "home.ctaTitle": "Ready to build your own ball?",
  "home.ctaBody":
    "Pick a construction, choose your rexine, upload your crest and request a quote — your configuration lands directly with our Sialkot sales desk.",
  "home.ctaPrimary2": "Start configuring",
  "home.ctaSecondary2": "See thermo bonded",
  "catalog.eyebrow": "Forward Sports · product catalog — company site: forward.pk",
  "catalog.title": "The complete ball range",
  "catalog.intro":
    "Pick any article below — the 3D studio on the right re-skins it with your chosen rexine, your logo, and even opens the ball up to show the bladder, foam and lining inside.",
  "config.materialsTitle": "Rexine materials",
  "config.insideTitle": "Inside this ball",
  "config.logoTitle": "Your logo on the ball",
  "config.priceTitle": "Live FOB price",
  "config.priceSub": "USD · FOB Sialkot · per unit",
  "config.quoteCta": "Request quote for this build",
  "config.lookInside": "Look inside",
  "config.closeUp": "Texture close-up",
  "config.mobileCta": "Configure in 3D",
  "footer.about":
    "The official product catalog of Forward Sports — The Soccer Expert. Products and pricing only; for facilities, equipment, staff, certifications, CSR and the 360° factory tour visit forward.pk.",
  // Contact details (address / e-mails / phone / hours) are edited in
  // Admin → Inbox & mail (settings key "contact") — these defaults just keep
  // older saved content rows rendering correctly.
  "footer.address": "Forward Sports (Pvt) Ltd — Sialkot, Pakistan",
  "footer.email": "hassanqulaba@forward.pk",
  "footer.phone": "+92 345 6680616",
  "footer.hours": "Monday – Saturday, 9:00 – 18:00 PKT",
  "footer.complianceNote":
    "Product test documentation accompanies every article. Company certifications, audits and policies are published on forward.pk.",
  "footer.copyright": "© 2026 Forward Sports (Pvt) Ltd — The Soccer Expert. All rights reserved.",
  "footer.craftLine": "Crafted in Sialkot",
};
