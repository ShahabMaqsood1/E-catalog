import { mkdir, readFile, readdir, stat, writeFile } from "fs/promises";
import path from "path";

/**
 * ONE place where every user-supplied file lives.
 *
 * Everything a client uploads (rexine photos, article 3D models, renders, layer
 * photos, artwork, brand assets, CorelDRAW files) is written INSIDE the project
 * tree at `public/media/<folder>/`, so the files travel with the project when it
 * is downloaded/copied to another machine — nothing depends on a temp dir or an
 * external URL. Files that are referenced by an external http(s) URL can be
 * pulled in with `localizeUrl()` (Admin → Media & files → "Copy external files
 * into the project").
 *
 * Serving: `/api/files/<folder>/<name>` (see app/api/files/[...path]/route.ts).
 * That route also still serves the legacy flat `storage/uploads/` folder so old
 * database rows keep working after the restructure.
 */

export type MediaFolder =
  | "rexine"
  | "models"
  | "renders"
  | "artwork"
  | "layers"
  | "brand"
  | "designs"
  | "misc";

export const MEDIA_ROOT = path.join(process.cwd(), "public", "media");
export const LEGACY_ROOT = path.join(process.cwd(), "storage", "uploads");

export const MEDIA_FOLDERS: Array<{
  id: MediaFolder;
  label: string;
  hint: string;
  accepts: string;
}> = [
  { id: "rexine", label: "Rexine material photos", hint: "Swatch photos used by the picker + the 3D grain/colour of each material", accepts: "png, jpg, jpeg, webp" },
  { id: "models", label: "Article 3D models", hint: "Baked-artwork GLB/GLTF/OBJ/STL per article (STL is auto-converted to GLB)", accepts: "glb, gltf, obj, stl" },
  { id: "renders", label: "Article render images", hint: "Static 3D render fallbacks shown when an article has no model", accepts: "png, jpg, jpeg, webp" },
  { id: "artwork", label: "Wrap artwork", hint: "Full-wrap artwork exported from CorelDRAW", accepts: "png, jpg, jpeg, webp, svg, pdf" },
  { id: "layers", label: "Look-inside layer photos", hint: "Cover / foam / lining / bladder photos for the exploded view", accepts: "png, jpg, jpeg, webp" },
  { id: "brand", label: "Brand assets", hint: "Logos and other brand artwork (site logo itself ships in public/brand)", accepts: "png, jpg, jpeg, svg, ico" },
  { id: "designs", label: "CorelDRAW / design files", hint: "Source design files kept for production", accepts: "cdr, ai, eps, pdf, svg" },
  { id: "misc", label: "Other files", hint: "Anything that does not belong to the folders above", accepts: "any allowed type" },
];

export const IMAGE_EXTS = new Set(["png", "jpg", "jpeg", "webp", "gif", "avif", "ico"]);
export const MODEL_EXTS = new Set(["glb", "gltf", "obj", "stl"]);
export const DESIGN_EXTS = new Set(["cdr", "ai", "eps", "pdf", "svg"]);

export const ALL_EXTS = new Set([...IMAGE_EXTS, ...MODEL_EXTS, ...DESIGN_EXTS]);

export function extOf(name: string): string {
  const e = path.extname(name).toLowerCase().replace(/^\./, "");
  return e;
}

/** Guess the right folder from an explicit hint, the extension, or a DB field name. */
export function folderFor(ext: string, hint?: string | null, field?: string | null): MediaFolder {
  const h = (hint || "").toLowerCase();
  if ((MEDIA_FOLDERS as Array<{ id: string }>).some((f) => f.id === h)) return h as MediaFolder;
  const f = (field || "").toLowerCase();
  if (f.includes("texture") || f.includes("rexine") || f.includes("material")) return "rexine";
  if (f.includes("model")) return "models";
  if (f.includes("render")) return "renders";
  if (f.includes("artwork")) return "artwork";
  if (f.includes("layer")) return "layers";
  if (f.includes("logo") || f.includes("favicon") || f.includes("brand")) return "brand";
  if (MODEL_EXTS.has(ext)) return "models";
  if (DESIGN_EXTS.has(ext)) return "designs";
  if (IMAGE_EXTS.has(ext)) return "misc";
  return "misc";
}

/** "Forward Logo (final) 2.PNG" -> "forward-logo-final-2.png" (safe for URLs + disks) */
export function sanitizeBase(name: string): string {
  const ext = extOf(name);
  const base = path
    .basename(name, ext ? `.${ext}` : undefined)
    .toLowerCase()
    .replace(/[^a-z0-9._-]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 60);
  return `${base || "file"}${ext ? `.${ext}` : ""}`;
}

export function uniqueName(originalName: string): string {
  const stamp = Date.now().toString(36);
  const rnd = Math.random().toString(36).slice(2, 6);
  const safe = sanitizeBase(originalName);
  const ext = extOf(safe);
  const stem = ext ? safe.slice(0, -(ext.length + 1)) : safe;
  return `${stem}-${stamp}${rnd}${ext ? `.${ext}` : ""}`;
}

/** Canonical public URL for a stored file. */
export function fileUrl(folder: MediaFolder | string, storedName: string): string {
  return `/api/files/${folder}/${storedName}`;
}

export async function ensureFolders(): Promise<void> {
  for (const f of MEDIA_FOLDERS) {
    await mkdir(path.join(MEDIA_ROOT, f.id), { recursive: true });
  }
}

/** Writes a buffer into the project's media tree and returns its URL. */
export async function saveMedia(
  buf: Buffer,
  opts: { folder?: MediaFolder | string; originalName: string; field?: string | null }
): Promise<{ url: string; folder: MediaFolder; storedName: string; size: number; absPath: string }> {
  const ext = extOf(opts.originalName);
  const folder = folderFor(ext, opts.folder, opts.field);
  const dir = path.join(MEDIA_ROOT, folder);
  await mkdir(dir, { recursive: true });
  const storedName = uniqueName(opts.originalName);
  const absPath = path.join(dir, storedName);
  await writeFile(absPath, buf);
  return { url: fileUrl(folder, storedName), folder, storedName, size: buf.length, absPath };
}

/** Turns any accepted reference ("/api/files/x.png", "/media/rexine/x.png", "rexine/x.png")
 *  into a path relative to a storage root, or null when it is not a local file. */
export function toRelPath(input: string): string | null {
  if (!input || typeof input !== "string") return null;
  let p = input.trim();
  if (!p) return null;
  if (/^https?:\/\//i.test(p)) return null;
  p = p.replace(/^\/api\/files\//, "").replace(/^\/media\//, "").replace(/^\/+/, "");
  p = p.split("?")[0].split("#")[0];
  if (!p || p.includes("..") || p.startsWith("/")) return null;
  const parts = p.split("/").filter(Boolean);
  if (parts.length === 0 || parts.length > 4) return null;
  for (const seg of parts) {
    if (!/^[A-Za-z0-9._-]+$/.test(seg)) return null;
  }
  return parts.join("/");
}

/** Reads a stored file: new tree first, then the legacy flat uploads folder. */
export async function readStored(input: string): Promise<{ buf: Buffer; absPath: string } | null> {
  const rel = toRelPath(input);
  if (!rel) return null;
  const candidates = [path.join(MEDIA_ROOT, rel), path.join(LEGACY_ROOT, path.basename(rel))];
  for (const abs of candidates) {
    try {
      const s = await stat(abs);
      if (!s.isFile()) continue;
      return { buf: await readFile(abs), absPath: abs };
    } catch {
      /* try next */
    }
  }
  return null;
}

const MIME_BY_EXT: Record<string, string> = {
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".webp": "image/webp",
  ".gif": "image/gif",
  ".avif": "image/avif",
  ".ico": "image/x-icon",
  ".svg": "image/svg+xml",
  ".pdf": "application/pdf",
  ".glb": "model/gltf-binary",
  ".gltf": "model/gltf+json",
  ".obj": "model/obj",
  ".stl": "model/stl",
  ".cdr": "application/octet-stream",
  ".ai": "application/octet-stream",
  ".eps": "application/octet-stream",
};

export function mimeFor(name: string): string {
  return MIME_BY_EXT[path.extname(name).toLowerCase()] ?? "application/octet-stream";
}

/** Inventory of the project's media tree — shown in Admin → Media & files. */
export async function mediaInventory(): Promise<
  Array<{ folder: MediaFolder; label: string; files: number; bytes: number; items: Array<{ name: string; url: string; size: number; modified: string }> }>
> {
  await ensureFolders();
  const out: Array<{ folder: MediaFolder; label: string; files: number; bytes: number; items: Array<{ name: string; url: string; size: number; modified: string }> }> = [];
  for (const f of MEDIA_FOLDERS) {
    const dir = path.join(MEDIA_ROOT, f.id);
    let names: string[] = [];
    try {
      names = await readdir(dir);
    } catch {
      names = [];
    }
    const items: Array<{ name: string; url: string; size: number; modified: string }> = [];
    let bytes = 0;
    for (const n of names.sort()) {
      try {
        const s = await stat(path.join(dir, n));
        if (!s.isFile()) continue;
        bytes += s.size;
        items.push({ name: n, url: fileUrl(f.id, n), size: s.size, modified: s.mtime.toISOString() });
      } catch {
        /* ignore */
      }
    }
    out.push({ folder: f.id, label: f.label, files: items.length, bytes, items });
  }
  return out;
}

/* ------------------------------------------------- external URL import ---- */

const CT_EXT: Record<string, string> = {
  "image/png": "png",
  "image/jpeg": "jpg",
  "image/webp": "webp",
  "image/gif": "gif",
  "image/svg+xml": "svg",
  "image/x-icon": "ico",
  "model/gltf-binary": "glb",
  "model/gltf+json": "gltf",
  "model/obj": "obj",
  "model/stl": "stl",
  "application/pdf": "pdf",
};

/** Downloads an external file so a copy lives inside the project. */
export async function fetchRemoteFile(
  url: string,
  maxBytes = 60 * 1024 * 1024
): Promise<{ buf: Buffer; name: string; ext: string }> {
  if (!/^https?:\/\//i.test(url)) throw new Error("Only http(s) URLs can be imported.");
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 30_000);
  let res: Response;
  try {
    res = await fetch(url, { signal: ctrl.signal, redirect: "follow" });
  } finally {
    clearTimeout(timer);
  }
  if (!res.ok) throw new Error(`Source responded ${res.status}.`);
  const ct = (res.headers.get("content-type") || "").split(";")[0].trim().toLowerCase();
  const len = Number(res.headers.get("content-length") || 0);
  if (len && len > maxBytes) throw new Error("Source file is larger than the 60 MB limit.");
  const ab = await res.arrayBuffer();
  if (ab.byteLength > maxBytes) throw new Error("Source file is larger than the 60 MB limit.");
  const buf = Buffer.from(ab);
  let name = "";
  try {
    name = decodeURIComponent(new URL(url).pathname.split("/").pop() || "");
  } catch {
    name = "";
  }
  let ext = extOf(name);
  if (!ext || !ALL_EXTS.has(ext)) ext = CT_EXT[ct] ?? "";
  if (!ext) throw new Error("Could not determine the file type of that URL.");
  if (!ALL_EXTS.has(ext)) throw new Error(`File type .${ext} is not allowed.`);
  if (!name || !name.toLowerCase().endsWith(`.${ext}`)) name = `${sanitizeBase(name || "imported") || "imported"}.${ext}`;
  return { buf, name, ext };
}

export function isRemoteUrl(value: unknown): value is string {
  return typeof value === "string" && /^https?:\/\//i.test(value.trim());
}
