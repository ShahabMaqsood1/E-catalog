import { eq } from "drizzle-orm";
import { db } from "@/db";
import { settings } from "@/db/schema";

/**
 * The sales contact details shown across the site AND used as the recipients of
 * every contact-form / quote-request e-mail.
 *
 * Item 7: exactly two addresses and the factory phone number.
 * Item 8: all of it is editable from the dashboard (Admin → Inbox & mail), so it
 * never requires a code change. Stored in `settings.contact`.
 */

export type ContactCfg = {
  emails: string[];
  phone: string;
  phoneHref: string;
  whatsapp: string;
  address: string;
  hours: string;
  responseNote: string;
};

export const DEFAULT_CONTACT: ContactCfg = {
  emails: ["hassanqulaba@forward.pk", "adeel@forward.pk"],
  phone: "+92 345 6680616",
  phoneHref: "+923456680616",
  whatsapp: "+92 345 6680616",
  address: "Forward Sports (Pvt) Ltd — Sialkot, Pakistan",
  hours: "Monday – Saturday, 9:00 – 18:00 PKT",
  responseNote: "Quotes are answered within one working day.",
};

export function normalizeEmails(value: unknown): string[] {
  const list = Array.isArray(value) ? value : typeof value === "string" ? value.split(/[,\n;]+/) : [];
  const out: string[] = [];
  for (const raw of list) {
    const e = String(raw ?? "").trim().toLowerCase();
    if (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e) && !out.includes(e)) out.push(e);
  }
  return out;
}

export async function getContactCfg(): Promise<ContactCfg> {
  try {
    const row = await db.query.settings.findFirst({ where: eq(settings.key, "contact") });
    const cfg = row ? { ...DEFAULT_CONTACT, ...(row.value as object) } : { ...DEFAULT_CONTACT };
    const emails = normalizeEmails(cfg.emails);
    return {
      ...cfg,
      emails: emails.length ? emails : DEFAULT_CONTACT.emails,
      phone: cfg.phone || DEFAULT_CONTACT.phone,
      phoneHref: (cfg.phoneHref || cfg.phone || DEFAULT_CONTACT.phone).replace(/[^+\d]/g, ""),
      whatsapp: cfg.whatsapp || "",
      address: cfg.address || DEFAULT_CONTACT.address,
      hours: cfg.hours || DEFAULT_CONTACT.hours,
      responseNote: cfg.responseNote || DEFAULT_CONTACT.responseNote,
    };
  } catch {
    return { ...DEFAULT_CONTACT };
  }
}

export async function saveContactCfg(patch: Partial<ContactCfg>): Promise<ContactCfg> {
  const current = await getContactCfg();
  const next: ContactCfg = {
    ...current,
    ...patch,
    emails: normalizeEmails(patch.emails ?? current.emails),
  };
  await db
    .insert(settings)
    .values({ key: "contact", value: next as never })
    .onConflictDoUpdate({ target: settings.key, set: { value: next as never } });
  return next;
}
