import nodemailer from "nodemailer";
import { db } from "@/db";
import { settings } from "@/db/schema";
import { eq } from "drizzle-orm";
import { normalizeEmails } from "@/lib/contact";

export { DEFAULT_CONTACT, getContactCfg, normalizeEmails, saveContactCfg, type ContactCfg } from "@/lib/contact";

/**
 * Mail + contact configuration.
 *
 * BOTH live in the `settings` table, so the owner can point the catalog at a
 * real mailbox (e.g. no-reply@forward.pk) from the dashboard — Admin →
 * "Inbox & mail" — without touching code or environment variables.
 *
 * If no SMTP server is configured, submissions are still stored in the
 * `messages` table (Admin → Inbox & mail) so nothing is ever lost; the row is
 * marked `delivered = false` and can be re-sent once the mailbox is set up.
 */

export type MailCfg = {
  enabled: boolean;
  host: string;
  port: number;
  secure: boolean; // true = implicit TLS (465), false = STARTTLS (587)
  user: string;
  pass: string;
  from: string; // e.g. no-reply@forward.pk
  fromName: string;
  replyTo: string;
  lastStatus: string;
  lastError: string;
  lastSentAt: string;
};

export const DEFAULT_MAIL: MailCfg = {
  enabled: false,
  host: "",
  port: 587,
  secure: false,
  user: "",
  pass: "",
  from: "",
  fromName: "Forward Sports E-Catalog",
  replyTo: "",
  lastStatus: "never",
  lastError: "",
  lastSentAt: "",
};

async function readSetting<T>(key: string, fallback: T): Promise<T> {
  try {
    const row = await db.query.settings.findFirst({ where: eq(settings.key, key) });
    return row ? ({ ...fallback, ...(row.value as object) } as T) : fallback;
  } catch {
    return fallback;
  }
}

async function writeSetting(key: string, value: unknown) {
  await db
    .insert(settings)
    .values({ key, value: value as never })
    .onConflictDoUpdate({ target: settings.key, set: { value: value as never } });
}

export async function getMailCfg(): Promise<MailCfg> {
  const cfg = await readSetting<MailCfg>("mail", DEFAULT_MAIL);
  return { ...cfg, port: Number(cfg.port) || 587, enabled: !!cfg.enabled };
}

export type SendResult = { sent: boolean; status: string; error?: string; to: string[] };

/** Sends through the dashboard-configured SMTP server. Never throws. */
export async function sendMail(opts: {
  to: string[];
  subject: string;
  text: string;
  html?: string;
  replyTo?: string;
}): Promise<SendResult> {
  const cfg = await getMailCfg();
  const to = normalizeEmails(opts.to);
  if (!to.length) return { sent: false, status: "no-recipients", to: [] };
  if (!cfg.enabled || !cfg.host || !cfg.from) {
    const msg = "Mail server not configured — message saved in the dashboard inbox instead.";
    await writeSetting("mail", { ...cfg, lastStatus: "not-configured", lastError: msg });
    return { sent: false, status: "not-configured", error: msg, to };
  }
  try {
    const transport = nodemailer.createTransport({
      host: cfg.host,
      port: cfg.port,
      secure: !!cfg.secure,
      auth: cfg.user ? { user: cfg.user, pass: cfg.pass } : undefined,
      connectionTimeout: 15_000,
      greetingTimeout: 15_000,
      socketTimeout: 25_000,
    });
    await transport.sendMail({
      from: { name: cfg.fromName || "Forward Sports E-Catalog", address: cfg.from },
      to,
      replyTo: opts.replyTo || cfg.replyTo || undefined,
      subject: opts.subject,
      text: opts.text,
      html: opts.html,
    });
    const at = new Date().toISOString();
    await writeSetting("mail", { ...cfg, lastStatus: "sent", lastError: "", lastSentAt: at });
    return { sent: true, status: "sent", to };
  } catch (err) {
    const error = (err as Error).message?.slice(0, 400) || "Unknown mail error";
    await writeSetting("mail", { ...cfg, lastStatus: "failed", lastError: error });
    console.warn("[mail] send failed:", error);
    return { sent: false, status: "failed", error, to };
  }
}

/* ------------------------------------------------------- email bodies ---- */

function esc(s: string) {
  return String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c] as string);
}

function rows(pairs: Array<[string, string]>) {
  return pairs
    .filter(([, v]) => v)
    .map(
      ([k, v]) =>
        `<tr><td style="padding:7px 14px 7px 0;color:#8a8580;font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;white-space:nowrap">${esc(
          k
        )}</td><td style="padding:7px 0;color:#191614;font-size:14px">${esc(v)}</td></tr>`
    )
    .join("");
}

export function wrapEmail(title: string, subtitle: string, tableRows: string, message: string, footer: string) {
  return `<!doctype html><html><body style="margin:0;background:#f4f2ef;font-family:Segoe UI,Helvetica,Arial,sans-serif">
<div style="max-width:640px;margin:0 auto;padding:26px 18px">
  <div style="background:#100e0d;border-radius:14px 14px 0 0;padding:20px 24px">
    <p style="margin:0;color:#cb0000;font-size:11px;font-weight:800;letter-spacing:.24em;text-transform:uppercase">Forward Sports · E-Catalog</p>
    <h1 style="margin:8px 0 0;color:#fff;font-size:22px;line-height:1.2">${esc(title)}</h1>
    <p style="margin:6px 0 0;color:#bdb8b3;font-size:13px">${esc(subtitle)}</p>
  </div>
  <div style="background:#fff;border:1px solid #e4e0db;border-top:0;border-radius:0 0 14px 14px;padding:22px 24px">
    <table style="border-collapse:collapse;width:100%">${tableRows}</table>
    ${
      message
        ? `<p style="margin:18px 0 0;color:#8a8580;font-size:11px;font-weight:800;letter-spacing:.14em;text-transform:uppercase">Message</p>
           <p style="margin:6px 0 0;color:#191614;font-size:14px;line-height:1.6;white-space:pre-wrap">${esc(message)}</p>`
        : ""
    }
    <p style="margin:22px 0 0;padding-top:14px;border-top:1px solid #eee9e4;color:#8a8580;font-size:12px;line-height:1.6">${esc(footer)}</p>
  </div>
</div></body></html>`;
}

export function contactEmailHtml(d: {
  name: string;
  email: string;
  phone?: string;
  company?: string;
  subject?: string;
  message: string;
  article?: string;
}) {
  return wrapEmail(
    d.subject || "New catalog enquiry",
    `From ${d.name} · ${d.email}`,
    rows([
      ["Name", d.name],
      ["Email", d.email],
      ["Phone", d.phone || ""],
      ["Company", d.company || ""],
      ["Article", d.article || ""],
    ]),
    d.message,
    "Sent from the Forward Sports e-catalog contact form. Reply directly to the address above."
  );
}

export function contactEmailText(d: {
  name: string;
  email: string;
  phone?: string;
  company?: string;
  subject?: string;
  message: string;
  article?: string;
}) {
  return [
    `New catalog enquiry — ${d.subject || "contact form"}`,
    "",
    `Name:    ${d.name}`,
    `Email:   ${d.email}`,
    d.phone ? `Phone:   ${d.phone}` : "",
    d.company ? `Company: ${d.company}` : "",
    d.article ? `Article: ${d.article}` : "",
    "",
    "Message:",
    d.message,
    "",
    "— Forward Sports e-catalog",
  ]
    .filter(Boolean)
    .join("\n");
}

export function quoteEmailHtml(d: {
  ref: string;
  name: string;
  email: string;
  company?: string;
  phone?: string;
  article?: string;
  material?: string;
  quantity: number;
  unit: string;
  total: string;
  logo?: string;
  message?: string;
}) {
  return wrapEmail(
    `Quote request ${d.ref}`,
    `${d.article || "Catalog article"} · ${d.quantity.toLocaleString()} units`,
    rows([
      ["Reference", d.ref],
      ["Buyer", d.name],
      ["Company", d.company || ""],
      ["Email", d.email],
      ["Phone", d.phone || ""],
      ["Article", d.article || ""],
      ["Rexine", d.material || ""],
      ["Quantity", `${d.quantity.toLocaleString()} units`],
      ["Unit FOB", d.unit],
      ["Total FOB", d.total],
      ["Logo", d.logo || ""],
    ]),
    d.message || "",
    "Sent from the Forward Sports e-catalog configurator. Reply with pricing, sampling or lead-time details."
  );
}

export function quoteEmailText(d: {
  ref: string;
  name: string;
  email: string;
  company?: string;
  phone?: string;
  article?: string;
  material?: string;
  quantity: number;
  unit: string;
  total: string;
  logo?: string;
  message?: string;
}) {
  return [
    `QUOTE REQUEST ${d.ref}`,
    `Buyer:    ${d.name}${d.company ? ` (${d.company})` : ""}`,
    `Email:    ${d.email}`,
    d.phone ? `Phone:    ${d.phone}` : "",
    `Article:  ${d.article || "-"}`,
    `Rexine:   ${d.material || "-"}`,
    `Quantity: ${d.quantity}`,
    `Unit FOB: ${d.unit}`,
    `Total:    ${d.total}`,
    d.logo ? `Logo:     ${d.logo}` : "",
    "",
    d.message ? `Message:\n${d.message}` : "",
    "— Forward Sports e-catalog",
  ]
    .filter(Boolean)
    .join("\n");
}
