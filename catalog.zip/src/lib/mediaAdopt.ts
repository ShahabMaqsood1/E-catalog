import { copyFile, mkdir, readdir, stat } from "fs/promises";
import path from "path";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { articles, materials } from "@/db/schema";
import { LEGACY_ROOT, MEDIA_ROOT, extOf, fileUrl, folderFor, uniqueName } from "@/lib/media";

/**
 * Runs on boot: adopts any file that is sitting in the OLD flat upload folder
 * (`storage/uploads`, used before the media restructure) into the project's own
 * media tree (`public/media/<folder>/`) and rewrites the database URLs to match.
 *
 * This is what keeps "everything I uploaded is inside the project" true even for
 * databases restored from an older backup. Idempotent — files already present are
 * left alone, and URLs that already point at the new tree are untouched.
 */
export async function adoptLegacyUploads(): Promise<{ copied: number; rewritten: number }> {
  await mkdir(MEDIA_ROOT, { recursive: true });
  let names: string[] = [];
  try {
    names = await readdir(LEGACY_ROOT);
  } catch {
    return { copied: 0, rewritten: 0 };
  }

  const mapping = new Map<string, string>(); // legacy name -> new url
  let copied = 0;

  for (const name of names) {
    const abs = path.join(LEGACY_ROOT, name);
    try {
      const s = await stat(abs);
      if (!s.isFile()) continue;
    } catch {
      continue;
    }
    const ext = extOf(name);
    const folder = folderFor(ext, null, /glb|gltf|obj|stl/.test(ext) ? "model" : null);
    const dir = path.join(MEDIA_ROOT, folder);
    await mkdir(dir, { recursive: true });
    const storedName = uniqueName(name);
    try {
      await copyFile(abs, path.join(dir, storedName));
      copied++;
    } catch {
      continue;
    }
    mapping.set(name, fileUrl(folder, storedName));
  }

  if (!mapping.size) return { copied, rewritten: 0 };

  const swap = (value: unknown): unknown => {
    if (typeof value !== "string") return value;
    const base = value.replace(/^\/api\/files\//, "").replace(/^\/media\//, "");
    const hit = mapping.get(base) ?? mapping.get(path.basename(base));
    return hit ?? value;
  };

  let rewritten = 0;
  const arts = await db.select().from(articles);
  for (const a of arts) {
    const patch: Record<string, unknown> = {};
    for (const field of ["artworkUrl", "designSvgUrl", "modelUrl", "renderUrl"] as const) {
      const next = swap(a[field]);
      if (next !== a[field]) patch[field] = next;
    }
    const layers = (a.layerImages ?? {}) as Record<string, unknown>;
    const nextLayers: Record<string, unknown> = { ...layers };
    let changed = false;
    for (const k of Object.keys(layers)) {
      const v = swap(layers[k]);
      if (v !== layers[k]) {
        nextLayers[k] = v;
        changed = true;
      }
    }
    if (changed) patch.layerImages = nextLayers;
    if (Object.keys(patch).length) {
      await db.update(articles).set(patch).where(eq(articles.id, a.id));
      rewritten++;
    }
  }

  const mats = await db.select().from(materials);
  for (const m of mats) {
    const next = swap(m.textureUrl);
    if (next !== m.textureUrl) {
      await db.update(materials).set({ textureUrl: String(next ?? "") }).where(eq(materials.id, m.id));
      rewritten++;
    }
  }

  return { copied, rewritten };
}
