import { eq } from "drizzle-orm";
import { isAdmin } from "@/lib/adminAuth";
import { db } from "@/db";
import { articles, materials } from "@/db/schema";
import { fetchRemoteFile, folderFor, isRemoteUrl, saveMedia } from "@/lib/media";

export const dynamic = "force-dynamic";
export const maxDuration = 300;

type Report = { scanned: number; imported: number; failed: Array<{ where: string; url: string; error: string }>; local: number };

/**
 * Sweeps the whole catalog for asset URLs that still point OUTSIDE the project
 * (http/https) and copies each file into `public/media/<folder>/`, rewriting the
 * database row to the local URL. Run it after bulk-importing data so every
 * picture and model travels with the project files.
 */
export async function POST() {
  if (!(await isAdmin())) return Response.json({ error: "Admin access required." }, { status: 401 });

  const report: Report = { scanned: 0, imported: 0, failed: [], local: 0 };
  const cache = new Map<string, string>();

  async function localize(value: unknown, where: string, field: string): Promise<unknown> {
    if (typeof value !== "string" || !value.trim()) return value;
    report.scanned++;
    if (!isRemoteUrl(value)) {
      report.local++;
      return value;
    }
    const hit = cache.get(value);
    if (hit) return hit;
    try {
      const remote = await fetchRemoteFile(value);
      const folder = folderFor(remote.ext, null, field);
      const saved = await saveMedia(remote.buf, { folder, originalName: remote.name, field });
      cache.set(value, saved.url);
      report.imported++;
      return saved.url;
    } catch (err) {
      report.failed.push({ where, url: value.slice(0, 200), error: (err as Error).message?.slice(0, 160) });
      return value;
    }
  }

  // ---- articles -------------------------------------------------------
  const arts = await db.select().from(articles);
  for (const a of arts) {
    const patch: Record<string, unknown> = {};
    const artworkUrl = await localize(a.artworkUrl, `${a.articleNo}.artworkUrl`, "artwork");
    if (artworkUrl !== a.artworkUrl) patch.artworkUrl = artworkUrl;
    const designSvgUrl = await localize(a.designSvgUrl, `${a.articleNo}.designSvgUrl`, "design");
    if (designSvgUrl !== a.designSvgUrl) patch.designSvgUrl = designSvgUrl;
    const modelUrl = await localize(a.modelUrl, `${a.articleNo}.modelUrl`, "model");
    if (modelUrl !== a.modelUrl) patch.modelUrl = modelUrl;
    const renderUrl = await localize(a.renderUrl, `${a.articleNo}.renderUrl`, "render");
    if (renderUrl !== a.renderUrl) patch.renderUrl = renderUrl;

    const layers = (a.layerImages ?? {}) as Record<string, unknown>;
    const nextLayers: Record<string, unknown> = { ...layers };
    let layersChanged = false;
    for (const key of ["cover", "foam", "lining", "bladder"]) {
      const v = await localize(layers[key], `${a.articleNo}.layerImages.${key}`, "layer");
      if (v !== layers[key]) {
        nextLayers[key] = v;
        layersChanged = true;
      }
    }
    if (layersChanged) patch.layerImages = nextLayers;

    if (Object.keys(patch).length) {
      await db.update(articles).set(patch).where(eq(articles.id, a.id));
    }
  }

  // ---- materials ------------------------------------------------------
  const mats = await db.select().from(materials);
  for (const m of mats) {
    const textureUrl = await localize(m.textureUrl, `${m.code}.textureUrl`, "texture");
    if (textureUrl !== m.textureUrl) {
      await db.update(materials).set({ textureUrl: String(textureUrl ?? "") }).where(eq(materials.id, m.id));
    }
  }

  return Response.json({ ok: true, report });
}
