import { NextResponse } from "next/server";
import { isAdmin, changePassword, revokeAllSessions, credentialInfo, passwordStrength } from "@/lib/adminAuth";

export const dynamic = "force-dynamic";

/** Dashboard security: read status, change password, or sign out everywhere. */
export async function GET() {
  if (!(await isAdmin())) return Response.json({ error: "Admin access required." }, { status: 401 });
  return Response.json({ ok: true, info: await credentialInfo() });
}

export async function POST(req: Request) {
  if (!(await isAdmin())) return Response.json({ error: "Admin access required." }, { status: 401 });
  let body: Record<string, unknown>;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return Response.json({ error: "Invalid request." }, { status: 400 });
  }

  if (body.action === "revoke") {
    const r = await revokeAllSessions();
    return Response.json({ ok: r.ok, signedOut: true, info: await credentialInfo() });
  }

  if (body.action === "strength") {
    return Response.json({ ok: true, ...(await Promise.resolve(passwordStrength(String(body.password ?? "")))) });
  }

  const current = String(body.current ?? "");
  const next = String(body.next ?? "");
  const result = await changePassword(current, next);
  if (!result.ok) return Response.json({ error: result.error }, { status: 400 });
  return Response.json({ ok: true, info: await credentialInfo(), note: "Password changed — every device must sign in again." });
}
