import { unlink } from "fs/promises";
import path from "path";
import { NextResponse } from "next/server";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import {
  activity,
  articles,
  categories,
  compliance,
  materials,
  messages,
  quotes,
  settings,
  uploads,
} from "@/db/schema";
import { isAdmin } from "@/lib/adminAuth";
import { LEGACY_ROOT, MEDIA_ROOT, mediaInventory } from "@/lib/media";
import { computeInsights, recentFeed } from "@/lib/insights";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ resource: string }> };

const str = (v: unknown, max = 500) => (typeof v === "string" ? v.slice(0, max) : undefined);
const num = (v: unknown) => {
  const n = Number(v);
  return Number.isFinite(n) ? n : undefined;
};
const bool = (v: unknown) => (typeof v === "boolean" ? v : undefined);
const hex = (v: unknown) => (typeof v === "string" && /^#[0-9a-fA-F]{3,8}$/.test(v) ? v : undefined);

function sanitizeColors(v: unknown) {
  if (!v || typeof v !== "object") return undefined;
  const c = v as Record<string, unknown>;
  const base = hex(c.base);
  const accent = hex(c.accent);
  const ink = hex(c.ink);
  if (!base || !accent || !ink) return undefined;
  return { base, accent, ink };
}

function buildArticleData(b: Record<string, unknown>, partial: boolean) {
  const d: Record<string, unknown> = {};
  const put = (k: string, v: unknown) => {
    if (v !== undefined) d[k] = v;
  };
  put("categoryId", num(b.categoryId));
  put("articleNo", str(b.articleNo, 40));
  put("name", str(b.name, 120));
  put("description", str(b.description, 2000));
  put("panelStyle", str(b.panelStyle, 30));
  const pc = num(b.panelCount);
  put("panelCount", pc !== undefined ? Math.round(pc) : undefined);
  const bp = num(b.basePrice);
  put("basePrice", bp !== undefined ? bp.toFixed(2) : undefined);
  const moq = num(b.moq);
  put("moq", moq !== undefined ? Math.max(1, Math.round(moq)) : undefined);
  put("colors", sanitizeColors(b.colors));
  put("featured", bool(b.featured));
  const status = str(b.status, 10);
  put("status", status === "live" || status === "draft" ? status : undefined);
  const art = str(b.artworkUrl, 300);
  put("artworkUrl", art === "" ? null : art);
  const svgUrl = str(b.designSvgUrl, 300);
  put("designSvgUrl", svgUrl === undefined ? undefined : svgUrl === "" ? null : svgUrl);
  const modelUrl = str(b.modelUrl, 300);
  put("modelUrl", modelUrl === undefined ? undefined : modelUrl === "" ? null : modelUrl);
  const defMat = str(b.defaultMaterialCode, 40);
  put("defaultMaterialCode", defMat === undefined ? undefined : defMat === "" ? null : defMat);
  if (b.modelAdjust && typeof b.modelAdjust === "object") {
    const ma = b.modelAdjust as Record<string, unknown>;
    const clamp = (v: unknown, lo: number, hi: number, dflt: number) => {
      const n = num(v);
      return n === undefined ? dflt : Math.min(hi, Math.max(lo, n));
    };
    put("modelAdjust", {
      rotY: clamp(ma.rotY, -360, 360, 0),
      offsetX: clamp(ma.offsetX, -0.5, 0.5, 0),
      offsetY: clamp(ma.offsetY, -0.5, 0.5, 0),
      scale: clamp(ma.scale, 0.4, 2.5, 1),
    });
  } else if (b.modelAdjust === null) {
    put("modelAdjust", null);
  }
  const renderUrl = str(b.renderUrl, 300);
  put("renderUrl", renderUrl === undefined ? undefined : renderUrl === "" ? null : renderUrl);
  const seam = str(b.seamStyle, 20);
  put("seamStyle", seam && ["auto", "hand", "machine", "bonded", "hybrid"].includes(seam) ? seam : undefined);
  if (b.layerImages && typeof b.layerImages === "object") {
    const li = b.layerImages as Record<string, unknown>;
    const out: Record<string, string | null> = {};
    for (const k of ["cover", "foam", "lining", "bladder"] as const) {
      const v = str(li[k], 300);
      out[k] = v === undefined || v === "" ? null : v;
    }
    put("layerImages", out);
  } else if (b.layerImages === null) {
    put("layerImages", null);
  }
  if (b.specs && typeof b.specs === "object") {
    const s = b.specs as Record<string, unknown>;
    const out: Record<string, unknown> = {};
    const bl = str(s.bladder, 120);
    if (bl) out.bladder = bl;
    const ln = str(s.lining, 120);
    if (ln) out.lining = ln;
    const cv = str(s.cover, 120);
    if (cv) out.cover = cv;
    const fm = num(s.foamMm);
    if (fm !== undefined) out.foamMm = Math.round(fm * 10) / 10;
    if (Object.keys(out).length > 0) put("specs", out);
  }
  const cdr = num(b.cdrUploadId);
  put("cdrUploadId", b.cdrUploadId === null ? null : cdr);
  if (!partial) {
    for (const k of ["categoryId", "articleNo", "name", "basePrice", "colors"]) {
      if (d[k] === undefined) throw new Error(`Missing field: ${k}`);
    }
  }
  return d;
}

function buildMaterialData(b: Record<string, unknown>, partial: boolean) {
  const d: Record<string, unknown> = {};
  const put = (k: string, v: unknown) => {
    if (v !== undefined) d[k] = v;
  };
  put("code", str(b.code, 40));
  put("name", str(b.name, 120));
  put("finish", str(b.finish, 60));
  put("description", str(b.description, 2000));
  put("textureUrl", str(b.textureUrl, 300));
  const delta = num(b.priceDelta);
  put("priceDelta", delta !== undefined ? delta.toFixed(2) : undefined);
  put("thickness", str(b.thickness, 40));
  put("weightGsm", num(b.weightGsm));
  put("isActive", bool(b.isActive));
  const so = num(b.sortOrder);
  put("sortOrder", so !== undefined ? Math.round(so) : undefined);
  if (!partial) {
    for (const k of ["code", "name", "priceDelta"]) {
      if (d[k] === undefined) throw new Error(`Missing field: ${k}`);
    }
  }
  return d;
}

/* ------------------------------ GET ------------------------------ */

export async function GET(_req: Request, { params }: Ctx) {
  if (!(await isAdmin())) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { resource } = await params;
  try {
    switch (resource) {
      case "articles":
        return NextResponse.json({ rows: await db.select().from(articles).orderBy(articles.id) });
      case "materials":
        return NextResponse.json({ rows: await db.select().from(materials).orderBy(materials.sortOrder) });
      case "categories":
        return NextResponse.json({ rows: await db.select().from(categories).orderBy(categories.sortOrder) });
      case "quotes":
        return NextResponse.json({ rows: await db.select().from(quotes).orderBy(desc(quotes.createdAt)) });
      case "uploads":
        return NextResponse.json({ rows: await db.select().from(uploads).orderBy(desc(uploads.createdAt)) });
      case "compliance":
        return NextResponse.json({ rows: await db.select().from(compliance).orderBy(compliance.sortOrder) });
      case "activity":
        return NextResponse.json({ rows: await recentFeed(30) });
      case "settings": {
        const rows = await db.select().from(settings);
        const obj: Record<string, unknown> = {};
        for (const r of rows) obj[r.key] = r.value;
        return NextResponse.json({ rows: obj });
      }
      case "messages":
        return NextResponse.json({ rows: await db.select().from(messages).orderBy(desc(messages.createdAt)) });
      case "media":
        return NextResponse.json({ rows: await mediaInventory() });
      case "insights":
        return NextResponse.json(await computeInsights());
      default:
        return NextResponse.json({ error: "Unknown resource" }, { status: 404 });
    }
  } catch (err) {
    return NextResponse.json({ error: (err as Error).message }, { status: 500 });
  }
}

/* ------------------------------ POST (create) ------------------------------ */

export async function POST(req: Request, { params }: Ctx) {
  if (!(await isAdmin())) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { resource } = await params;
  try {
    const b = (await req.json()) as Record<string, unknown>;
    switch (resource) {
      case "articles": {
        const [row] = await db.insert(articles).values(buildArticleData(b, false) as never).returning();
        return NextResponse.json({ row });
      }
      case "materials": {
        const [row] = await db.insert(materials).values(buildMaterialData(b, false) as never).returning();
        return NextResponse.json({ row });
      }
      case "categories": {
        const [row] = await db
          .insert(categories)
          .values({
            slug: str(b.slug, 60) ?? `section-${Date.now()}`,
            name: str(b.name, 120) ?? "New section",
            shortName: str(b.shortName, 60) ?? "New section",
            tagline: str(b.tagline, 200) ?? "",
            description: str(b.description, 2000) ?? "",
            iconKey: str(b.iconKey, 30) ?? "ball",
            sortOrder: num(b.sortOrder) ?? 99,
            isActive: bool(b.isActive) ?? true,
          })
          .returning();
        return NextResponse.json({ row });
      }
      case "compliance": {
        const [row] = await db
          .insert(compliance)
          .values({
            title: str(b.title, 160) ?? "New requirement",
            standard: str(b.standard, 80) ?? "",
            detail: str(b.detail, 1000) ?? "",
            status: str(b.status, 20) ?? "in-progress",
            nextReview: str(b.nextReview, 10) ?? "",
            sortOrder: num(b.sortOrder) ?? 99,
          })
          .returning();
        return NextResponse.json({ row });
      }
      case "settings": {
        const key = str(b.key, 60);
        if (!key) return NextResponse.json({ error: "Missing key" }, { status: 400 });
        const [row] = await db
          .insert(settings)
          .values({ key, value: (b.value ?? null) as never })
          .onConflictDoUpdate({ target: settings.key, set: { value: (b.value ?? null) as never } })
          .returning();
        return NextResponse.json({ row });
      }
      default:
        return NextResponse.json({ error: "Cannot create for this resource" }, { status: 400 });
    }
  } catch (err) {
    return NextResponse.json({ error: (err as Error).message }, { status: 400 });
  }
}

/* ------------------------------ PATCH (update) ------------------------------ */

export async function PATCH(req: Request, { params }: Ctx) {
  if (!(await isAdmin())) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { resource } = await params;
  try {
    const b = (await req.json()) as Record<string, unknown>;
    const id = num(b.id);
    if (!id) return NextResponse.json({ error: "Missing id" }, { status: 400 });
    const data = (b.data ?? {}) as Record<string, unknown>;

    switch (resource) {
      case "articles": {
        const [row] = await db
          .update(articles)
          .set(buildArticleData(data, true) as never)
          .where(eq(articles.id, id))
          .returning();
        return NextResponse.json({ row });
      }
      case "materials": {
        const [row] = await db
          .update(materials)
          .set(buildMaterialData(data, true) as never)
          .where(eq(materials.id, id))
          .returning();
        return NextResponse.json({ row });
      }
      case "categories": {
        const d: Record<string, unknown> = {};
        const s = (k: keyof typeof d, v: unknown) => {
          if (v !== undefined) d[k as string] = v;
        };
        s("name", str(data.name, 120));
        s("shortName", str(data.shortName, 60));
        s("tagline", str(data.tagline, 200));
        s("description", str(data.description, 2000));
        s("iconKey", str(data.iconKey, 30));
        s("isActive", bool(data.isActive));
        const so = num(data.sortOrder);
        s("sortOrder", so !== undefined ? Math.round(so) : undefined);
        const [row] = await db.update(categories).set(d as never).where(eq(categories.id, id)).returning();
        return NextResponse.json({ row });
      }
      case "quotes": {
        const status = str(data.status, 20);
        if (!["new", "contacted", "sampling", "closed"].includes(status ?? ""))
          return NextResponse.json({ error: "Invalid status" }, { status: 400 });
        const [row] = await db.update(quotes).set({ status }).where(eq(quotes.id, id)).returning();
        return NextResponse.json({ row });
      }
      case "messages": {
        const d: Record<string, unknown> = {};
        const st = str(data.status, 20);
        if (st) {
          if (!["new", "read", "replied", "archived"].includes(st))
            return NextResponse.json({ error: "Invalid status" }, { status: 400 });
          d.status = st;
        }
        if (data.delivered !== undefined) d.delivered = !!data.delivered;
        const note = str(data.deliveryNote, 400);
        if (note !== undefined) d.deliveryNote = note;
        const [row] = await db.update(messages).set(d as never).where(eq(messages.id, id)).returning();
        return NextResponse.json({ row });
      }
      case "uploads": {
        const d: Record<string, unknown> = {};
        const st = str(data.status, 20);
        if (st) d.status = st;
        if (data.articleId !== undefined) d.articleId = data.articleId === null ? null : num(data.articleId);
        const note = str(data.note, 500);
        if (note !== undefined) d.note = note;
        const [row] = await db.update(uploads).set(d as never).where(eq(uploads.id, id)).returning();
        return NextResponse.json({ row });
      }
      case "compliance": {
        const d: Record<string, unknown> = {};
        const t = str(data.title, 160);
        if (t) d.title = t;
        const std = str(data.standard, 80);
        if (std !== undefined) d.standard = std;
        const det = str(data.detail, 1000);
        if (det !== undefined) d.detail = det;
        const st = str(data.status, 20);
        if (st) d.status = st;
        const nr = str(data.nextReview, 10);
        if (nr !== undefined) d.nextReview = nr;
        const so = num(data.sortOrder);
        if (so !== undefined) d.sortOrder = Math.round(so);
        const [row] = await db.update(compliance).set(d as never).where(eq(compliance.id, id)).returning();
        return NextResponse.json({ row });
      }
      default:
        return NextResponse.json({ error: "Cannot update this resource" }, { status: 400 });
    }
  } catch (err) {
    return NextResponse.json({ error: (err as Error).message }, { status: 400 });
  }
}

/* ------------------------------ DELETE ------------------------------ */

export async function DELETE(req: Request, { params }: Ctx) {
  if (!(await isAdmin())) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { resource } = await params;
  try {
    const b = (await req.json()) as Record<string, unknown>;
    const id = num(b.id);
    if (!id) return NextResponse.json({ error: "Missing id" }, { status: 400 });

    switch (resource) {
      case "articles":
        await db.delete(articles).where(eq(articles.id, id));
        return NextResponse.json({ ok: true });
      case "materials":
        await db.delete(materials).where(eq(materials.id, id));
        return NextResponse.json({ ok: true });
      case "categories":
        await db.delete(categories).where(eq(categories.id, id));
        return NextResponse.json({ ok: true });
      case "quotes":
        await db.delete(quotes).where(eq(quotes.id, id));
        return NextResponse.json({ ok: true });
      case "compliance":
        await db.delete(compliance).where(eq(compliance.id, id));
        return NextResponse.json({ ok: true });
      case "messages":
        await db.delete(messages).where(eq(messages.id, id));
        return NextResponse.json({ ok: true });
      case "uploads": {
        const [row] = await db.select().from(uploads).where(eq(uploads.id, id));
        if (row) {
          // storedName is "<folder>/<file>" in the project media tree; older rows
          // are flat names inside the legacy storage/uploads folder.
          const candidates = [
            path.join(MEDIA_ROOT, row.storedName),
            path.join(MEDIA_ROOT, row.storedName.replace(/\.stl$/i, ".glb")),
            path.join(LEGACY_ROOT, path.basename(row.storedName)),
            path.join(LEGACY_ROOT, path.basename(row.storedName).replace(/\.stl$/i, ".glb")),
          ];
          for (const abs of candidates) {
            try {
              await unlink(abs);
            } catch {
              /* file may already be gone */
            }
          }
          await db.delete(uploads).where(eq(uploads.id, id));
        }
        return NextResponse.json({ ok: true });
      }
      default:
        return NextResponse.json({ error: "Cannot delete this resource" }, { status: 400 });
    }
  } catch (err) {
    return NextResponse.json({ error: (err as Error).message }, { status: 400 });
  }
}
