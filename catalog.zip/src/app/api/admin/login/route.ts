import { NextResponse } from "next/server";
import { ADMIN_COOKIE, verifyLogin } from "@/lib/adminAuth";

export const dynamic = "force-dynamic";

/**
 * Dashboard sign-in. The password is checked against a scrypt hash stored in
 * the database (Admin → Settings → Dashboard security), never against a plain
 * string, and repeated failures lock the endpoint for 15 minutes.
 */
export async function POST(req: Request) {
  let password: unknown;
  try {
    const body = await req.json();
    password = body?.password;
  } catch {
    return NextResponse.json({ error: "Invalid request." }, { status: 400 });
  }
  if (typeof password !== "string" || !password) {
    return NextResponse.json({ error: "Enter the dashboard password." }, { status: 400 });
  }

  const result = await verifyLogin(password);
  if (!result.ok) {
    return NextResponse.json(
      { error: result.error, retryAfter: result.retryAfter ?? null },
      { status: result.status, headers: result.retryAfter ? { "Retry-After": String(result.retryAfter) } : undefined }
    );
  }

  const fwdProto = req.headers.get("x-forwarded-proto") || "";
  const isHttps = fwdProto.split(",")[0].trim() === "https" || new URL(req.url).protocol === "https:";
  const res = NextResponse.json({ ok: true });
  res.cookies.set(ADMIN_COOKIE, result.token, {
    httpOnly: true,
    sameSite: "lax",
    secure: isHttps,
    path: "/",
    maxAge: 60 * 60 * 12, // 12 hours — sign in again each working day
  });
  return res;
}
