import { isAdmin } from "@/lib/adminAuth";
import { getMailCfg, sendMail, wrapEmail } from "@/lib/mail";
import { getContactCfg, normalizeEmails } from "@/lib/contact";

export const dynamic = "force-dynamic";

/** Sends a test message with the currently configured SMTP mailbox. */
export async function POST(req: Request) {
  if (!(await isAdmin())) return Response.json({ error: "Admin access required." }, { status: 401 });

  let body: Record<string, unknown> = {};
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    body = {};
  }

  const [cfg, contact] = await Promise.all([getMailCfg(), getContactCfg()]);
  const to = normalizeEmails(body.to ?? "").length ? normalizeEmails(body.to) : contact.emails;

  const result = await sendMail({
    to,
    subject: "[E-Catalog] Test message — your mail server is connected",
    text: `This is a test from the Forward Sports e-catalog dashboard.\n\nMail server: ${cfg.host || "(not set)"}:${cfg.port}\nSending address: ${cfg.from || "(not set)"}\nDelivered to: ${to.join(", ")}\n\nIf you can read this, contact-form and quote-request e-mails will arrive here too.`,
    html: wrapEmail(
      "Test message delivered",
      "Your e-catalog mailbox is connected",
      `<tr><td style="padding:6px 0;color:#191614;font-size:14px">Mail server</td><td style="padding:6px 0;font-size:14px">${cfg.host || "(not set)"}:${cfg.port} (${cfg.secure ? "TLS" : "STARTTLS"})</td></tr>
       <tr><td style="padding:6px 0;color:#191614;font-size:14px">Sending address</td><td style="padding:6px 0;font-size:14px">${cfg.from || "(not set)"}</td></tr>
       <tr><td style="padding:6px 0;color:#191614;font-size:14px">Delivered to</td><td style="padding:6px 0;font-size:14px">${to.join(", ")}</td></tr>`,
      "",
      "Contact-form and quote-request e-mails will arrive in this inbox from now on."
    ),
  });

  return Response.json({ ok: result.sent, result });
}
