import { isAdmin } from "@/lib/adminAuth";
import { fetchRemoteFile, saveMedia, folderFor, extOf } from "@/lib/media";
import { db } from "@/db";
import { uploads } from "@/db/schema";

export const dynamic = "force-dynamic";

/**
 * Copies an EXTERNAL file (any http/https URL — a photo on a phone-linked web
 * album, a supplier's image, a Dropbox link…) into the project's own media
 * folders, so the catalog never depends on something outside the project.
 *
 * body: { url, folder?, field?, originalName? } -> { ok, url, folder, size }
 */
export async function POST(req: Request) {
  if (!(await isAdmin())) return Response.json({ error: "Admin access required." }, { status: 401 });
  let body: Record<string, unknown>;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return Response.json({ error: "Invalid request." }, { status: 400 });
  }
  const url = String(body.url ?? "").trim();
  if (!url) return Response.json({ error: "Provide a file URL." }, { status: 400 });

  try {
    const remote = await fetchRemoteFile(url);
    const folder = folderFor(remote.ext, String(body.folder ?? "") || null, String(body.field ?? "") || null);
    const originalName = String(body.originalName ?? "").trim() || remote.name;
    const saved = await saveMedia(remote.buf, {
      folder,
      originalName: extOf(originalName) ? originalName : `${originalName}.${remote.ext}`,
      field: String(body.field ?? "") || null,
    });

    try {
      await db.insert(uploads).values({
        originalName: originalName,
        storedName: `${saved.folder}/${saved.storedName}`,
        kind: folder === "models" ? "model" : folder === "designs" ? "design-file" : "image",
        size: saved.size,
        status: "linked",
        note: `imported from ${url.slice(0, 180)}`,
      });
    } catch {
      /* the file itself is what matters */
    }

    return Response.json({ ok: true, url: saved.url, folder: saved.folder, size: saved.size, source: url });
  } catch (err) {
    return Response.json({ error: (err as Error).message || "Import failed." }, { status: 400 });
  }
}
