import { eq } from "drizzle-orm";
import { db } from "@/db";
import { activity, articles, materials, messages, quotes } from "@/db/schema";
import { getContactCfg, quoteEmailHtml, quoteEmailText, sendMail } from "@/lib/mail";

export const dynamic = "force-dynamic";

const hits = new Map<string, number[]>();

function throttled(ip: string) {
  const now = Date.now();
  const arr = (hits.get(ip) ?? []).filter((t) => now - t < 60_000);
  arr.push(now);
  hits.set(ip, arr);
  return arr.length > 8;
}

/**
 * Quote request from the configurator. Stored as a quote AND as a message, then
 * e-mailed to the sales addresses configured in the dashboard.
 */
export async function POST(req: Request) {
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "unknown";
  if (throttled(ip)) {
    return Response.json({ error: "Too many requests — please try again in a minute." }, { status: 429 });
  }
  try {
    const b = await req.json();
    const customerName = String(b.customerName ?? "").trim();
    const email = String(b.email ?? "").trim();
    const phone = String(b.phone ?? "").trim();
    const company = String(b.company ?? "").trim();
    const quantity = Number(b.quantity ?? 0);
    const unitPrice = Number(b.unitPrice ?? 0);
    const total = Number(b.total ?? 0);
    const message = String(b.message ?? "").slice(0, 2000);

    if (!customerName || customerName.length < 2)
      return Response.json({ error: "Please provide your name." }, { status: 400 });
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))
      return Response.json({ error: "Please provide a valid business email." }, { status: 400 });
    if (!Number.isFinite(quantity) || quantity < 1)
      return Response.json({ error: "Quantity must be at least 1." }, { status: 400 });
    if (!Number.isFinite(unitPrice) || unitPrice < 0)
      return Response.json({ error: "Invalid pricing payload." }, { status: 400 });

    const ref = `FSQ-${Date.now().toString(36).toUpperCase()}${Math.floor(Math.random() * 90 + 10)}`;

    const articleId = b.articleId ? Number(b.articleId) : null;
    const materialId = b.materialId ? Number(b.materialId) : null;
    const [art, mat] = await Promise.all([
      articleId ? db.query.articles.findFirst({ where: eq(articles.id, articleId) }) : Promise.resolve(undefined),
      materialId ? db.query.materials.findFirst({ where: eq(materials.id, materialId) }) : Promise.resolve(undefined),
    ]);
    const articleLabel = art ? `${art.name} (${art.articleNo})` : "";
    const materialLabel = mat ? `${mat.name} — ${mat.finish}` : "";
    const unit = unitPrice.toFixed(2);
    const totalStr = (Number.isFinite(total) ? total : unitPrice * quantity).toFixed(2);
    const logoName = b.logoName ? String(b.logoName).slice(0, 200) : null;

    const [quote] = await db
      .insert(quotes)
      .values({
        ref,
        articleId,
        materialId,
        customerName,
        company,
        email,
        quantity: Math.round(quantity),
        unitPrice: unit,
        total: totalStr,
        logoName,
        message,
      })
      .returning();

    const contact = await getContactCfg();
    const [msg] = await db
      .insert(messages)
      .values({
        kind: "quote",
        ref,
        name: customerName,
        email,
        phone,
        company,
        subject: `Quote request — ${articleLabel || "catalog article"}`,
        body: message,
        articleId,
        articleLabel,
        quoteId: quote.id,
        meta: {
          material: materialLabel,
          quantity: Math.round(quantity),
          unitPrice: unit,
          total: totalStr,
          logo: logoName || "",
          ip,
          sentTo: contact.emails,
        },
        delivered: false,
      })
      .returning();

    const mail = await sendMail({
      to: contact.emails,
      subject: `[Quote ${ref}] ${articleLabel || "Catalog"} · ${Math.round(quantity).toLocaleString()} units · ${customerName}`,
      text: quoteEmailText({
        ref,
        name: customerName,
        email,
        company,
        phone,
        article: articleLabel,
        material: materialLabel,
        quantity: Math.round(quantity),
        unit: `USD ${unit}`,
        total: `USD ${totalStr}`,
        logo: logoName || undefined,
        message,
      }),
      html: quoteEmailHtml({
        ref,
        name: customerName,
        email,
        company,
        phone,
        article: articleLabel,
        material: materialLabel,
        quantity: Math.round(quantity),
        unit: `USD ${unit}`,
        total: `USD ${totalStr}`,
        logo: logoName || undefined,
        message,
      }),
      replyTo: email,
    });

    await db
      .update(messages)
      .set({ delivered: mail.sent, deliveryNote: mail.sent ? `E-mailed to ${mail.to.join(", ")}` : mail.error || mail.status })
      .where(eq(messages.id, msg.id));

    await db.insert(activity).values({
      event: "quote_request",
      refId: articleId ? String(articleId) : null,
      payload: { ref, quantity: Math.round(quantity), email, delivered: mail.sent },
    });

    return Response.json({ ok: true, ref, delivered: mail.sent, sentTo: contact.emails });
  } catch (err) {
    console.error("[quote]", err);
    return Response.json({ error: "Could not submit the request. Please try again." }, { status: 500 });
  }
}
