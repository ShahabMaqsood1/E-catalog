import { isAdmin } from "@/lib/adminAuth";
import { db } from "@/db";
import { uploads } from "@/db/schema";
import {
  ALL_EXTS,
  DESIGN_EXTS,
  MODEL_EXTS,
  extOf,
  folderFor,
  saveMedia,
  type MediaFolder,
} from "@/lib/media";

export const dynamic = "force-dynamic";

const MAX_BYTES = 60 * 1024 * 1024;

/**
 * Admin upload. Files are written INSIDE the project tree
 * (`public/media/<folder>/`) so they survive a project download/copy and are
 * never lost between machines:
 *
 *   rexine/  material swatch photos      models/  article 3D models
 *   renders/ static render images        artwork/ wrap artwork
 *   layers/  exploded-view layer photos  brand/   logos & icons
 *   designs/ CorelDRAW & source files    misc/    everything else
 *
 * Optional form fields: `folder` (force a destination) and `field` (the DB
 * column the file is for — used to guess the folder automatically).
 */
export async function POST(req: Request) {
  if (!(await isAdmin())) {
    return Response.json({ error: "Admin access required." }, { status: 401 });
  }
  try {
    const form = await req.formData();
    const file = form.get("file");
    const folderHint = String(form.get("folder") ?? "") || null;
    const fieldHint = String(form.get("field") ?? "") || null;

    if (!(file instanceof File)) {
      return Response.json({ error: "No file provided." }, { status: 400 });
    }
    if (file.size > MAX_BYTES) {
      return Response.json({ error: "File must be under 60 MB." }, { status: 400 });
    }
    const ext = extOf(file.name);
    if (!ALL_EXTS.has(ext)) {
      return Response.json(
        {
          error:
            "Allowed files: CorelDRAW (.cdr), .ai, .eps, .pdf, .svg, 3D models (.glb/.gltf/.obj/.stl) or images (png/jpg/jpeg/webp/gif/ico).",
        },
        { status: 400 }
      );
    }

    const folder: MediaFolder = folderFor(ext, folderHint, fieldHint);
    const buf = Buffer.from(await file.arrayBuffer());
    const saved = await saveMedia(buf, { folder, originalName: file.name || `upload.${ext}`, field: fieldHint });

    // STL files are far too heavy for browsers — convert to a light, UV-mapped
    // GLB on the server right away. The article stores the GLB, not the STL.
    let derivedUrl: string | null = null;
    if (ext === "stl") {
      try {
        const { normalizeStlToGlb } = await import("@/lib/stlNormalize");
        const glbName = saved.storedName.replace(/\.stl$/i, ".glb");
        const stats = await normalizeStlToGlb(saved.absPath, `${saved.absPath.replace(/\.stl$/i, ".glb")}`);
        if (stats) {
          derivedUrl = `/api/files/${saved.folder}/${glbName}`;
          console.log(`[stl-normalize] ${file.name}: ${stats.triangles} tris -> ${saved.folder}/${glbName}`);
        }
      } catch (err) {
        console.warn("[stl-normalize] skipped:", (err as Error).message?.slice(0, 160));
      }
    }

    const relPath = `${saved.folder}/${saved.storedName}`;
    const [row] = await db
      .insert(uploads)
      .values({
        originalName: file.name,
        storedName: relPath,
        kind: MODEL_EXTS.has(ext) ? "model" : DESIGN_EXTS.has(ext) ? "design-file" : "image",
        size: file.size,
        status: "received",
        note: derivedUrl ? "normalized to glb on upload" : `stored in public/media/${saved.folder}`,
      })
      .returning();

    return Response.json({
      ok: true,
      upload: { ...row, url: saved.url, folder: saved.folder, storedName: relPath },
      url: saved.url,
      folder: saved.folder,
      derivedUrl,
      // kept for older clients
      derived: derivedUrl ? { glb: { url: derivedUrl } } : null,
    });
  } catch (err) {
    console.error("[upload]", err);
    return Response.json({ error: "Upload failed." }, { status: 500 });
  }
}
