import { db } from "@/db";
import { activity, articles, messages } from "@/db/schema";
import { eq } from "drizzle-orm";
import {
  contactEmailHtml,
  contactEmailText,
  getContactCfg,
  sendMail,
} from "@/lib/mail";

export const dynamic = "force-dynamic";

/** Tiny in-memory throttle: 5 messages per minute per visitor. */
const hits = new Map<string, number[]>();

function throttled(ip: string) {
  const now = Date.now();
  const arr = (hits.get(ip) ?? []).filter((t) => now - t < 60_000);
  arr.push(now);
  hits.set(ip, arr);
  if (hits.size > 500) for (const [k, v] of hits) if (!v.length) hits.delete(k);
  return arr.length > 5;
}

/**
 * Public contact form. The message is ALWAYS stored in the `messages` table
 * first (visible in Admin → Inbox & mail), then e-mailed to the addresses
 * configured in the dashboard (defaults: hassanqulaba@forward.pk and
 * adeel@forward.pk). If no SMTP server is set up yet the row stays marked
 * "not delivered" instead of being lost.
 */
export async function POST(req: Request) {
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "unknown";
  if (throttled(ip)) {
    return Response.json({ error: "Too many messages — please try again in a minute." }, { status: 429 });
  }

  let b: Record<string, unknown> = {};
  try {
    b = (await req.json()) as Record<string, unknown>;
  } catch {
    return Response.json({ error: "Invalid request." }, { status: 400 });
  }

  // honeypot — bots fill it, humans never see it
  if (String(b.website ?? "").trim()) return Response.json({ ok: true, ref: "ignored" });

  const name = String(b.name ?? "").trim();
  const email = String(b.email ?? "").trim().toLowerCase();
  const phone = String(b.phone ?? "").trim();
  const company = String(b.company ?? "").trim();
  const subject = String(b.subject ?? "").trim().slice(0, 160);
  const message = String(b.message ?? "").trim().slice(0, 4000);
  const articleId = b.articleId ? Number(b.articleId) : null;

  if (name.length < 2) return Response.json({ error: "Please tell us your name." }, { status: 400 });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return Response.json({ error: "Please provide a valid email address." }, { status: 400 });
  if (message.length < 10) return Response.json({ error: "Please write a short message (10 characters or more)." }, { status: 400 });

  let articleLabel = "";
  if (articleId) {
    try {
      const row = await db.query.articles.findFirst({ where: eq(articles.id, articleId) });
      articleLabel = row ? `${row.name} (${row.articleNo})` : "";
    } catch {
      articleLabel = "";
    }
  }

  const contact = await getContactCfg();
  const ref = `FSM-${Date.now().toString(36).toUpperCase()}${Math.floor(Math.random() * 90 + 10)}`;

  const [row] = await db
    .insert(messages)
    .values({
      kind: "contact",
      ref,
      name,
      email,
      phone,
      company,
      subject: subject || "Catalog enquiry",
      body: message,
      articleId: articleId && articleLabel ? articleId : null,
      articleLabel,
      meta: { ip, userAgent: (req.headers.get("user-agent") || "").slice(0, 200), sentTo: contact.emails },
      status: "new",
      delivered: false,
      deliveryNote: "",
    })
    .returning();

  const mail = await sendMail({
    to: contact.emails,
    subject: `[E-Catalog] ${subject || "Catalog enquiry"} — ${name}`,
    text: contactEmailText({ name, email, phone, company, subject, message, article: articleLabel }),
    html: contactEmailHtml({ name, email, phone, company, subject, message, article: articleLabel }),
    replyTo: email,
  });

  await db
    .update(messages)
    .set({ delivered: mail.sent, deliveryNote: mail.sent ? `E-mailed to ${mail.to.join(", ")}` : mail.error || mail.status })
    .where(eq(messages.id, row.id));

  await db.insert(activity).values({
    event: "contact_message",
    refId: String(row.id),
    payload: { ref, email, delivered: mail.sent, article: articleLabel },
  });

  return Response.json({
    ok: true,
    ref,
    delivered: mail.sent,
    note: mail.sent
      ? `Thanks ${name.split(" ")[0]} — your message is on its way to our sales team.`
      : `Thanks ${name.split(" ")[0]} — your message is saved with our team and will be answered shortly.`,
    sentTo: contact.emails,
  });
}
