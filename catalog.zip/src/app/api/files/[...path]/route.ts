import { readStored, mimeFor } from "@/lib/media";

export const dynamic = "force-dynamic";

/**
 * Serves every stored file.
 *
 *   /api/files/rexine/swatch-ab12.png   -> public/media/rexine/swatch-ab12.png
 *   /api/files/models/mock-fs-tb-01.glb -> public/media/models/mock-fs-tb-01.glb
 *   /api/files/1699999-abc.png          -> legacy storage/uploads/1699999-abc.png
 *
 * Reading straight from disk on every request means files added AFTER a build
 * (uploads, imported assets) are served immediately — no rebuild, no restart.
 */
export async function GET(_req: Request, ctx: { params: Promise<{ path: string[] }> }) {
  const { path: segments } = await ctx.params;
  const rel = (segments || []).join("/");
  if (!rel) return Response.json({ error: "Invalid file path." }, { status: 400 });

  const found = await readStored(rel);
  if (!found) return Response.json({ error: "File not found." }, { status: 404 });

  const name = found.absPath.split("/").pop() || rel;
  return new Response(new Uint8Array(found.buf), {
    headers: {
      "Content-Type": mimeFor(name),
      "Content-Length": String(found.buf.length),
      "Cache-Control": "public, max-age=31536000, immutable",
    },
  });
}
