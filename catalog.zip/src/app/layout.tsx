import type { Metadata } from "next";
import type { ReactNode } from "react";
import "@fontsource-variable/archivo";
import "@fontsource-variable/manrope";
import "@fontsource-variable/dm-sans";
import "./globals.css";
import { TourProvider } from "@/components/Tour";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

/** Every page renders per request so dashboard edits are live on the next refresh. */
export const dynamic = "force-dynamic";

/**
 * Brand assets are real files inside the project (`public/brand/`, downloaded
 * from forward.pk) — the logo is not uploadable from the dashboard, so what you
 * see is always what ships with the code.
 */
export const metadata: Metadata = {
  title: "Forward Sports — Product Catalog | The Soccer Expert",
  description:
    "Official product catalog of Forward Sports, Sialkot — configure hand-stitched, machine-stitched, thermal-bonded, hybrid, mini, volleyball and medicine balls in live 3D with real rexine materials. Company profile, facilities and team: forward.pk.",
  icons: {
    icon: "/brand/favicon.ico",
    shortcut: "/brand/favicon.ico",
    apple: "/brand/forward-logo.png",
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-paper text-ink-900 font-ui antialiased">
        <TourProvider>
          <Header />
          {children}
          <Footer />
        </TourProvider>
      </body>
    </html>
  );
}
