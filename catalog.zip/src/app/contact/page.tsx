import Link from "next/link";
import { ArrowRight, Clock, ExternalLink, Mail, MapPin, MessageSquare, Phone } from "lucide-react";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { articles } from "@/db/schema";
import { getContactCfg } from "@/lib/contact";
import { getContent } from "@/lib/content";
import ContactForm from "@/components/ContactForm";

export const dynamic = "force-dynamic";

export const metadata = {
  title: "Contact the sales team — Forward Sports Product Catalog",
  description:
    "Enquiries, quotes, sampling and private-label requests: hassanqulaba@forward.pk and adeel@forward.pk, +92 345 6680616.",
};

export default async function ContactPage({ searchParams }: { searchParams: Promise<{ articleId?: string }> }) {
  const sp = await searchParams;
  const [contact, content, arts] = await Promise.all([
    getContactCfg(),
    getContent(),
    db.select().from(articles).where(eq(articles.status, "live")).orderBy(articles.id),
  ]);
  const prefill = Number(sp.articleId) || null;

  return (
    <main>
      {/* header */}
      <section className="border-b border-line bg-ink-950 text-white">
        <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6">
          <p className="text-xs font-extrabold uppercase tracking-[0.28em] text-brand-400">Contact us</p>
          <h1 className="mt-2 max-w-3xl font-display text-3xl font-black uppercase leading-tight tracking-tight sm:text-4xl">
            Talk to the people who make the balls
          </h1>
          <p className="mt-4 max-w-2xl text-sm leading-relaxed text-white/65">
            Quotes, sampling, private-label production and article questions all come to the same two
            inboxes below. Attach an article number from the catalog and we can answer with pricing,
            MOQ and lead time straight away.
          </p>
          <div className="mt-6 flex flex-wrap gap-3">
            <Link
              href="/catalog"
              className="inline-flex items-center gap-2 rounded-xl bg-brand-600 px-5 py-3 font-display text-xs font-extrabold uppercase tracking-widest text-white transition hover:bg-brand-500"
            >
              Open the catalog <ArrowRight className="h-4 w-4" />
            </Link>
            <a
              href="https://forward.pk"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 rounded-xl border border-white/20 px-5 py-3 font-display text-xs font-extrabold uppercase tracking-widest text-white/80 transition hover:border-brand-400 hover:text-white"
            >
              forward.pk — company website <ExternalLink className="h-3.5 w-3.5" />
            </a>
          </div>
        </div>
      </section>

      <div className="mx-auto grid max-w-7xl gap-8 px-4 py-12 sm:px-6 lg:grid-cols-[minmax(0,1fr)_380px]">
        <div className="min-w-0">
          <ContactForm sentTo={contact.emails} articles={arts.map((a) => ({ id: a.id, name: a.name, articleNo: a.articleNo }))} prefillArticleId={prefill} />

          <div data-tour="contact-after" className="mt-6 rounded-2xl border border-line bg-card p-6">
            <h2 className="font-display text-sm font-extrabold uppercase tracking-[0.18em] text-ink-950">
              What happens next
            </h2>
            <ol className="mt-4 grid gap-4 sm:grid-cols-3">
              {[
                ["1 · Stored", "Your message is written into the Forward Sports dashboard inbox the moment you press send, so it can never be lost."],
                ["2 · Delivered", `It is e-mailed to ${contact.emails.join(" and ")} with your address set as Reply-To.`],
                ["3 · Answered", `${contact.responseNote} Expect FOB pricing, MOQ, sampling options and lead time for your quantity.`],
              ].map(([t, d]) => (
                <li key={t} className="rounded-xl border border-line bg-paper p-4">
                  <p className="font-display text-xs font-extrabold uppercase tracking-wider text-brand-700">{t}</p>
                  <p className="mt-1.5 text-xs leading-relaxed text-ink-600">{d}</p>
                </li>
              ))}
            </ol>
            <p className="mt-4 text-xs leading-relaxed text-ink-500">
              Already configured a ball in the 3D studio? Use{" "}
              <b className="font-extrabold text-ink-700">Request quote</b> there — it sends the article,
              rexine, quantity, logo and price together with your details.
            </p>
          </div>
        </div>

        {/* details rail */}
        <aside data-tour="contact-details" className="space-y-5">
          <div className="rounded-2xl border border-line bg-card p-6">
            <h2 className="font-display text-sm font-extrabold uppercase tracking-[0.18em] text-ink-950">
              Sales desk
            </h2>
            <ul className="mt-4 space-y-4 text-sm">
              {contact.emails.map((e) => (
                <li key={e} className="flex items-start gap-3">
                  <span className="mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-brand-600/10 text-brand-700">
                    <Mail className="h-4 w-4" />
                  </span>
                  <span className="min-w-0">
                    <span className="block text-[10px] font-extrabold uppercase tracking-wider text-ink-400">Email</span>
                    <a href={`mailto:${e}`} className="block break-all font-semibold text-ink-900 hover:text-brand-700">
                      {e}
                    </a>
                  </span>
                </li>
              ))}
              <li className="flex items-start gap-3">
                <span className="mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-brand-600/10 text-brand-700">
                  <Phone className="h-4 w-4" />
                </span>
                <span>
                  <span className="block text-[10px] font-extrabold uppercase tracking-wider text-ink-400">
                    Phone / WhatsApp
                  </span>
                  <a href={`tel:${contact.phoneHref}`} className="block font-semibold text-ink-900 hover:text-brand-700">
                    {contact.phone}
                  </a>
                </span>
              </li>
              <li className="flex items-start gap-3">
                <span className="mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-ink-100 text-ink-600">
                  <MapPin className="h-4 w-4" />
                </span>
                <span>
                  <span className="block text-[10px] font-extrabold uppercase tracking-wider text-ink-400">Factory</span>
                  <span className="block font-semibold text-ink-900">{contact.address}</span>
                </span>
              </li>
              <li className="flex items-start gap-3">
                <span className="mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-ink-100 text-ink-600">
                  <Clock className="h-4 w-4" />
                </span>
                <span>
                  <span className="block text-[10px] font-extrabold uppercase tracking-wider text-ink-400">Hours</span>
                  <span className="block font-semibold text-ink-900">{contact.hours}</span>
                </span>
              </li>
            </ul>
            <a
              href={`https://wa.me/${contact.phoneHref.replace("+", "")}`}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-5 flex items-center justify-center gap-2 rounded-xl border border-line bg-paper px-4 py-3 font-display text-xs font-extrabold uppercase tracking-widest text-ink-700 transition hover:border-ok hover:text-ok"
            >
              <MessageSquare className="h-4 w-4" /> WhatsApp the sales desk
            </a>
          </div>

          <div className="rounded-2xl border border-line bg-paper-deep p-6">
            <h2 className="font-display text-sm font-extrabold uppercase tracking-[0.18em] text-ink-950">
              Everything else
            </h2>
            <p className="mt-2 text-xs leading-relaxed text-ink-600">
              {content["footer.about"]}
            </p>
            <p className="mt-3 text-xs leading-relaxed text-ink-500">
              Facilities, certifications, the team and the 360° factory tour are on the company
              website.
            </p>
            <a
              href="https://forward.pk"
              target="_blank"
              rel="noopener noreferrer"
              className="mt-4 inline-flex items-center gap-2 text-xs font-extrabold uppercase tracking-wider text-brand-700 hover:text-brand-600"
            >
              forward.pk <ExternalLink className="h-3.5 w-3.5" />
            </a>
          </div>
        </aside>
      </div>
    </main>
  );
}
