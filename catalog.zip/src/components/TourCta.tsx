"use client";

import { Compass } from "lucide-react";
import { useTour } from "@/components/Tour";
import type { TourId } from "@/lib/tour-steps";
import { cn } from "@/lib/utils";

/**
 * Loud "guided tour" entry point (item 5). Sits in the hero and in the footer of
 * the catalog so a first-time visitor always finds it; the pulsing dot appears
 * until the tour for this page has been completed once.
 */
export default function TourCta({
  tour = "home",
  label = "Take the guided tour",
  variant = "dark",
  className,
}: {
  tour?: TourId;
  label?: string;
  variant?: "dark" | "light";
  className?: string;
}) {
  const { startTour, isActive, seen } = useTour();
  return (
    <button
      type="button"
      onClick={() => startTour(tour)}
      disabled={isActive}
      className={cn(
        "group relative flex items-center gap-2 rounded-xl px-6 py-3.5 font-display text-sm font-extrabold uppercase tracking-widest transition disabled:opacity-60",
        variant === "dark"
          ? "border border-brand-400/60 bg-brand-600/20 text-white hover:bg-brand-600"
          : "border border-brand-600 bg-brand-600/5 text-brand-700 hover:bg-brand-600 hover:text-white",
        className
      )}
      title="A guided walkthrough that operates the catalog for you"
    >
      <Compass className="h-4 w-4 transition group-hover:rotate-45" />
      {label}
      {!seen && (
        <span className="absolute -right-1.5 -top-1.5 flex h-3 w-3">
          <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-brand-400 opacity-75" />
          <span className="relative inline-flex h-3 w-3 rounded-full bg-brand-500 ring-2 ring-ink-950/40" />
        </span>
      )}
    </button>
  );
}
