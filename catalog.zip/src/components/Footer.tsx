import Link from "next/link";
import { ExternalLink, Mail, MapPin, MessageSquare, Phone } from "lucide-react";
import { getContent } from "@/lib/content";
import { getContactCfg } from "@/lib/contact";

const CATEGORIES = [
  { slug: "hand-stitched", name: "Hand-Stitched" },
  { slug: "machine-stitched", name: "Machine-Stitched" },
  { slug: "thermal-bonded", name: "Thermal-Bonded" },
  { slug: "hybrid", name: "Hybrid" },
  { slug: "amb-mini", name: "AMB / Mini Balls" },
  { slug: "volleyballs", name: "Volleyballs" },
  { slug: "medicine-balls", name: "Medicine Balls" },
];

const EXPLORE: Array<[string, string]> = [
  ["forward.pk — main website", "https://forward.pk"],
  ["Virtual factory tour", "https://forward.pk"],
  ["Team & experts", "https://forward.pk"],
  ["CSR & environment", "https://forward.pk/CSR"],
];

export default async function Footer() {
  const [c, contact] = await Promise.all([getContent(), getContactCfg()]);
  return (
    <footer className="bg-ink-950 text-white/70">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-14 sm:px-6 md:grid-cols-2 lg:grid-cols-4">
        <div>
          <div className="flex items-center gap-3">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src="/brand/forward-logo-white.png" alt="Forward Sports" className="h-9 w-auto" />
            <span className="font-display text-[10px] font-black uppercase tracking-[0.24em] text-white/55">
              Product Catalog
            </span>
          </div>
          <p className="mt-4 max-w-xs text-sm leading-relaxed">{c["footer.about"]}</p>
          <p className="mt-4 flex items-start gap-2 text-xs">
            <MapPin className="mt-0.5 h-3.5 w-3.5 shrink-0 text-brand-400" />
            {contact.address}
          </p>
        </div>

        <div>
          <h4 className="font-display text-xs font-extrabold uppercase tracking-[0.22em] text-white">Constructions</h4>
          <ul className="mt-4 space-y-2.5 text-sm">
            {CATEGORIES.map((cat) => (
              <li key={cat.slug}>
                <Link href={`/catalog#${cat.slug}`} className="transition hover:text-brand-400">
                  {cat.name}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h4 className="font-display text-xs font-extrabold uppercase tracking-[0.22em] text-white">
            Explore Forward Sports
          </h4>
          <p className="mt-4 text-xs leading-relaxed text-white/50">
            This site is the product catalog only. Our equipment, facilities, staff, certifications
            and the 360° factory tour live on the company website.
          </p>
          <ul className="mt-4 space-y-2.5 text-sm">
            {EXPLORE.map(([label, href]) => (
              <li key={label}>
                <a
                  href={href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 transition hover:text-brand-400"
                >
                  <ExternalLink className="h-3.5 w-3.5 text-brand-400" />
                  {label}
                </a>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h4 className="font-display text-xs font-extrabold uppercase tracking-[0.22em] text-white">Contact</h4>
          <ul className="mt-4 space-y-3 text-sm">
            {contact.emails.map((e) => (
              <li key={e} className="flex items-center gap-2.5">
                <Mail className="h-4 w-4 shrink-0 text-brand-400" />
                <a href={`mailto:${e}`} className="break-all hover:text-brand-400">
                  {e}
                </a>
              </li>
            ))}
            <li className="flex items-center gap-2.5">
              <Phone className="h-4 w-4 shrink-0 text-brand-400" />
              <a href={`tel:${contact.phoneHref}`} className="hover:text-brand-400">
                {contact.phone}
              </a>
            </li>
            <li className="text-xs text-white/50">{contact.hours}</li>
          </ul>
          <div className="mt-6 flex flex-wrap gap-2">
            <Link
              href="/contact"
              className="inline-flex items-center gap-2 rounded-lg bg-brand-600 px-5 py-2.5 font-display text-xs font-extrabold uppercase tracking-widest text-white transition hover:bg-brand-500"
            >
              <MessageSquare className="h-3.5 w-3.5" /> Contact us
            </Link>
            <Link
              href="/catalog"
              className="inline-flex items-center gap-2 rounded-lg border border-white/20 px-5 py-2.5 font-display text-xs font-extrabold uppercase tracking-widest text-white/80 transition hover:border-brand-400 hover:text-white"
            >
              {c["home.ctaPrimary"]}
            </Link>
          </div>
        </div>
      </div>

      <div className="border-t border-white/10">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-2 px-4 py-5 text-xs text-white/45 sm:flex-row sm:px-6">
          <p>{c["footer.copyright"]}</p>
          <p>
            {c["footer.craftLine"]} ·{" "}
            <a href="https://forward.pk" className="underline-offset-2 hover:text-brand-400 hover:underline">
              forward.pk
            </a>
          </p>
        </div>
      </div>
    </footer>
  );
}
