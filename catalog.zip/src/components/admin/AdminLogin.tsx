"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { Eye, EyeOff, KeyRound, LifeBuoy, ShieldCheck } from "lucide-react";

export default function AdminLogin() {
  const router = useRouter();
  const [password, setPassword] = useState("");
  const [show, setShow] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const res = await fetch("/api/admin/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Login failed");
      router.refresh();
    } catch (err) {
      setError((err as Error).message);
      setBusy(false);
    }
  };

  return (
    <main className="mx-auto grid min-h-[70vh] max-w-7xl place-items-center px-4 py-16">
      <div className="w-full max-w-md">
        <div className="rounded-2xl border border-line bg-card p-8 shadow-sm">
          <span className="grid h-12 w-12 place-items-center rounded-xl bg-ink-950 text-white">
            <ShieldCheck className="h-6 w-6" />
          </span>
          <h1 className="mt-5 font-display text-2xl font-black uppercase tracking-tight text-ink-950">
            Admin studio
          </h1>
          <p className="mt-1.5 text-sm text-ink-500">
            Restricted area — a strong dashboard password is required (12+ characters, upper &amp;
            lower case, a number and a symbol). Six wrong attempts lock the door for 15 minutes.
          </p>
          <form onSubmit={submit} className="mt-6 space-y-4">
            <label className="block">
              <span className="mb-1 block text-[11px] font-extrabold uppercase tracking-wider text-ink-500">
                Password
              </span>
              <span className="relative block">
                <input
                  type={show ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  autoFocus
                  autoComplete="current-password"
                  className="w-full rounded-lg border border-line bg-paper px-3 py-2.5 pr-11 text-sm outline-none focus:border-brand-500"
                  placeholder="••••••••••"
                />
                <button
                  type="button"
                  onClick={() => setShow((v) => !v)}
                  aria-label={show ? "Hide password" : "Show password"}
                  className="absolute inset-y-0 right-0 grid w-11 place-items-center text-ink-400 hover:text-ink-700"
                >
                  {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </span>
            </label>
            {error && <p className="text-xs font-bold text-danger">{error}</p>}
            <button
              type="submit"
              disabled={busy}
              className="flex w-full items-center justify-center gap-2 rounded-xl bg-brand-600 px-5 py-3 font-display text-sm font-extrabold uppercase tracking-widest text-white transition hover:bg-brand-500 disabled:opacity-60"
            >
              <KeyRound className="h-4 w-4" />
              {busy ? "Checking…" : "Enter dashboard"}
            </button>
          </form>

          <details className="mt-5 rounded-xl border border-line bg-paper p-4 text-xs leading-relaxed text-ink-600">
            <summary className="flex cursor-pointer items-center gap-2 font-extrabold uppercase tracking-wider text-ink-800">
              <LifeBuoy className="h-4 w-4 text-brand-600" />
              Password not working?
            </summary>
            <ol className="mt-3 list-decimal space-y-2 pl-4">
              <li>
                The password lives in <b>.env</b> as <code className="font-mono">ADMIN_PASSWORD</code>{" "}
                (default <code className="font-mono">Fwd@Catalog2026!</code>). It is re-adopted on
                every start until you set your own inside the dashboard.
              </li>
              <li>
                Running with Docker? Pass it through <code className="font-mono">docker-compose.yml</code>{" "}
                / <code className="font-mono">.env</code> and run{" "}
                <code className="font-mono">docker compose up -d --force-recreate web</code>. A weak
                value (like <code className="font-mono">forward2026</code>) is rejected, and the app
                then generates a random one — that is the usual cause of a failed sign-in.
              </li>
              <li>
                Still locked out? Run{" "}
                <code className="font-mono">node scripts/reset-admin-password.mjs &quot;My@NewPass123&quot;</code>{" "}
                in the project folder — it resets the hash, clears the lockout and signs out every
                device. A generated password is also written to{" "}
                <code className="font-mono">storage/admin-recovery.txt</code>.
              </li>
              <li>
                Signed in? Change it under <b>Security → Dashboard password</b>. That value is stored
                hashed in the database and always wins over the file.
              </li>
            </ol>
          </details>
        </div>
      </div>
    </main>
  );
}
