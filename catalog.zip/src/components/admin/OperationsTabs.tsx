"use client";

import { useCallback, useEffect, useState } from "react";
import {
  CheckCircle2,
  DownloadCloud,
  FolderOpen,
  Inbox,
  KeyRound,
  Loader2,
  Mail,
  MailWarning,
  RefreshCw,
  Save,
  Send,
  ShieldAlert,
  ShieldCheck,
  Trash2,
} from "lucide-react";
import { api, Badge, bytes, Field, inputCls, Toggle } from "@/components/admin/ui";
import { cn, timeAgo } from "@/lib/utils";

type Notify = (m: string, k?: "ok" | "err") => void;

/* ------------------------------------------------------------------ types -- */

type MailCfg = {
  enabled: boolean;
  host: string;
  port: number;
  secure: boolean;
  user: string;
  pass: string;
  from: string;
  fromName: string;
  replyTo: string;
  lastStatus: string;
  lastError: string;
  lastSentAt: string;
};

type ContactCfg = {
  emails: string[];
  phone: string;
  phoneHref: string;
  whatsapp: string;
  address: string;
  hours: string;
  responseNote: string;
};

type MessageRow = {
  id: number;
  kind: string;
  ref: string | null;
  name: string;
  email: string;
  phone: string;
  company: string;
  subject: string;
  body: string;
  articleLabel: string;
  status: string;
  delivered: boolean;
  deliveryNote: string;
  createdAt: string;
};

type MediaGroup = {
  folder: string;
  label: string;
  files: number;
  bytes: number;
  items: Array<{ name: string; url: string; size: number; modified: string }>;
};

type CredInfo = {
  configured: boolean;
  source: string;
  updatedAt: string;
  epoch: number;
  fails: number;
  lockedUntil: string | null;
  lastOkAt: string | null;
  minLength: number;
  envUsable: boolean;
  envIssues: string[];
  maxFails: number;
  lockMinutes: number;
};

const DEFAULT_MAIL: MailCfg = {
  enabled: false,
  host: "",
  port: 587,
  secure: false,
  user: "",
  pass: "",
  from: "",
  fromName: "Forward Sports E-Catalog",
  replyTo: "",
  lastStatus: "never",
  lastError: "",
  lastSentAt: "",
};

const DEFAULT_CONTACT: ContactCfg = {
  emails: ["hassanqulaba@forward.pk", "adeel@forward.pk"],
  phone: "+92 345 6680616",
  phoneHref: "+923456680616",
  whatsapp: "+92 345 6680616",
  address: "Forward Sports (Pvt) Ltd — Sialkot, Pakistan",
  hours: "Monday – Saturday, 9:00 – 18:00 PKT",
  responseNote: "Quotes are answered within one working day.",
};

function Card({
  title,
  icon,
  note,
  children,
}: {
  title: string;
  icon?: React.ReactNode;
  note?: string;
  children: React.ReactNode;
}) {
  return (
    <section className="rounded-2xl border border-line bg-card p-6">
      <header className="mb-4 flex items-start gap-3">
        {icon && <span className="mt-0.5 grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-ink-950 text-white">{icon}</span>}
        <div className="min-w-0">
          <h2 className="font-display text-sm font-extrabold uppercase tracking-[0.18em] text-ink-950">{title}</h2>
          {note && <p className="mt-1 text-xs leading-relaxed text-ink-500">{note}</p>}
        </div>
      </header>
      {children}
    </section>
  );
}

function SaveBar({ busy, onSave, label = "Save" }: { busy: boolean; onSave: () => void; label?: string }) {
  return (
    <button
      onClick={onSave}
      disabled={busy}
      className="flex items-center gap-2 rounded-xl bg-brand-600 px-5 py-2.5 font-display text-xs font-extrabold uppercase tracking-widest text-white hover:bg-brand-500 disabled:opacity-60"
    >
      {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
      {busy ? "Saving…" : label}
    </button>
  );
}

/* ------------------------------------------------- Inbox & mail (item 8) --- */

export function InboxMailTab({ notify }: { notify: Notify }) {
  const [mail, setMail] = useState<MailCfg>(DEFAULT_MAIL);
  const [contact, setContact] = useState<ContactCfg>(DEFAULT_CONTACT);
  const [emailsText, setEmailsText] = useState(DEFAULT_CONTACT.emails.join("\n"));
  const [rows, setRows] = useState<MessageRow[]>([]);
  const [loaded, setLoaded] = useState(false);
  const [busy, setBusy] = useState<"mail" | "contact" | "test" | null>(null);
  const [testTo, setTestTo] = useState("");
  const [filter, setFilter] = useState<"all" | "undelivered" | "contact" | "quote">("all");

  const load = useCallback(async () => {
    const [s, m] = await Promise.all([
      api<Record<string, unknown>>("GET", "settings"),
      api<{ rows: MessageRow[] }>("GET", "messages"),
    ]);
    const mc = { ...DEFAULT_MAIL, ...((s.mail as object) ?? {}) } as MailCfg;
    const cc = { ...DEFAULT_CONTACT, ...((s.contact as object) ?? {}) } as ContactCfg;
    setMail({ ...mc, port: Number(mc.port) || 587 });
    setContact(cc);
    setEmailsText((cc.emails?.length ? cc.emails : DEFAULT_CONTACT.emails).join("\n"));
    setRows(m.rows ?? []);
    setLoaded(true);
  }, []);

  useEffect(() => {
    load().catch((e) => notify((e as Error).message, "err"));
  }, [load, notify]);

  if (!loaded) return <div className="animate-pulse rounded-xl border border-line bg-card p-10 text-sm text-ink-400">Loading inbox &amp; mail…</div>;

  const saveMail = async () => {
    setBusy("mail");
    try {
      await api("POST", "settings", { key: "mail", value: { ...mail, port: Number(mail.port) || 587 } });
      notify("Mail server saved — contact forms and quote requests now use it");
    } catch (e) {
      notify((e as Error).message, "err");
    } finally {
      setBusy(null);
    }
  };

  const saveContact = async () => {
    setBusy("contact");
    try {
      const emails = emailsText
        .split(/[,\n;]+/)
        .map((e) => e.trim().toLowerCase())
        .filter(Boolean);
      const next = { ...contact, emails };
      await api("POST", "settings", { key: "contact", value: next });
      setContact(next);
      notify(`Saved — enquiries go to ${emails.join(", ") || "(no address!)"}`);
    } catch (e) {
      notify((e as Error).message, "err");
    } finally {
      setBusy(null);
    }
  };

  const sendTest = async () => {
    setBusy("test");
    try {
      const res = await fetch("/api/admin/mail-test", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ to: testTo }),
      });
      const data = (await res.json()) as { ok: boolean; result?: { status: string; error?: string; to: string[] } };
      if (data.ok) notify(`Test e-mail sent to ${data.result?.to.join(", ")}`);
      else notify(data.result?.error || "Test failed — check the server details", "err");
      await load();
    } catch (e) {
      notify((e as Error).message, "err");
    } finally {
      setBusy(null);
    }
  };

  const setStatus = async (row: MessageRow, status: string) => {
    try {
      await api("PATCH", "messages", { id: row.id, data: { status } });
      setRows((r) => r.map((x) => (x.id === row.id ? { ...x, status } : x)));
      notify(`Marked as ${status}`);
    } catch (e) {
      notify((e as Error).message, "err");
    }
  };

  const visible = rows.filter((r) =>
    filter === "all" ? true : filter === "undelivered" ? !r.delivered : r.kind === filter
  );
  const undelivered = rows.filter((r) => !r.delivered).length;

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl font-black uppercase tracking-tight text-ink-950">Inbox &amp; mail</h1>
          <p className="mt-1 max-w-3xl text-sm text-ink-500">
            Every contact form and quote request is stored here first, then e-mailed to the addresses
            below through your own mailbox (for example <b>no-reply@forward.pk</b>). Nothing needs a
            code change — set the server, press save, send a test.
          </p>
        </div>
        <button onClick={() => load()} className="flex items-center gap-2 rounded-lg border border-line px-3 py-2 text-xs font-bold text-ink-600 hover:bg-paper">
          <RefreshCw className="h-3.5 w-3.5" /> Refresh
        </button>
      </div>

      <Card
        title="Sending mailbox (SMTP)"
        icon={<Mail className="h-4 w-4" />}
        note="The account the catalog sends FROM. Ask your mail administrator for the host, port and password — for a cPanel mailbox this is usually mail.forward.pk, port 465 (SSL) or 587 (STARTTLS)."
      >
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Mail server (host)" hint="e.g. smtp.forward.pk or mail.forward.pk">
            <input className={inputCls} value={mail.host} placeholder="mail.forward.pk" onChange={(e) => setMail({ ...mail, host: e.target.value })} />
          </Field>
          <Field label="Port">
            <input type="number" className={inputCls} value={mail.port} onChange={(e) => setMail({ ...mail, port: Number(e.target.value) })} />
          </Field>
          <Field label="Username" hint="Usually the full e-mail address">
            <input className={inputCls} value={mail.user} placeholder="no-reply@forward.pk" onChange={(e) => setMail({ ...mail, user: e.target.value })} autoComplete="off" />
          </Field>
          <Field label="Password / app password">
            <input type="password" className={inputCls} value={mail.pass} onChange={(e) => setMail({ ...mail, pass: e.target.value })} autoComplete="new-password" />
          </Field>
          <Field label="From address" hint="Must be an address on this server">
            <input className={inputCls} value={mail.from} placeholder="no-reply@forward.pk" onChange={(e) => setMail({ ...mail, from: e.target.value })} />
          </Field>
          <Field label="From name">
            <input className={inputCls} value={mail.fromName} onChange={(e) => setMail({ ...mail, fromName: e.target.value })} />
          </Field>
          <Field label="Reply-to (optional)" hint="Buyers' replies land here instead">
            <input className={inputCls} value={mail.replyTo} placeholder="hassanqulaba@forward.pk" onChange={(e) => setMail({ ...mail, replyTo: e.target.value })} />
          </Field>
          <div className="space-y-3 sm:pt-6">
            <Toggle checked={mail.secure} onChange={(v) => setMail({ ...mail, secure: v })} label="SSL / implicit TLS (port 465)" />
            <Toggle checked={mail.enabled} onChange={(v) => setMail({ ...mail, enabled: v })} label="E-mail delivery enabled" />
          </div>
        </div>

        <div className="mt-4 flex flex-wrap items-center gap-3">
          <SaveBar busy={busy === "mail"} onSave={saveMail} label="Save mail server" />
          <span className="flex items-center gap-2 text-xs font-bold text-ink-500">
            Test to:
            <input
              className={cn(inputCls, "w-64 py-1.5 text-xs")}
              value={testTo}
              placeholder={contact.emails.join(", ")}
              onChange={(e) => setTestTo(e.target.value)}
            />
            <button
              onClick={sendTest}
              disabled={busy === "test"}
              className="flex items-center gap-2 rounded-lg border border-line px-3 py-2 text-xs font-extrabold uppercase tracking-wide text-ink-700 hover:border-brand-400 hover:text-brand-700 disabled:opacity-60"
            >
              {busy === "test" ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Send className="h-3.5 w-3.5" />}
              Send test
            </button>
          </span>
        </div>

        <div className={cn("mt-4 flex items-start gap-2 rounded-xl border p-3 text-xs", mail.lastStatus === "sent" ? "border-ok/40 bg-ok/5 text-ink-700" : "border-warn/40 bg-warn/5 text-ink-700")}>
          {mail.lastStatus === "sent" ? <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-ok" /> : <MailWarning className="mt-0.5 h-4 w-4 shrink-0 text-warn" />}
          <span>
            Last attempt: <b>{mail.lastStatus}</b>
            {mail.lastSentAt ? ` · ${timeAgo(mail.lastSentAt)}` : ""}
            {mail.lastError ? ` — ${mail.lastError}` : ""}
            {!mail.enabled && " Delivery is OFF: messages are still stored in the inbox below."}
          </span>
        </div>
      </Card>

      <Card
        title="Where enquiries are sent + contact details on the site"
        icon={<Inbox className="h-4 w-4" />}
        note="These are the recipients of every contact form and quote request, and the details printed on the contact page and in the footer."
      >
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Recipient e-mails (one per line)" hint="Defaults: hassanqulaba@forward.pk and adeel@forward.pk">
            <textarea rows={4} className={cn(inputCls, "font-mono text-xs")} value={emailsText} onChange={(e) => setEmailsText(e.target.value)} />
          </Field>
          <div className="space-y-4">
            <Field label="Phone number">
              <input className={inputCls} value={contact.phone} onChange={(e) => setContact({ ...contact, phone: e.target.value })} />
            </Field>
            <Field label="WhatsApp (optional)">
              <input className={inputCls} value={contact.whatsapp} onChange={(e) => setContact({ ...contact, whatsapp: e.target.value })} />
            </Field>
          </div>
          <Field label="Address">
            <input className={inputCls} value={contact.address} onChange={(e) => setContact({ ...contact, address: e.target.value })} />
          </Field>
          <Field label="Opening hours">
            <input className={inputCls} value={contact.hours} onChange={(e) => setContact({ ...contact, hours: e.target.value })} />
          </Field>
        </div>
        <Field label="Response note" hint="Shown next to the contact form">
          <input className={inputCls} value={contact.responseNote} onChange={(e) => setContact({ ...contact, responseNote: e.target.value })} />
        </Field>
        <div className="mt-4">
          <SaveBar busy={busy === "contact"} onSave={saveContact} label="Save recipients & contact details" />
        </div>
      </Card>

      <Card
        title={`Messages (${rows.length})${undelivered ? ` · ${undelivered} not e-mailed` : ""}`}
        icon={<Inbox className="h-4 w-4" />}
        note="Stored before sending, so an unconfigured or failing mail server never loses an enquiry."
      >
        <div className="mb-3 flex flex-wrap gap-2">
          {(["all", "undelivered", "contact", "quote"] as const).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={cn(
                "rounded-lg px-3 py-1.5 text-xs font-extrabold uppercase tracking-wide transition",
                filter === f ? "bg-ink-950 text-white" : "border border-line text-ink-600 hover:bg-paper"
              )}
            >
              {f === "undelivered" ? `not e-mailed (${undelivered})` : f}
            </button>
          ))}
        </div>
        {visible.length === 0 ? (
          <p className="rounded-xl border border-dashed border-line p-8 text-center text-sm text-ink-400">
            Nothing here yet — messages from the contact form and quote requests appear instantly.
          </p>
        ) : (
          <ul className="space-y-2">
            {visible.map((m) => (
              <li key={m.id} className="rounded-xl border border-line bg-paper p-4">
                <div className="flex flex-wrap items-center gap-2">
                  <Badge tone={m.kind === "quote" ? "brand" : "neutral"}>{m.kind}</Badge>
                  <span className="text-sm font-extrabold text-ink-950">{m.name}</span>
                  <a href={`mailto:${m.email}`} className="text-xs font-bold text-brand-700 hover:underline">{m.email}</a>
                  {m.phone && <span className="text-xs text-ink-500">{m.phone}</span>}
                  <Badge tone={m.delivered ? "ok" : "warn"}>{m.delivered ? "e-mailed" : "not e-mailed"}</Badge>
                  <Badge tone={m.status === "new" ? "warn" : "neutral"}>{m.status}</Badge>
                  <span className="ml-auto text-[11px] text-ink-400">{timeAgo(m.createdAt)}</span>
                </div>
                {m.subject && <p className="mt-2 text-xs font-extrabold uppercase tracking-wide text-ink-600">{m.subject}</p>}
                {m.articleLabel && <p className="mt-1 text-xs text-ink-500">Article: {m.articleLabel}{m.ref ? ` · ref ${m.ref}` : ""}</p>}
                <p className="mt-2 whitespace-pre-wrap text-sm leading-relaxed text-ink-700">{m.body}</p>
                {!m.delivered && m.deliveryNote && <p className="mt-2 text-xs font-semibold text-warn">{m.deliveryNote}</p>}
                <div className="mt-3 flex flex-wrap gap-2">
                  <a href={`mailto:${m.email}?subject=Re: ${encodeURIComponent(m.subject || "Forward Sports enquiry")}`} className="rounded-lg border border-line px-3 py-1.5 text-xs font-bold text-ink-700 hover:border-brand-400">
                    Reply by e-mail
                  </a>
                  {["read", "replied", "archived"].map((s) => (
                    <button key={s} onClick={() => setStatus(m, s)} disabled={m.status === s} className="rounded-lg border border-line px-3 py-1.5 text-xs font-bold text-ink-500 hover:border-brand-400 disabled:opacity-40">
                      mark {s}
                    </button>
                  ))}
                </div>
              </li>
            ))}
          </ul>
        )}
      </Card>
    </div>
  );
}

/* ------------------------------------------------ Media & files (item 10) -- */

export function MediaFilesTab({ notify }: { notify: Notify }) {
  const [groups, setGroups] = useState<MediaGroup[]>([]);
  const [loaded, setLoaded] = useState(false);
  const [busy, setBusy] = useState(false);
  const [report, setReport] = useState<{ scanned: number; imported: number; local: number; failed: Array<{ where: string; url: string; error: string }> } | null>(null);

  const load = useCallback(async () => {
    const r = await api<{ rows: MediaGroup[] }>("GET", "media");
    setGroups(r.rows ?? []);
    setLoaded(true);
  }, []);

  useEffect(() => {
    load().catch((e) => notify((e as Error).message, "err"));
  }, [load, notify]);

  const localize = async () => {
    setBusy(true);
    setReport(null);
    try {
      const res = await fetch("/api/admin/localize", { method: "POST" });
      const data = (await res.json()) as { ok: boolean; report?: typeof report; error?: string };
      if (!res.ok) throw new Error(data.error || "Import failed");
      setReport(data.report ?? null);
      notify(`Copied ${data.report?.imported ?? 0} external file(s) into the project`);
      await load();
    } catch (e) {
      notify((e as Error).message, "err");
    } finally {
      setBusy(false);
    }
  };

  if (!loaded) return <div className="animate-pulse rounded-xl border border-line bg-card p-10 text-sm text-ink-400">Loading media folders…</div>;

  const totalFiles = groups.reduce((n, g) => n + g.files, 0);
  const totalBytes = groups.reduce((n, g) => n + g.bytes, 0);

  return (
    <div className="space-y-5">
      <div>
        <h1 className="font-display text-2xl font-black uppercase tracking-tight text-ink-950">Media &amp; files</h1>
        <p className="mt-1 max-w-3xl text-sm text-ink-500">
          Every uploaded file is written <b>inside the project</b> at{" "}
          <code className="font-mono text-xs">public/media/&lt;folder&gt;/</code> — {totalFiles} files,
          {" "}{bytes(totalBytes)}. Copy or download the project folder and the rexine photos, 3D
          models and artwork travel with it; nothing is left behind on the old machine.
        </p>
      </div>

      <Card
        title="Pull in files that still live elsewhere"
        icon={<DownloadCloud className="h-4 w-4" />}
        note="If data was imported with links to another server (http/https), this downloads a copy of every file into the project and rewrites the database row to the local copy. Safe to run repeatedly."
      >
        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={localize}
            disabled={busy}
            className="flex items-center gap-2 rounded-xl bg-brand-600 px-5 py-2.5 font-display text-xs font-extrabold uppercase tracking-widest text-white hover:bg-brand-500 disabled:opacity-60"
          >
            {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <DownloadCloud className="h-4 w-4" />}
            {busy ? "Copying files…" : "Copy external files into the project"}
          </button>
          <button onClick={() => load()} className="flex items-center gap-2 rounded-lg border border-line px-3 py-2 text-xs font-bold text-ink-600 hover:bg-paper">
            <RefreshCw className="h-3.5 w-3.5" /> Refresh
          </button>
        </div>
        {report && (
          <div className="mt-4 rounded-xl border border-line bg-paper p-4 text-xs leading-relaxed text-ink-600">
            <p>
              Scanned <b>{report.scanned}</b> asset link(s) · copied <b className="text-ok">{report.imported}</b> into
              the project · already local <b>{report.local}</b>
              {report.failed.length > 0 && <> · failed <b className="text-danger">{report.failed.length}</b></>}
            </p>
            {report.failed.length > 0 && (
              <ul className="mt-2 space-y-1">
                {report.failed.slice(0, 8).map((f) => (
                  <li key={`${f.where}-${f.url}`} className="font-mono text-[11px] text-danger">
                    {f.where}: {f.error}
                  </li>
                ))}
              </ul>
            )}
          </div>
        )}
      </Card>

      <div className="grid gap-4 lg:grid-cols-2">
        {groups.map((g) => (
          <Card key={g.folder} title={g.label} icon={<FolderOpen className="h-4 w-4" />} note={`${g.files} file(s) · ${bytes(g.bytes)} · public/media/${g.folder}/`}>
            {g.items.length === 0 ? (
              <p className="rounded-xl border border-dashed border-line p-6 text-center text-xs text-ink-400">
                Empty — upload from Articles, Rexine materials or the Front page tab and the file lands here.
              </p>
            ) : (
              <ul className="max-h-72 space-y-1.5 overflow-y-auto pr-1">
                {g.items.map((it) => (
                  <li key={it.name} className="flex items-center gap-3 rounded-lg border border-line bg-paper px-3 py-2">
                    {/\.(png|jpe?g|webp|gif|avif|ico|svg)$/i.test(it.name) ? (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img src={it.url} alt="" className="h-9 w-9 shrink-0 rounded border border-line object-cover" />
                    ) : (
                      <span className="grid h-9 w-9 shrink-0 place-items-center rounded border border-line bg-card text-[9px] font-black uppercase text-ink-500">
                        {it.name.split(".").pop()}
                      </span>
                    )}
                    <a href={it.url} target="_blank" rel="noopener noreferrer" className="min-w-0 flex-1 truncate text-xs font-bold text-ink-800 hover:text-brand-700">
                      {it.name}
                    </a>
                    <span className="shrink-0 text-[11px] text-ink-400">{bytes(it.size)}</span>
                  </li>
                ))}
              </ul>
            )}
          </Card>
        ))}
      </div>
    </div>
  );
}

/* ------------------------------------------------------- Security (item 2) -- */

export function SecurityTab({ notify }: { notify: Notify }) {
  const [info, setInfo] = useState<CredInfo | null>(null);
  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [confirm, setConfirm] = useState("");
  const [issues, setIssues] = useState<string[]>([]);
  const [score, setScore] = useState<{ score: number; label: string } | null>(null);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    const res = await fetch("/api/admin/password");
    const data = (await res.json()) as { ok: boolean; info: CredInfo };
    if (data.ok) setInfo(data.info);
  }, []);

  useEffect(() => {
    load().catch(() => undefined);
  }, [load]);

  useEffect(() => {
    if (!next) {
      setIssues([]);
      setScore(null);
      return;
    }
    const t = setTimeout(() => {
      fetch("/api/admin/password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "strength", password: next }),
      })
        .then((r) => r.json())
        .then((d) => {
          setIssues(d.issues ?? []);
          setScore({ score: d.score ?? 0, label: d.label ?? "" });
        })
        .catch(() => undefined);
    }, 250);
    return () => clearTimeout(t);
  }, [next]);

  const change = async () => {
    if (next !== confirm) {
      notify("The two new passwords do not match", "err");
      return;
    }
    setBusy(true);
    try {
      const res = await fetch("/api/admin/password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ current, next }),
      });
      const data = (await res.json()) as { ok?: boolean; error?: string; note?: string };
      if (!res.ok) throw new Error(data.error || "Could not change the password");
      notify(data.note || "Password changed — every device must sign in again");
      setCurrent("");
      setNext("");
      setConfirm("");
      await load();
    } catch (e) {
      notify((e as Error).message, "err");
    } finally {
      setBusy(false);
    }
  };

  const revoke = async () => {
    setBusy(true);
    try {
      const res = await fetch("/api/admin/password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "revoke" }),
      });
      const data = (await res.json()) as { ok?: boolean; error?: string };
      if (!res.ok || !data.ok) throw new Error(data.error || "Could not sign out other devices");
      notify("Every device signed out — you will need to sign in again");
      await load();
    } catch (e) {
      notify((e as Error).message, "err");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="max-w-2xl space-y-5">
      <div>
        <h1 className="font-display text-2xl font-black uppercase tracking-tight text-ink-950">Security</h1>
        <p className="mt-1 text-sm text-ink-500">
          The dashboard is reachable only with a strong password. It is stored as a scrypt hash in the
          database — never as plain text — and changing it here signs out every device.
        </p>
      </div>

      <Card title="Current status" icon={<ShieldCheck className="h-4 w-4" />}>
        {info ? (
          <dl className="grid gap-3 text-sm sm:grid-cols-2">
            <div className="rounded-xl border border-line bg-paper p-3">
              <dt className="text-[11px] font-extrabold uppercase tracking-wider text-ink-500">Password source</dt>
              <dd className="mt-1 font-bold text-ink-900">
                {info.source === "dashboard" ? "set in this dashboard" : info.source === "env" ? "ADMIN_PASSWORD in .env" : "auto-generated on first boot"}
              </dd>
            </div>
            <div className="rounded-xl border border-line bg-paper p-3">
              <dt className="text-[11px] font-extrabold uppercase tracking-wider text-ink-500">Last changed</dt>
              <dd className="mt-1 font-bold text-ink-900">{info.updatedAt ? timeAgo(info.updatedAt) : "—"}</dd>
            </div>
            <div className="rounded-xl border border-line bg-paper p-3">
              <dt className="text-[11px] font-extrabold uppercase tracking-wider text-ink-500">Failed attempts</dt>
              <dd className="mt-1 font-bold text-ink-900">
                {info.lockedUntil ? `locked until ${new Date(info.lockedUntil).toLocaleString()}` : `${info.fails} of ${info.maxFails} (then ${info.lockMinutes} min lock)`}
              </dd>
            </div>
            <div className="rounded-xl border border-line bg-paper p-3">
              <dt className="text-[11px] font-extrabold uppercase tracking-wider text-ink-500">Last successful sign-in</dt>
              <dd className="mt-1 font-bold text-ink-900">{info.lastOkAt ? timeAgo(info.lastOkAt) : "never"}</dd>
            </div>
          </dl>
        ) : (
          <p className="text-sm text-ink-400">Loading…</p>
        )}
        {info && info.source !== "dashboard" && (
          <p className="mt-4 flex items-start gap-2 rounded-xl border border-warn/40 bg-warn/5 p-3 text-xs leading-relaxed text-ink-700">
            <ShieldAlert className="mt-0.5 h-4 w-4 shrink-0 text-warn" />
            <span>
              The password currently comes from <code className="font-mono">ADMIN_PASSWORD</code> in the
              environment file{info.envUsable ? "" : " — and that value is too weak, so a random one was generated"}.
              Set your own below: it is stored hashed in the database, survives restarts and redeploys,
              and takes priority over the file.
              {!info.envUsable && info.envIssues.length > 0 && (
                <span className="mt-1 block font-semibold text-danger">Weak because it needs {info.envIssues.join(", ")}.</span>
              )}
            </span>
          </p>
        )}
      </Card>

      <Card title="Dashboard password" icon={<KeyRound className="h-4 w-4" />} note={`At least ${info?.minLength ?? 12} characters with an uppercase letter, a lowercase letter, a number and a symbol. It must not start with forward / catalog / admin / password.`}>
        <div className="space-y-4">
          <Field label="Current password">
            <input type="password" className={inputCls} value={current} onChange={(e) => setCurrent(e.target.value)} autoComplete="current-password" />
          </Field>
          <Field label="New password">
            <input type="password" className={inputCls} value={next} onChange={(e) => setNext(e.target.value)} autoComplete="new-password" />
          </Field>
          {next && (
            <div className="flex items-center gap-2">
              <div className="flex h-1.5 flex-1 gap-1">
                {[0, 1, 2, 3, 4].map((i) => (
                  <span key={i} className={cn("h-full flex-1 rounded-full", (score?.score ?? 0) > i ? ((score?.score ?? 0) >= 4 ? "bg-ok" : "bg-warn") : "bg-ink-200")} />
                ))}
              </div>
              <span className={cn("text-[11px] font-extrabold uppercase tracking-wider", issues.length ? "text-danger" : "text-ok")}>{score?.label || "…"}</span>
            </div>
          )}
          {issues.length > 0 && (
            <ul className="space-y-1 text-xs font-semibold text-danger">
              {issues.map((i) => (
                <li key={i}>• needs {i}</li>
              ))}
            </ul>
          )}
          <Field label="Repeat new password">
            <input type="password" className={inputCls} value={confirm} onChange={(e) => setConfirm(e.target.value)} autoComplete="new-password" />
          </Field>
          <div className="flex flex-wrap gap-3">
            <button
              onClick={change}
              disabled={busy || issues.length > 0 || !current || !next}
              className="flex items-center gap-2 rounded-xl bg-brand-600 px-5 py-2.5 font-display text-xs font-extrabold uppercase tracking-widest text-white hover:bg-brand-500 disabled:opacity-50"
            >
              {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <KeyRound className="h-4 w-4" />}
              Change password
            </button>
            <button
              onClick={revoke}
              disabled={busy}
              className="flex items-center gap-2 rounded-xl border border-line px-5 py-2.5 font-display text-xs font-extrabold uppercase tracking-widest text-ink-700 hover:border-danger hover:text-danger disabled:opacity-50"
            >
              <Trash2 className="h-4 w-4" />
              Sign out every device
            </button>
          </div>
        </div>
      </Card>

      <Card title="Locked out?" icon={<ShieldAlert className="h-4 w-4" />} note="If you cannot sign in at all, reset the password from the project folder — no database access needed.">
        <pre className="overflow-x-auto rounded-xl border border-line bg-ink-950 p-4 font-mono text-[11px] leading-relaxed text-white">
{`# uses ADMIN_PASSWORD from .env
node scripts/reset-admin-password.mjs

# or set an explicit new one
node scripts/reset-admin-password.mjs "My@NewPassword123"`}
        </pre>
      </Card>
    </div>
  );
}
