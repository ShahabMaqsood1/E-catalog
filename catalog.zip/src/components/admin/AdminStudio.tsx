"use client";

import { useRouter } from "next/navigation";
import { useCallback, useEffect, useState } from "react";
import {
  Activity,
  BrainCircuit,
  FileImage,
  FolderOpen,
  Inbox,
  KeyRound,
  LayoutGrid,
  Layers,
  LogOut,
  MessageSquareQuote,
  MonitorSmartphone,
  Settings2,
  ShieldCheck,
  Sparkles,
  Type,
  type LucideIcon,
} from "lucide-react";
import { InboxMailTab, MediaFilesTab, SecurityTab } from "@/components/admin/OperationsTabs";
import type { InsightsPayload } from "@/lib/insights";
import { cn, formatMoney, timeAgo } from "@/lib/utils";
import { api, Badge, Field, inputCls, StatCard } from "@/components/admin/ui";
import { ArticlesTab, ComplianceTab, DesignFilesTab, MaterialsTab } from "@/components/admin/AdminEditors";
import FrontPageTab from "@/components/admin/FrontPageTab";
import ContentTab from "@/components/admin/ContentTab";
import type { ArticleRow, CategoryRow, MaterialRow, UploadRow } from "@/components/admin/AdminEditors";

export type QuoteRow = {
  id: number;
  ref: string;
  articleId: number | null;
  materialId: number | null;
  customerName: string;
  company: string;
  email: string;
  quantity: number;
  unitPrice: string;
  total: string;
  logoName: string | null;
  message: string;
  status: string;
  createdAt: string;
};

type ActivityRow = { id: number; event: string; refId: string | null; payload: Record<string, unknown>; createdAt: string };

type TabId =
  | "overview"
  | "articles"
  | "materials"
  | "design-files"
  | "front-page"
  | "content"
  | "quotes"
  | "inbox"
  | "media"
  | "compliance"
  | "settings"
  | "security";

const TABS: Array<{ id: TabId; label: string; icon: LucideIcon; tour?: string }> = [
  { id: "overview", label: "Overview", icon: LayoutGrid, tour: "tab-overview" },
  { id: "articles", label: "Articles", icon: Layers, tour: "tab-articles" },
  { id: "materials", label: "Rexine materials", icon: Sparkles, tour: "tab-materials" },
  { id: "design-files", label: "CorelDRAW files", icon: FileImage, tour: "tab-design-files" },
  { id: "front-page", label: "Front page", icon: MonitorSmartphone, tour: "tab-front-page" },
  { id: "content", label: "Site content", icon: Type, tour: "tab-content" },
  { id: "quotes", label: "Quote requests", icon: MessageSquareQuote },
  { id: "inbox", label: "Inbox & mail", icon: Inbox, tour: "tab-inbox" },
  { id: "media", label: "Media & files", icon: FolderOpen, tour: "tab-media" },
  { id: "compliance", label: "Compliance", icon: ShieldCheck, tour: "tab-compliance" },
  { id: "settings", label: "Settings", icon: Settings2, tour: "tab-settings" },
  { id: "security", label: "Security", icon: KeyRound, tour: "tab-security" },
];

export default function AdminStudio() {
  const router = useRouter();
  const [tab, setTab] = useState<TabId>("overview");
  const [toast, setToast] = useState<{ msg: string; kind: "ok" | "err" } | null>(null);

  const notify = useCallback((msg: string, kind: "ok" | "err" = "ok") => {
    setToast({ msg, kind });
    setTimeout(() => setToast(null), 3200);
  }, []);

  const logout = async () => {
    await fetch("/api/admin/logout", { method: "POST" });
    router.refresh();
  };

  return (
    <div className="mx-auto flex max-w-[1400px] gap-6 px-4 py-8 sm:px-6">
      {/* Sidebar */}
      <aside className="hidden w-60 shrink-0 lg:block">
        <div className="sticky top-20 space-y-1">
          {TABS.map((t) => (
            <button
              key={t.id}
              data-tour={t.tour}
              onClick={() => setTab(t.id)}
              className={cn(
                "flex w-full items-center gap-2.5 rounded-xl px-3.5 py-2.5 text-left text-sm font-bold transition",
                tab === t.id ? "bg-ink-950 text-white" : "text-ink-600 hover:bg-card"
              )}
            >
              <t.icon className="h-4 w-4" />
              {t.label}
            </button>
          ))}
          <div className="pt-3">
            <button
              onClick={logout}
              className="flex w-full items-center gap-2.5 rounded-xl px-3.5 py-2.5 text-left text-sm font-bold text-danger hover:bg-danger-soft"
            >
              <LogOut className="h-4 w-4" /> Sign out
            </button>
          </div>
        </div>
      </aside>

      {/* Mobile tabs */}
      <div className="fixed inset-x-0 top-16 z-30 flex gap-1 overflow-x-auto border-b border-line bg-paper px-3 py-2 no-scrollbar lg:hidden">
        {TABS.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={cn(
              "shrink-0 rounded-lg px-3 py-1.5 text-xs font-bold",
              tab === t.id ? "bg-ink-950 text-white" : "bg-card text-ink-600"
            )}
          >
            {t.label}
          </button>
        ))}
        <button onClick={logout} className="shrink-0 rounded-lg px-3 py-1.5 text-xs font-bold text-danger">
          Sign out
        </button>
      </div>

      {/* Content */}
      <main className="min-w-0 flex-1 pt-12 lg:pt-0">
        {tab === "overview" && <OverviewTab />}
        {tab === "articles" && <ArticlesTab notify={notify} />}
        {tab === "materials" && <MaterialsTab notify={notify} />}
        {tab === "design-files" && <DesignFilesTab notify={notify} />}
        {tab === "front-page" && <FrontPageTab notify={notify} />}
        {tab === "content" && <ContentTab notify={notify} />}
        {tab === "quotes" && <QuotesTab notify={notify} />}
        {tab === "inbox" && <InboxMailTab notify={notify} />}
        {tab === "media" && <MediaFilesTab notify={notify} />}
        {tab === "compliance" && <ComplianceTab notify={notify} />}
        {tab === "settings" && <SettingsTab notify={notify} />}
        {tab === "security" && <SecurityTab notify={notify} />}
      </main>

      {toast && (
        <div
          className={cn(
            "fixed bottom-6 right-6 z-[85] rounded-xl px-4 py-3 text-sm font-bold text-white shadow-2xl anim-fade-up",
            toast.kind === "ok" ? "bg-ok" : "bg-danger"
          )}
        >
          {toast.msg}
        </div>
      )}
    </div>
  );
}

/* ---------------- Overview ---------------- */

function OverviewTab() {
  const [data, setData] = useState<InsightsPayload | null>(null);
  const [feed, setFeed] = useState<ActivityRow[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api<InsightsPayload>("GET", "insights")
      .then(setData)
      .catch((e) => setError((e as Error).message));
    api<{ rows: ActivityRow[] }>("GET", "activity")
      .then((d) => setFeed(d.rows))
      .catch(() => {});
  }, []);

  if (error)
    return (
      <div className="rounded-xl border border-danger/30 bg-danger-soft p-6 text-sm font-bold text-danger">
        Could not load insights: {error}
      </div>
    );
  if (!data)
    return <div className="animate-pulse rounded-xl border border-line bg-card p-10 text-sm text-ink-400">Crunching catalog signals…</div>;

  const maxSel = Math.max(1, ...data.topMaterials.map((m) => m.selections));

  return (
    <div className="space-y-6">
      <header className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl font-black uppercase tracking-tight text-ink-950">Overview</h1>
          <p className="text-sm text-ink-500">
            Live picture of the catalog — generated {new Date(data.generatedAt).toLocaleTimeString()}
          </p>
        </div>
        <span className="inline-flex items-center gap-2 rounded-lg bg-brand-600/10 px-3 py-2 text-xs font-extrabold text-brand-700">
          <BrainCircuit className="h-4 w-4" /> Self-tuning engine active
        </span>
      </header>

      <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
        <StatCard label="Live articles" value={String(data.stats.liveArticles)} sub={`${data.stats.draftArticles} drafts`} />
        <StatCard label="Rexine materials" value={String(data.stats.activeMaterials)} sub="active in picker" />
        <StatCard label="New quote requests" value={String(data.stats.newQuotes)} sub={`${formatMoney(data.stats.quotePipelineValue)} pipeline`} accent />
        <StatCard
          label="Buyer interactions · 7d"
          value={String(data.stats.selections7d + data.stats.views7d)}
          sub={`${data.stats.views7d} views · ${data.stats.selections7d} material picks`}
        />
      </div>

      <div className="grid gap-6 xl:grid-cols-[1.5fr_1fr]">
        {/* Insights */}
        <section className="rounded-2xl border border-line bg-card">
          <div className="flex items-center gap-2 border-b border-line px-5 py-4">
            <BrainCircuit className="h-4 w-4 text-brand-600" />
            <h2 className="font-display text-sm font-extrabold uppercase tracking-[0.18em] text-ink-950">
              Smart insights & self-improvements
            </h2>
          </div>
          <ul className="divide-y divide-line">
            {data.insights.map((ins, i) => (
              <li key={i} className="flex gap-3.5 px-5 py-4">
                <span
                  className={cn(
                    "mt-1.5 h-2 w-2 shrink-0 rounded-full",
                    ins.level === "good" ? "bg-ok" : ins.level === "warn" ? "bg-warn" : "bg-ink-300"
                  )}
                />
                <div>
                  <p className="text-sm font-extrabold text-ink-900">{ins.title}</p>
                  <p className="mt-1 text-[13px] leading-relaxed text-ink-500">{ins.detail}</p>
                </div>
              </li>
            ))}
          </ul>
        </section>

        <div className="space-y-6">
          {/* Top materials */}
          <section className="rounded-2xl border border-line bg-card p-5">
            <h2 className="font-display text-sm font-extrabold uppercase tracking-[0.18em] text-ink-950">
              Most selected rexines · 7d
            </h2>
            {data.topMaterials.length === 0 ? (
              <p className="mt-3 text-xs text-ink-400">No selections yet — share the catalog link with buyers.</p>
            ) : (
              <div className="mt-4 space-y-3">
                {data.topMaterials.map((m) => (
                  <div key={m.id}>
                    <div className="flex justify-between text-xs font-bold text-ink-700">
                      <span>{m.name}</span>
                      <span className="text-ink-400">{m.selections}</span>
                    </div>
                    <div className="mt-1 h-2 overflow-hidden rounded-full bg-paper-deep">
                      <div
                        className="h-full rounded-full bg-brand-600"
                        style={{ width: `${(m.selections / maxSel) * 100}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </section>

          {/* Compliance mini */}
          <section className="rounded-2xl border border-line bg-card p-5">
            <h2 className="font-display text-sm font-extrabold uppercase tracking-[0.18em] text-ink-950">
              Compliance radar
            </h2>
            <ul className="mt-3 space-y-2">
              {data.compliance.map((c) => (
                <li key={c.id} className="flex items-center justify-between gap-2 text-[13px]">
                  <span className="truncate font-semibold text-ink-700">{c.title.split("—")[0]}</span>
                  <Badge tone={c.status === "compliant" ? "ok" : c.status === "attention" ? "danger" : "warn"}>
                    {c.status}
                  </Badge>
                </li>
              ))}
            </ul>
          </section>
        </div>
      </div>

      {/* Activity feed */}
      <section className="rounded-2xl border border-line bg-card">
        <div className="flex items-center gap-2 border-b border-line px-5 py-4">
          <Activity className="h-4 w-4 text-brand-600" />
          <h2 className="font-display text-sm font-extrabold uppercase tracking-[0.18em] text-ink-950">
            Buyer activity feed
          </h2>
        </div>
        {feed.length === 0 ? (
          <p className="px-5 py-6 text-xs text-ink-400">No events recorded yet.</p>
        ) : (
          <ul className="grid gap-x-8 divide-y divide-line px-5 sm:grid-cols-2 sm:divide-y-0">
            {feed.map((f) => (
              <li key={f.id} className="flex items-center justify-between gap-3 border-b border-line py-2.5 text-xs last:border-0">
                <span className="truncate font-semibold text-ink-700">
                  <span className="mr-2 rounded bg-paper-deep px-1.5 py-0.5 font-mono text-[10px] text-ink-500">
                    {f.event}
                  </span>
                  {String(f.payload?.articleNo ?? f.payload?.ref ?? f.refId ?? "")}
                </span>
                <span className="shrink-0 text-ink-400">{timeAgo(f.createdAt)}</span>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}

/* ---------------- Quotes ---------------- */

function QuotesTab({ notify }: { notify: (m: string, k?: "ok" | "err") => void }) {
  const [rows, setRows] = useState<QuoteRow[]>([]);
  const [articlesRows, setArticlesRows] = useState<ArticleRow[]>([]);
  const [materialsRows, setMaterialsRows] = useState<MaterialRow[]>([]);

  const load = useCallback(() => {
    api<{ rows: QuoteRow[] }>("GET", "quotes").then((d) => setRows(d.rows)).catch(() => {});
    api<{ rows: ArticleRow[] }>("GET", "articles").then((d) => setArticlesRows(d.rows)).catch(() => {});
    api<{ rows: MaterialRow[] }>("GET", "materials").then((d) => setMaterialsRows(d.rows)).catch(() => {});
  }, []);
  useEffect(load, [load]);

  const setStatus = async (id: number, status: string) => {
    try {
      await api("PATCH", "quotes", { id, data: { status } });
      notify("Quote status updated");
      load();
    } catch (e) {
      notify((e as Error).message, "err");
    }
  };

  const articleNo = (id: number | null) => articlesRows.find((a) => a.id === id)?.articleNo ?? "—";
  const materialName = (id: number | null) => materialsRows.find((m) => m.id === id)?.name ?? "—";

  return (
    <div className="space-y-4">
      <h1 className="font-display text-2xl font-black uppercase tracking-tight text-ink-950">Quote requests</h1>
      {rows.length === 0 ? (
        <div className="rounded-xl border border-line bg-card p-10 text-center text-sm text-ink-400">
          No quote requests yet. They appear here the moment a buyer submits a configuration.
        </div>
      ) : (
        <div className="overflow-x-auto rounded-2xl border border-line bg-card">
          <table className="w-full min-w-[900px] text-left text-sm">
            <thead>
              <tr className="border-b border-line bg-paper text-[10px] uppercase tracking-wider text-ink-400">
                {["Ref", "Received", "Customer", "Article", "Rexine", "Qty", "Total", "Logo", "Status"].map((h) => (
                  <th key={h} className="px-4 py-3 font-extrabold">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-line">
              {rows.map((q) => (
                <tr key={q.id} className="align-top hover:bg-paper/60">
                  <td className="px-4 py-3 font-mono text-xs font-bold text-brand-700">{q.ref}</td>
                  <td className="px-4 py-3 text-xs text-ink-500">{timeAgo(q.createdAt)}</td>
                  <td className="px-4 py-3">
                    <p className="font-bold text-ink-900">{q.customerName}</p>
                    <p className="text-xs text-ink-400">{q.company || q.email}</p>
                  </td>
                  <td className="px-4 py-3 font-semibold">{articleNo(q.articleId)}</td>
                  <td className="px-4 py-3 text-xs text-ink-600">{materialName(q.materialId)}</td>
                  <td className="px-4 py-3">{q.quantity}</td>
                  <td className="px-4 py-3 font-display font-black">{formatMoney(q.total)}</td>
                  <td className="px-4 py-3 text-xs text-ink-500">{q.logoName ? "Yes" : "—"}</td>
                  <td className="px-4 py-3">
                    <select
                      value={q.status}
                      onChange={(e) => setStatus(q.id, e.target.value)}
                      className={cn(
                        "rounded-lg border px-2 py-1.5 text-xs font-bold outline-none",
                        q.status === "new"
                          ? "border-brand-300 bg-brand-50 text-brand-700"
                          : "border-line bg-paper text-ink-700"
                      )}
                    >
                      {["new", "contacted", "sampling", "closed"].map((s) => (
                        <option key={s} value={s}>{s}</option>
                      ))}
                    </select>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

/* ---------------- Settings ---------------- */

function SettingsTab({ notify }: { notify: (m: string, k?: "ok" | "err") => void }) {
  const [values, setValues] = useState<Record<string, unknown>>({});
  const [loaded, setLoaded] = useState(false);
  const [saving, setSaving] = useState(false);
  const [tiersText, setTiersText] = useState("");

  useEffect(() => {
    api<Record<string, unknown>>("GET", "settings").then((rows) => {
      setValues(rows);
      setTiersText(JSON.stringify(rows.quoteTiers ?? [], null, 2));
      setLoaded(true);
    });
  }, []);

  if (!loaded) return <div className="animate-pulse rounded-xl border border-line bg-card p-10 text-sm text-ink-400">Loading settings…</div>;

  const company = (values.company ?? {}) as Record<string, string>;
  const currency = (values.currency ?? {}) as Record<string, string>;

  const save = async () => {
    setSaving(true);
    try {
      let tiers: unknown;
      try {
        tiers = JSON.parse(tiersText);
        if (!Array.isArray(tiers)) throw new Error("Tiers must be an array");
      } catch (e) {
        throw new Error(`Volume tiers JSON invalid: ${(e as Error).message}`);
      }
      const updates: Array<[string, unknown]> = [
        ["company", company],
        ["currency", currency],
        ["salesEmail", values.salesEmail ?? ""],
        ["leadTime", values.leadTime ?? ""],
        ["defaultMoq", Number(values.defaultMoq) || 300],
        ["quoteTiers", tiers],
      ];
      for (const [key, value] of updates) {
        await api("POST", "settings", { key, value });
      }
      notify("Settings saved — live across the catalog");
    } catch (e) {
      notify((e as Error).message, "err");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="max-w-2xl space-y-5">
      <h1 className="font-display text-2xl font-black uppercase tracking-tight text-ink-950">Catalog settings</h1>
      <div className="space-y-4 rounded-2xl border border-line bg-card p-6">
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Company name">
            <input className={inputCls} value={company.name ?? ""} onChange={(e) => setValues({ ...values, company: { ...company, name: e.target.value } })} />
          </Field>
          <Field label="City">
            <input className={inputCls} value={company.city ?? ""} onChange={(e) => setValues({ ...values, company: { ...company, city: e.target.value } })} />
          </Field>
          <Field label="Sales email (shown to buyers)">
            <input className={inputCls} value={String(values.salesEmail ?? "")} onChange={(e) => setValues({ ...values, salesEmail: e.target.value })} />
          </Field>
          <Field label="Lead time text">
            <input className={inputCls} value={String(values.leadTime ?? "")} onChange={(e) => setValues({ ...values, leadTime: e.target.value })} />
          </Field>
          <Field label="Currency code">
            <input className={inputCls} value={currency.code ?? ""} onChange={(e) => setValues({ ...values, currency: { ...currency, code: e.target.value } })} />
          </Field>
          <Field label="Default MOQ">
            <input type="number" className={inputCls} value={Number(values.defaultMoq ?? 300)} onChange={(e) => setValues({ ...values, defaultMoq: e.target.value })} />
          </Field>
        </div>
        <Field label="Volume discount tiers (JSON)" hint="Array of { minQty, discountPct } — applied automatically in the configurator.">
          <textarea rows={6} className={cn(inputCls, "font-mono text-xs")} value={tiersText} onChange={(e) => setTiersText(e.target.value)} />
        </Field>
        <button
          onClick={save}
          disabled={saving}
          className="rounded-xl bg-brand-600 px-6 py-3 font-display text-sm font-extrabold uppercase tracking-widest text-white hover:bg-brand-500 disabled:opacity-60"
        >
          {saving ? "Saving…" : "Save settings"}
        </button>
      </div>
    </div>
  );
}
