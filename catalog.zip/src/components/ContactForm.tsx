"use client";

import { useState } from "react";
import { CheckCircle2, Loader2, Mail, Send } from "lucide-react";
import { inputCls } from "@/components/admin/ui";
import { cn } from "@/lib/utils";

type Props = {
  sentTo: string[];
  articles: Array<{ id: number; name: string; articleNo: string }>;
  prefillArticleId?: number | null;
};

/** Public contact / enquiry form — posts to /api/contact, which stores the
 *  message in the dashboard inbox and e-mails both sales addresses. */
export default function ContactForm({ sentTo, articles, prefillArticleId }: Props) {
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    company: "",
    subject: "Product enquiry",
    articleId: prefillArticleId ? String(prefillArticleId) : "",
    message: "",
    website: "", // honeypot — hidden from humans
  });
  const [state, setState] = useState<"idle" | "sending" | "sent" | "error">("idle");
  const [info, setInfo] = useState<{ ref?: string; note?: string; error?: string }>({});

  const set = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) =>
    setForm((f) => ({ ...f, [k]: e.target.value }));

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const fail = (error: string) => {
      setInfo({ error });
      setState("error");
    };
    if (form.name.trim().length < 2) return fail("Please tell us your name.");
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) return fail("Please provide a valid email address.");
    if (form.message.trim().length < 10) return fail("Please write a short message (10 characters or more).");
    setState("sending");
    setInfo({});
    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        cache: "no-store",
        body: JSON.stringify({ ...form, articleId: form.articleId ? Number(form.articleId) : null }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error((data as { error?: string }).error || "Could not send the message.");
      const d = data as { ref?: string; note?: string; delivered?: boolean };
      setState("sent");
      setInfo({ ref: d.ref, note: d.note });
    } catch (err) {
      setState("error");
      setInfo({ error: (err as Error).message });
    }
  };

  if (state === "sent") {
    return (
      <div data-tour="contact-form" className="rounded-2xl border border-ok/30 bg-ok-soft p-8 text-center">
        <CheckCircle2 className="mx-auto h-10 w-10 text-ok" />
        <h2 className="mt-4 font-display text-xl font-black uppercase tracking-tight text-ink-950">
          Message received
        </h2>
        <p className="mx-auto mt-2 max-w-md text-sm leading-relaxed text-ink-600">
          {info.note || "Thank you — our sales team has your enquiry."}
        </p>
        {info.ref && (
          <p className="mt-3 inline-block rounded-lg bg-card px-3 py-1.5 font-mono text-xs font-bold text-ink-700">
            Reference {info.ref}
          </p>
        )}
        <p className="mt-4 text-xs text-ink-500">
          Sent to {sentTo.join(" and ")} — quote this reference when we reply.
        </p>
        <button
          onClick={() => {
            setState("idle");
            setForm({ ...form, message: "", subject: "Product enquiry" });
          }}
          className="mt-6 rounded-xl border border-line bg-card px-5 py-2.5 text-sm font-bold text-ink-700 hover:bg-paper"
        >
          Send another message
        </button>
      </div>
    );
  }

  return (
    <form
      data-tour="contact-form"
      onSubmit={submit}
      className="rounded-2xl border border-line bg-card p-6 sm:p-8"
      noValidate
    >
      <h2 className="font-display text-xl font-black uppercase tracking-tight text-ink-950">Send an enquiry</h2>
      <p className="mt-1.5 text-sm text-ink-500">
        Tell us what you need — article, quantity, printing or sampling. We answer within one working day.
      </p>

      <div className="mt-6 grid gap-4 sm:grid-cols-2">
        <label className="block">
          <span className="mb-1 block text-[11px] font-extrabold uppercase tracking-wider text-ink-500">
            Your name *
          </span>
          <input className={inputCls} value={form.name} onChange={set("name")} placeholder="Ahmed Khan" required />
        </label>
        <label className="block">
          <span className="mb-1 block text-[11px] font-extrabold uppercase tracking-wider text-ink-500">
            Business email *
          </span>
          <input className={inputCls} value={form.email} onChange={set("email")} placeholder="you@company.com" required />
        </label>
        <label className="block">
          <span className="mb-1 block text-[11px] font-extrabold uppercase tracking-wider text-ink-500">Company</span>
          <input className={inputCls} value={form.company} onChange={set("company")} placeholder="Club, brand or importer" />
        </label>
        <label className="block">
          <span className="mb-1 block text-[11px] font-extrabold uppercase tracking-wider text-ink-500">
            Phone / WhatsApp
          </span>
          <input className={inputCls} value={form.phone} onChange={set("phone")} placeholder="+92 300 0000000" />
        </label>
        <label className="block">
          <span className="mb-1 block text-[11px] font-extrabold uppercase tracking-wider text-ink-500">Subject</span>
          <select className={inputCls} value={form.subject} onChange={set("subject")}>
            {["Product enquiry", "Quote request", "Sampling", "Private label / OEM", "Existing order", "Other"].map((s) => (
              <option key={s}>{s}</option>
            ))}
          </select>
        </label>
        <label className="block">
          <span className="mb-1 block text-[11px] font-extrabold uppercase tracking-wider text-ink-500">
            Article (optional)
          </span>
          <select className={inputCls} value={form.articleId} onChange={set("articleId")}>
            <option value="">Not sure yet</option>
            {articles.map((a) => (
              <option key={a.id} value={a.id}>
                {a.articleNo} — {a.name}
              </option>
            ))}
          </select>
        </label>
      </div>

      <label className="mt-4 block">
        <span className="mb-1 block text-[11px] font-extrabold uppercase tracking-wider text-ink-500">Message *</span>
        <textarea
          rows={6}
          className={cn(inputCls, "leading-relaxed")}
          value={form.message}
          onChange={set("message")}
          placeholder="Quantity, target price, printing/logo requirements, delivery country…"
          required
        />
      </label>

      {/* honeypot — real visitors never see or fill this */}
      <input
        type="text"
        tabIndex={-1}
        autoComplete="off"
        value={form.website}
        onChange={set("website")}
        className="hidden"
        aria-hidden="true"
      />

      {state === "error" && info.error && (
        <p className="mt-4 rounded-lg bg-danger-soft px-3 py-2 text-xs font-bold text-danger">{info.error}</p>
      )}

      <div className="mt-6 flex flex-wrap items-center gap-4">
        <button
          type="submit"
          disabled={state === "sending"}
          className="flex items-center gap-2 rounded-xl bg-brand-600 px-6 py-3 font-display text-sm font-extrabold uppercase tracking-widest text-white transition hover:bg-brand-500 disabled:opacity-60"
        >
          {state === "sending" ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
          {state === "sending" ? "Sending…" : "Send message"}
        </button>
        <p className="flex items-center gap-2 text-xs text-ink-500">
          <Mail className="h-3.5 w-3.5 text-brand-600" />
          Delivered to {sentTo.join(" and ")}
        </p>
      </div>
    </form>
  );
}
