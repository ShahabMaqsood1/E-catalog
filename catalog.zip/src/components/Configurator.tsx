"use client";

import dynamic from "next/dynamic";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  Check,
  ImageIcon,
  Layers,
  Minimize2,
  Pause,
  Play,
  RotateCcw,
  Send,
  Upload,
  X,
  ZoomIn,
} from "lucide-react";
import BallThumb from "@/components/BallThumb";
import { CategoryIcon } from "@/components/CategoryIcon";
import SafeBoundary from "@/components/SafeBoundary";
import SoftBall from "@/components/SoftBall";
import {
  DEFAULT_LOGO_TRANSFORM,
  type BallColors,
  type BallSpecs,
  type LayerImages,
  type LogoTransform,
  type ModelAdjust,
} from "@/db/schema";
import type { BallTextureMeta } from "@/lib/ballTexture";
import type { LayerKey } from "@/components/BallViewer";
import { useTour } from "@/components/Tour";
import { cn, formatMoney, logActivity } from "@/lib/utils";

const BallViewer = dynamic(() => import("@/components/BallViewer"), { ssr: false });

export type CatInfo = {
  id: number;
  slug: string;
  name: string;
  shortName: string;
  tagline: string;
  description: string;
  iconKey: string;
};

export type CatalogArticle = {
  id: number;
  categoryId: number;
  articleNo: string;
  name: string;
  description: string;
  panelStyle: string;
  panelCount: number;
  basePrice: number;
  moq: number;
  colors: BallColors;
  featured: boolean;
  artworkUrl: string | null;
  designSvgUrl: string | null;
  modelUrl: string | null;
  modelAdjust: ModelAdjust | null;
  renderUrl: string | null;
  seamStyle: string;
  layerImages: LayerImages | null;
  specs: BallSpecs | null;
  defaultMaterialCode: string | null;
  categorySlug: string;
};

export type CatalogMaterial = {
  id: number;
  code: string;
  name: string;
  finish: string;
  description: string;
  textureUrl: string;
  priceDelta: number;
  thickness: string;
  weightGsm: number | null;
};

export type QuoteTier = { minQty: number; discountPct: number };

const DEFAULT_SPECS: BallSpecs = {
  bladder: "Butyl valve bladder",
  lining: "Cotton-poly winding",
  foamMm: 2,
};

export default function CatalogOnePage({
  categories,
  articles,
  materials,
  tiers,
  content,
}: {
  categories: CatInfo[];
  articles: CatalogArticle[];
  materials: CatalogMaterial[];
  tiers: QuoteTier[];
  content?: Record<string, string>;
}) {
  const t = (key: string, fallback: string) => content?.[key] || fallback;
  const [articleId, setArticleId] = useState<number>(articles[0]?.id ?? -1);
  const [materialId, setMaterialId] = useState<number>(materials[0]?.id ?? -1);
  const [logoUrl, setLogoUrl] = useState<string | null>(null);
  const [logoName, setLogoName] = useState<string | null>(null);
  const [logoT, setLogoT] = useState<LogoTransform>(DEFAULT_LOGO_TRANSFORM);

  /* Item 4 — two independent panes. The studio rail on the right owns the mouse
     wheel while the cursor is inside it: it scrolls its own content and stops at
     its ends instead of dragging the whole page (and therefore the 3D view)
     along. Scrolling anywhere over the article list moves only the page. A
     native non-passive listener is required because React registers `wheel`
     passively, where preventDefault() is ignored. */
  const railRef = useRef<HTMLDivElement | null>(null);
  useEffect(() => {
    const el = railRef.current;
    if (!el) return;
    const onWheel = (e: WheelEvent) => {
      const scrollable = el.scrollHeight - el.clientHeight;
      if (scrollable <= 1) return; // nothing of its own to scroll → let the page move
      const atTop = el.scrollTop <= 0 && e.deltaY < 0;
      const atBottom = el.scrollTop >= scrollable - 1 && e.deltaY > 0;
      if (atTop || atBottom) e.preventDefault(); // no chaining into the page
    };
    el.addEventListener("wheel", onWheel, { passive: false });
    return () => el.removeEventListener("wheel", onWheel);
  }, []);

  const [qty, setQty] = useState<number>(300);
  const [autoRotate, setAutoRotate] = useState(true);
  const [closeUp, setCloseUp] = useState(false);
  const [exploded, setExploded] = useState(false);
  const [focusLayer, setFocusLayer] = useState<LayerKey | null>(null);
  const [meta, setMeta] = useState<BallTextureMeta | null>(null);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [quoteOpen, setQuoteOpen] = useState(false);
  const [logoError, setLogoError] = useState<string | null>(null);
  const [activeSlug, setActiveSlug] = useState(categories[0]?.slug ?? "");
  const seenArticles = useRef<Set<number>>(new Set());

  const article = articles.find((a) => a.id === articleId) ?? articles[0];
  const material = materials.find((m) => m.id === materialId) ?? materials[0];

  useEffect(() => {
    if (!article) return;
    if (seenArticles.current.has(article.id)) return;
    seenArticles.current.add(article.id);
    logActivity("article_view", String(article.id), { articleNo: article.articleNo });
  }, [article]);

  // Scroll-spy for the section chips
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries.filter((e) => e.isIntersecting).sort((a, b) => a.boundingClientRect.top - b.boundingClientRect.top);
        if (visible[0]) setActiveSlug(visible[0].target.id);
      },
      { rootMargin: "-25% 0px -60% 0px" }
    );
    categories.forEach((c) => {
      const el = document.getElementById(c.slug);
      if (el) observer.observe(el);
    });
    return () => observer.disconnect();
  }, [categories]);

  useEffect(() => {
    document.body.style.overflow = mobileOpen || quoteOpen ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [mobileOpen, quoteOpen]);

  // Every article carries its own default rexine (client requirement: no more
  // one shared material across the whole list). Applied on first open and
  // whenever the buyer switches article — manual material picks still win
  // until the next article switch.
  useEffect(() => {
    const a = articles.find((x) => x.id === articleId);
    if (!a?.defaultMaterialCode) return;
    const dm = materials.find((m) => m.code === a.defaultMaterialCode);
    if (dm) setMaterialId(dm.id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [articleId]);

  /* ---- Guided tour (item 5): the tour OPERATES the studio while it explains
          each control, so a first-time visitor sees the product working. ---- */
  const { demo } = useTour();
  useEffect(() => {
    if (!demo) return;
    switch (demo.action) {
      case "open-studio":
        if (typeof window !== "undefined" && window.innerWidth < 1024) setMobileOpen(true);
        break;
      case "select-featured": {
        const target = articles.find((a) => a.featured) ?? articles[1] ?? articles[0];
        if (!target) break;
        setArticleId(target.id);
        setQty((q) => (q < target.moq ? target.moq : q));
        setExploded(false);
        setCloseUp(false);
        break;
      }
      case "next-article": {
        const i = articles.findIndex((a) => a.id === articleId);
        const target = articles[(i + 1) % Math.max(1, articles.length)];
        if (!target) break;
        setArticleId(target.id);
        setQty((q) => (q < target.moq ? target.moq : q));
        break;
      }
      case "cycle-material": {
        if (materials.length < 2) break;
        const i = materials.findIndex((m) => m.id === materialId);
        const target = materials[(i + 1) % materials.length];
        setMaterialId(target.id);
        setExploded(false);
        break;
      }
      case "look-inside":
        setCloseUp(false);
        setExploded(true);
        setAutoRotate(false);
        break;
      case "close-up":
        setExploded(false);
        setCloseUp(true);
        break;
      case "reset-view":
        setExploded(false);
        setCloseUp(false);
        setFocusLayer(null);
        setAutoRotate(true);
        break;
      default:
        break;
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [demo?.nonce]);

  const selectArticle = useCallback((a: CatalogArticle) => {
    setArticleId(a.id);
    setQty((q) => (q < a.moq ? a.moq : q));
    setExploded(false);
    setFocusLayer(null);
    // On smaller screens the studio lives in a sheet — open the article directly.
    if (typeof window !== "undefined" && window.innerWidth < 1024) {
      setMobileOpen(true);
    }
  }, []);

  const price = useMemo(() => {
    if (!article || !material) return null;
    const unit = article.basePrice + material.priceDelta;
    const tier = [...tiers].sort((a, b) => b.minQty - a.minQty).find((t) => qty >= t.minQty);
    const discounted = tier ? unit * (1 - tier.discountPct / 100) : unit;
    return {
      base: article.basePrice,
      delta: material.priceDelta,
      tierPct: tier?.discountPct ?? 0,
      discounted,
      total: discounted * qty,
    };
  }, [article, material, qty, tiers]);

  const onLogoFile = (file: File | undefined | null) => {
    setLogoError(null);
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      setLogoError("Please choose an image file (PNG, JPG or SVG).");
      return;
    }
    if (file.size > 4 * 1024 * 1024) {
      setLogoError("Logo must be under 4 MB.");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      setLogoUrl(String(reader.result));
      setLogoName(file.name);
      // stop the spin so the buyer can drag the logo into place
      setAutoRotate(false);
      logActivity("logo_upload", article ? String(article.id) : undefined, { file: file.name });
    };
    reader.readAsDataURL(file);
  };

  if (!article) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-24 text-center text-ink-500">
        No live articles yet — the admin can add them in the dashboard.
      </div>
    );
  }

  const specs = article.specs ?? DEFAULT_SPECS;
  const layerMeta: Record<LayerKey, { name: string; detail: string }> = {
    cover: {
      name: "Rexine cover",
      detail: `${material?.name ?? "—"} · ${material?.thickness || "1.05 mm"}`,
    },
    foam: { name: "Impact foam", detail: `${specs.foamMm} mm EVA` },
    lining: { name: "Fabric lining", detail: specs.lining },
    bladder: { name: "Bladder", detail: specs.bladder },
  };
  const layerList: LayerKey[] = ["cover", "foam", "lining", "bladder"];

  /* ---------------- shared panel pieces ---------------- */

  const viewer = (
    <div
      data-tour="viewer"
      className="blueprint-grid relative overflow-hidden rounded-xl border border-ink-800 bg-ink-950"
    >
      <div className="h-[300px] sm:h-[380px] xl:h-[420px]">
        <SafeBoundary
          label="studio"
          height="100%"
          fallback={
            <SoftBall
              className="h-full w-full"
              panelStyle={article.panelStyle}
              colors={article.colors}
              rexineUrl={material?.textureUrl || null}
              artworkUrl={article.artworkUrl}
              designSvgUrl={article.designSvgUrl}
              seamStyle={article.seamStyle}
              label={`${article.panelCount}`}
              autoRotate={autoRotate}
              closeUp={closeUp}
              exploded={exploded}
              specs={specs}
              layerNames={layerMeta}
              focusLayer={focusLayer}
            />
          }
        >
        <BallViewer
          className="h-full w-full"
          panelStyle={article.panelStyle}
          colors={article.colors}
          rexineUrl={material?.textureUrl || null}
          artworkUrl={article.artworkUrl}
          designSvgUrl={article.designSvgUrl}
          modelUrl={article.modelUrl}
          renderUrl={article.renderUrl}
          layerImages={article.layerImages}
          seamStyle={article.seamStyle}
          modelAdjust={article.modelAdjust}
          logoUrl={logoUrl}
          logo={logoT}
          logoDraggable={!!logoUrl}
          onLogoMove={(p) => setLogoT((t) => ({ ...t, u: p.u, v: p.v }))}
          label={`${article.panelCount}`}
          roughness={material?.finish.toLowerCase().includes("matte") ? 0.62 : 0.4}
          autoRotate={autoRotate}
          closeUp={closeUp}
          exploded={exploded}
          specs={specs}
          layerNames={layerMeta}
          focusLayer={focusLayer}
          onMeta={setMeta}
        />
        </SafeBoundary>
      </div>

      <div className="pointer-events-none absolute left-4 top-4 flex flex-wrap items-center gap-2">
        <span className="rounded-md bg-black/55 px-2.5 py-1 font-display text-[11px] font-extrabold uppercase tracking-widest text-white backdrop-blur">
          {article.articleNo}
        </span>
        {article.modelUrl ? (
          <span className="rounded-md bg-ok px-2.5 py-1 text-[11px] font-extrabold text-white backdrop-blur">
            Studio 3D model · designer artwork
          </span>
        ) : meta?.mode === "svg" ? (
          <span className="rounded-md bg-brand-600 px-2.5 py-1 text-[11px] font-extrabold text-white backdrop-blur">
            Panel Intelligence · {meta.panels} panels auto-detected
          </span>
        ) : meta?.mode === "artwork" ? (
          <span className="rounded-md bg-white/15 px-2.5 py-1 text-[11px] font-bold text-white backdrop-blur">
            CorelDRAW full-wrap artwork
          </span>
        ) : (
          <span className="hidden rounded-md bg-black/55 px-2.5 py-1 text-[11px] font-semibold text-white/70 backdrop-blur sm:block">
            {article.panelCount}-panel construction
          </span>
        )}
      </div>

      <div className="absolute bottom-4 left-4 flex flex-wrap items-center gap-2">
        <button
          onClick={() => setAutoRotate((v) => !v)}
          className="grid h-9 w-9 place-items-center rounded-lg bg-black/55 text-white backdrop-blur transition hover:bg-brand-600"
          title={autoRotate ? "Pause rotation" : "Auto-rotate"}
        >
          {autoRotate ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
        </button>
        <button
          onClick={() => {
            setExploded(false);
            setCloseUp(true);
          }}
          className={cn(
            "flex h-9 items-center gap-1.5 rounded-lg bg-black/55 px-3 text-xs font-bold text-white backdrop-blur transition hover:bg-brand-600",
            closeUp && !exploded && "bg-brand-600"
          )}
        >
          <ZoomIn className="h-4 w-4" /> {t("config.closeUp", "Texture close-up")}
        </button>
        <button
          data-tour="look-inside"
          onClick={() => {
            setCloseUp(false);
            setExploded((v) => !v);
          }}
          className={cn(
            "flex h-9 items-center gap-1.5 rounded-lg px-3 text-xs font-bold backdrop-blur transition",
            exploded
              ? "bg-brand-600 text-white"
              : "bg-white/15 text-white hover:bg-brand-600"
          )}
        >
          <Layers className="h-4 w-4" />
          {exploded ? "Assemble ball" : t("config.lookInside", "Look inside")}
        </button>
        {(closeUp || exploded) && (
          <button
            onClick={() => {
              setCloseUp(false);
              setExploded(false);
            }}
            className="flex h-9 items-center gap-1.5 rounded-lg bg-white/15 px-3 text-xs font-bold text-white backdrop-blur transition hover:bg-white/25"
          >
            <Minimize2 className="h-4 w-4" /> Reset
          </button>
        )}
      </div>

      <p className="pointer-events-none absolute bottom-4 right-4 hidden rounded-md bg-black/45 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-wider text-white/60 backdrop-blur sm:block">
        {exploded ? "Drag to orbit the exploded layers" : "Drag to rotate · Scroll to zoom"}
      </p>
    </div>
  );

  const layerCards = (
    <section>
      <div className="mb-3 flex items-baseline justify-between">
        <h3 className="font-display text-sm font-extrabold uppercase tracking-[0.18em] text-ink-950">
          {t("config.insideTitle", "Inside this ball")}
        </h3>
        <span className="text-xs font-semibold text-ink-400">Hover a layer to isolate it</span>
      </div>
      <div className="space-y-2">
        {layerList.map((key) => (
          <div
            key={key}
            onMouseEnter={() => setFocusLayer(key)}
            onMouseLeave={() => setFocusLayer(null)}
            className={cn(
              "flex items-center justify-between gap-3 rounded-xl border bg-card p-3.5 transition",
              focusLayer === key ? "border-brand-600 ring-2 ring-brand-600/20" : "border-line"
            )}
          >
            <div className="min-w-0">
              <p className="text-sm font-extrabold text-ink-950">{layerMeta[key].name}</p>
              <p className="mt-0.5 text-xs text-ink-500">{layerMeta[key].detail}</p>
            </div>
            {key === "foam" ? (
              <span className="shrink-0 rounded-md bg-paper-deep px-2 py-1 font-display text-xs font-black text-ink-700">
                {specs.foamMm} mm
              </span>
            ) : key === "cover" ? (
              <span className="shrink-0 rounded-md bg-paper-deep px-2 py-1 font-display text-xs font-black text-ink-700">
                {material?.thickness || "1.05 mm"}
              </span>
            ) : (
              <span className="shrink-0 rounded-md bg-paper-deep px-2 py-1 font-display text-xs font-black text-ink-700">
                core
              </span>
            )}
          </div>
        ))}
      </div>
      <p className="mt-3 rounded-lg bg-paper-deep px-3.5 py-2.5 text-xs leading-relaxed text-ink-600">
        The exploded view shows the exact construction of {article.name}: {specs.lining.toLowerCase()} over a{" "}
        {specs.bladder.toLowerCase()}, cushioned with {specs.foamMm} mm of EVA under the selected rexine.
      </p>
    </section>
  );

  const materialPicker = (
    <section data-tour="materials">
      <div className="mb-3 flex items-baseline justify-between">
        <h3 className="font-display text-sm font-extrabold uppercase tracking-[0.18em] text-ink-950">
          {t("config.materialsTitle", "Rexine materials")}
        </h3>
        <span className="text-xs font-semibold text-ink-400">{materials.length} available</span>
      </div>
      <div className="grid grid-cols-2 gap-3 xl:grid-cols-3">
        {materials.map((m) => {
          const selected = m.id === material?.id;
          return (
            <button
              key={m.id}
              onClick={() => {
                setMaterialId(m.id);
                logActivity("material_select", String(m.id), {
                  materialId: m.id,
                  articleId: article.id,
                });
              }}
              className={cn(
                "group overflow-hidden rounded-xl border bg-card text-left transition",
                selected ? "border-brand-600 ring-2 ring-brand-600/25" : "border-line hover:border-ink-300"
              )}
            >
              <div className="relative h-16 overflow-hidden bg-ink-100">
                {m.textureUrl ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img
                    src={m.textureUrl}
                    alt={m.name}
                    className="h-full w-full object-cover transition duration-300 group-hover:scale-105"
                  />
                ) : (
                  <div className="grid h-full place-items-center text-ink-300">
                    <ImageIcon className="h-5 w-5" />
                  </div>
                )}
                {selected && (
                  <span className="absolute right-2 top-2 grid h-6 w-6 place-items-center rounded-full bg-brand-600 text-white shadow">
                    <Check className="h-3.5 w-3.5" />
                  </span>
                )}
              </div>
              <div className="p-3">
                <p className="text-[13px] font-bold leading-tight text-ink-900">{m.name}</p>
                <p className="mt-0.5 text-[11px] text-ink-400">{m.finish}</p>
                <p className="mt-1.5 text-xs font-extrabold text-brand-700">+{formatMoney(m.priceDelta)}</p>
              </div>
            </button>
          );
        })}
      </div>
      {material && (
        <p className="mt-3 rounded-lg bg-paper-deep px-3.5 py-2.5 text-xs leading-relaxed text-ink-600">
          <span className="font-bold text-ink-900">{material.name}:</span> {material.description}
          {material.thickness && <span className="text-ink-400"> · {material.thickness} thick</span>}
          {material.weightGsm && <span className="text-ink-400"> · {material.weightGsm} gsm</span>}
        </p>
      )}
    </section>
  );

  /* Item 1: the "add your logo" upload option is REMOVED from the buyer studio.
     The catalog shows Forward Sports' own articles only — logo/branding artwork
     is part of the baked 3D model supplied by the designer, so buyers no longer
     upload anything here. The 3D plumbing (logoUrl / logo placement) is kept
     intact but never receives a file, so a future re-enable is a one-line change. */

  const pricePanel = (
    <section data-tour="price" className="rounded-xl border border-line bg-card p-5">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h3 className="font-display text-sm font-extrabold uppercase tracking-[0.18em] text-ink-950">
            {t("config.priceTitle", "Live FOB price")}
          </h3>
          <p className="mt-0.5 text-[11px] text-ink-400">{t("config.priceSub", "USD · FOB Sialkot · per unit")}</p>
        </div>
        {price && price.tierPct > 0 && (
          <span className="rounded-md bg-ok-soft px-2 py-1 text-[11px] font-extrabold text-ok">
            −{price.tierPct}% volume tier
          </span>
        )}
      </div>
      <dl className="mt-4 space-y-1.5 text-sm">
        <div className="flex justify-between text-ink-600">
          <dt>{article.name} — FOB base</dt>
          <dd className="font-semibold">{formatMoney(price?.base)}</dd>
        </div>
        <div className="flex justify-between text-ink-600">
          <dt>{material?.name ?? "Rexine"}</dt>
          <dd className="font-semibold">+{formatMoney(price?.delta)}</dd>
        </div>
        {price && price.tierPct > 0 && (
          <div className="flex justify-between text-ok">
            <dt>Volume discount ({qty} pcs)</dt>
            <dd className="font-semibold">−{price.tierPct}%</dd>
          </div>
        )}
      </dl>
      <div className="mt-4 flex items-end justify-between border-t border-line pt-4">
        <div>
          <p className="text-[11px] font-bold uppercase tracking-wider text-ink-400">Unit price</p>
          <p className="font-display text-3xl font-black text-ink-950">{formatMoney(price?.discounted)}</p>
        </div>
        <label className="text-right">
          <span className="mb-1 block text-[11px] font-bold uppercase tracking-wider text-ink-400">Quantity</span>
          <input
            type="number"
            min={1}
            value={qty}
            onChange={(e) => setQty(Math.max(1, Number(e.target.value) || 1))}
            className="w-28 rounded-lg border border-line bg-paper px-3 py-2 text-right font-bold text-ink-900 outline-none focus:border-brand-500"
          />
        </label>
      </div>
      <div className="mt-2 flex items-center justify-between text-xs text-ink-500">
        <span>Estimated FOB total ({qty} pcs)</span>
        <span className="font-display text-base font-extrabold text-brand-700">{formatMoney(price?.total)}</span>
      </div>
      <p className="mt-2 rounded-md bg-paper-deep px-2.5 py-1.5 text-[11px] font-semibold text-ink-600">
        MOQ for this model: <span className="font-extrabold text-ink-900">{article.moq} pcs</span> · prices are FOB
        Sialkot, ex-works packing included
      </p>
      {qty < article.moq && (
        <p className="mt-2 rounded-md bg-warn-soft px-2.5 py-1.5 text-[11px] font-semibold text-warn">
          Below MOQ ({article.moq} pcs) — production lead time may vary.
        </p>
      )}
    </section>
  );

  const cta = (
    <div data-tour="quote">
      <button
        onClick={() => setQuoteOpen(true)}
        className="flex w-full items-center justify-center gap-2 rounded-xl bg-brand-600 px-5 py-3.5 font-display text-sm font-extrabold uppercase tracking-widest text-white shadow-lg shadow-brand-600/25 transition hover:bg-brand-500"
      >
        <Send className="h-4 w-4" /> {t("config.quoteCta", "Request quote for this build")}
      </button>
    </div>
  );

  const panel = (
    <>
      {viewer}
      {exploded ? layerCards : materialPicker}
      {pricePanel}
      {cta}
    </>
  );

  /* ---------------- page ---------------- */

  return (
    <div className="pb-24 lg:pb-0">
      {/* Page intro */}
      <div className="border-b border-line bg-card">
        <div className="mx-auto max-w-[1440px] px-4 py-10 sm:px-6">
          <p className="text-xs font-extrabold uppercase tracking-[0.28em] text-brand-700">
            {t("catalog.eyebrow", "Forward Sports · one catalog, every construction")}
          </p>
          <h1 className="mt-2 font-display text-3xl font-black uppercase tracking-tight text-ink-950 sm:text-4xl">
            {t("catalog.title", "The complete ball range")}
          </h1>
          <p className="mt-3 max-w-2xl text-sm leading-relaxed text-ink-500">
            {articles.length} articles across {categories.length} construction families.{" "}
            {t(
              "catalog.intro",
              "The page is split in two: the article list and descriptions scroll on the left, while the 3D studio on the right stays put with the live model, the rexine picker, the price and the quote button. Put your cursor inside the right pane and scroll to move through its controls — it even opens the ball up to show the bladder, foam and lining inside."
            )}
          </p>
        </div>
      </div>

      {/* TWO INDEPENDENT PANES (item 4): the article list on the left scrolls
          with the page; the 3D studio on the right is pinned to the viewport and
          only scrolls when the cursor is inside it (overscroll-contain stops the
          page from moving). The split runs all the way down to the footer. */}
      <div className="mx-auto grid max-w-[1440px] gap-0 px-4 sm:px-6 lg:grid-cols-[minmax(0,1fr)_460px] xl:grid-cols-[minmax(0,1fr)_490px]">
        {/* LEFT — articles + descriptions */}
        <div className="min-w-0 lg:pr-9">
          {/* Section chips */}
          <div className="sticky top-16 z-30 -mx-4 border-b border-line bg-paper/95 px-4 py-3 backdrop-blur sm:-mx-6 sm:px-6 lg:-mr-9 lg:pl-0">
            <div className="flex gap-2 overflow-x-auto no-scrollbar">
          {categories.map((c) => (
            <a
              key={c.slug}
              href={`#${c.slug}`}
              className={cn(
                "flex shrink-0 items-center gap-2 rounded-lg px-3.5 py-2 text-xs font-extrabold uppercase tracking-wide transition",
                activeSlug === c.slug
                  ? "bg-brand-600 text-white"
                  : "bg-card text-ink-600 hover:text-brand-700"
              )}
            >
              <CategoryIcon iconKey={c.iconKey} className="h-3.5 w-3.5" />
              {c.shortName}
            </a>
          ))}
            </div>
          </div>

          {/* Sections */}
          <div data-tour="article-list" className="space-y-14 py-10">
          {categories.map((cat) => {
            const inCat = articles.filter((a) => a.categoryId === cat.id);
            return (
              <section key={cat.id} id={cat.slug} className="scroll-mt-40">
                <header className="mb-5 flex items-center gap-4">
                  <span className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-ink-950 text-white">
                    <CategoryIcon iconKey={cat.iconKey} className="h-5 w-5" />
                  </span>
                  <div className="min-w-0">
                    <h2 className="font-display text-2xl font-black uppercase tracking-tight text-ink-950">
                      {cat.name}
                    </h2>
                    <p className="mt-0.5 text-[13px] text-ink-500">{cat.tagline}</p>
                  </div>
                  <span className="ml-auto hidden shrink-0 rounded-lg bg-card px-3 py-1.5 text-xs font-extrabold text-ink-500 sm:block">
                    {inCat.length} article{inCat.length === 1 ? "" : "s"}
                  </span>
                </header>
                <div className="space-y-3">
                  {inCat.map((a) => {
                    const sel = a.id === article.id;
                    const dMin = materials.length ? a.basePrice + Math.min(...materials.map((m) => m.priceDelta)) : a.basePrice;
                    const dMax = materials.length ? a.basePrice + Math.max(...materials.map((m) => m.priceDelta)) : a.basePrice;
                    return (
                      <button
                        key={a.id}
                        onClick={() => selectArticle(a)}
                        className={cn(
                          "flex w-full items-center gap-4 rounded-xl border bg-card p-3.5 text-left transition",
                          sel ? "border-brand-600 ring-2 ring-brand-600/20" : "border-line hover:border-ink-300"
                        )}
                      >
                        <BallThumb
                          panelStyle={a.panelStyle}
                          colors={a.colors}
                          artworkUrl={a.artworkUrl}
                          designSvgUrl={a.designSvgUrl}
                          seamStyle={a.seamStyle}
                          size={68}
                        />
                        <span className="min-w-0 flex-1">
                          <span className="flex flex-wrap items-center gap-2">
                            <span className="text-sm font-extrabold text-ink-950">{a.name}</span>
                            {a.featured && (
                              <span className="rounded bg-brand-600/10 px-1.5 py-0.5 text-[10px] font-extrabold uppercase tracking-wider text-brand-700">
                                Featured
                              </span>
                            )}
                            {a.designSvgUrl && !a.modelUrl && (
                              <span className="rounded bg-ink-950 px-1.5 py-0.5 text-[10px] font-extrabold uppercase tracking-wider text-white">
                                Vector panels
                              </span>
                            )}
                            {a.modelUrl && (
                              <span className="rounded bg-ok px-1.5 py-0.5 text-[10px] font-extrabold uppercase tracking-wider text-white">
                                3D model
                              </span>
                            )}
                            {!a.modelUrl && a.renderUrl && (
                              <span className="rounded bg-ink-700 px-1.5 py-0.5 text-[10px] font-extrabold uppercase tracking-wider text-white">
                                3D render
                              </span>
                            )}
                          </span>
                          <span className="mt-0.5 block text-[11px] font-bold uppercase tracking-wider text-ink-400">
                            {a.articleNo} · {a.panelCount} panels · MOQ {a.moq}
                          </span>
                          <span className="mt-1 line-clamp-2 block text-xs leading-relaxed text-ink-500">
                            {a.description}
                          </span>
                        </span>
                        <span className="shrink-0 text-right">
                          <span className="block text-[10px] font-bold uppercase tracking-wider text-ink-400">
                            FOB range · MOQ {a.moq}
                          </span>
                          <span className="block font-display text-base font-black text-ink-950">{formatMoney(dMin)}</span>
                          <span className="block text-[11px] font-semibold text-ink-500">– {formatMoney(dMax)}</span>
                        </span>
                      </button>
                    );
                  })}
                </div>
              </section>
            );
          })}
          </div>
        </div>

        {/* RIGHT — 3D view, rexine, price and quote: a pinned, full-height pane
            with its OWN scrollbar. The page (left column) scrolls past it; the
            pane only moves when the cursor is inside it, and its scroll never
            chains into the page (railRef wheel trap + overscroll-contain). The
            divider line runs the whole way down to the footer. */}
        <aside className="hidden lg:block lg:border-l lg:border-line">
          <div
            ref={railRef}
            data-tour="studio-rail"
            className="sticky top-16 h-[calc(100vh-4rem)] space-y-5 overflow-y-auto overscroll-contain py-8 pl-9"
          >
            {panel}
          </div>
        </aside>
      </div>

      {/* Mobile configure bar */}
      <div className="fixed inset-x-0 bottom-0 z-40 border-t border-ink-800 bg-ink-950 px-4 py-3 lg:hidden">
        <div className="flex items-center justify-between gap-3">
          <div className="min-w-0">
            <p className="truncate text-sm font-extrabold text-white">{article.name}</p>
            <p className="text-xs font-bold text-brand-400">{formatMoney(price?.discounted)} / unit</p>
          </div>
          <button
            onClick={() => setMobileOpen(true)}
            className="shrink-0 rounded-xl bg-brand-600 px-5 py-2.5 font-display text-xs font-extrabold uppercase tracking-widest text-white"
          >
            {t("config.mobileCta", "Configure in 3D")}
          </button>
        </div>
      </div>

      {/* Mobile studio sheet */}
      {mobileOpen && (
        <div className="fixed inset-0 z-[60] lg:hidden">
          {/* dimmed backdrop — the article list stays visible behind the panel
              and a single click dismisses it (no more full-page takeover) */}
          <div
            className="absolute inset-0 animate-[sf-fade_.18s_ease-out] bg-ink-950/45 backdrop-blur-[2px]"
            onClick={() => setMobileOpen(false)}
            aria-hidden
          />
          <aside className="absolute inset-y-0 right-0 flex w-full max-w-xl animate-[sf-drawer_.26s_cubic-bezier(.2,.8,.2,1)] flex-col border-l border-line bg-paper shadow-2xl">
            <div className="flex items-center justify-between border-b border-line bg-paper/95 px-4 py-3 backdrop-blur">
              <p className="font-display text-sm font-black uppercase tracking-widest text-ink-950">
                3D configurator
              </p>
              <button
                onClick={() => setMobileOpen(false)}
                className="rounded-lg border border-line p-2 text-ink-600 hover:bg-card"
                aria-label="Close configurator"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <div className="flex-1 space-y-5 overflow-y-auto px-4 py-5">{panel}</div>
          </aside>
        </div>
      )}

      {quoteOpen && (
        <QuoteModal
          article={article}
          material={material ?? null}
          qty={qty}
          unit={price?.discounted ?? 0}
          total={price?.total ?? 0}
          logoName={logoName}
          onClose={() => setQuoteOpen(false)}
        />
      )}
    </div>
  );
}

/* ---------------- logo placement ---------------- */

const LOGO_SPOTS: Array<{ label: string; u: number; v: number }> = [
  { label: "Front panel", u: 0.5, v: 0.5 },
  { label: "Left panel", u: 0.29, v: 0.5 },
  { label: "Right panel", u: 0.71, v: 0.5 },
  { label: "Top", u: 0.5, v: 0.2 },
  { label: "Bottom", u: 0.5, v: 0.8 },
];

function LogoControls({
  value,
  onChange,
}: {
  value: LogoTransform;
  onChange: (t: LogoTransform) => void;
}) {
  return (
    <div className="mt-3 rounded-xl border border-line bg-card p-4">
      <div className="flex items-baseline justify-between">
        <h4 className="font-display text-xs font-extrabold uppercase tracking-[0.18em] text-ink-950">
          Place your logo
        </h4>
        <button
          onClick={() => onChange(DEFAULT_LOGO_TRANSFORM)}
          className="flex items-center gap-1 text-[11px] font-bold text-ink-500 hover:text-brand-700"
        >
          <RotateCcw className="h-3 w-3" /> Reset
        </button>
      </div>
      <p className="mt-1 text-[11px] leading-relaxed text-ink-500">
        <span className="font-bold text-ink-700">Drag the logo directly on the 3D ball</span>, or pick a panel below.
      </p>

      <div className="mt-3 flex flex-wrap gap-1.5">
        {LOGO_SPOTS.map((s) => {
          const active = Math.abs(value.u - s.u) < 0.02 && Math.abs(value.v - s.v) < 0.02;
          return (
            <button
              key={s.label}
              onClick={() => onChange({ ...value, u: s.u, v: s.v })}
              className={cn(
                "rounded-lg px-2.5 py-1.5 text-[11px] font-bold transition",
                active
                  ? "bg-brand-600 text-white"
                  : "border border-line bg-paper text-ink-600 hover:border-brand-300 hover:text-brand-700"
              )}
            >
              {s.label}
            </button>
          );
        })}
      </div>

      <div className="mt-4 space-y-3">
        <label className="block">
          <span className="mb-1 flex justify-between text-[11px] font-bold uppercase tracking-wider text-ink-500">
            Size <span className="text-ink-700">{Math.round(value.scale * 100)}%</span>
          </span>
          <input
            type="range"
            min={0.3}
            max={2}
            step={0.05}
            value={value.scale}
            onChange={(e) => onChange({ ...value, scale: Number(e.target.value) })}
            className="w-full accent-brand-600"
          />
        </label>
        <label className="block">
          <span className="mb-1 flex justify-between text-[11px] font-bold uppercase tracking-wider text-ink-500">
            Rotation <span className="text-ink-700">{Math.round(value.rotate)}°</span>
          </span>
          <input
            type="range"
            min={-180}
            max={180}
            step={1}
            value={value.rotate}
            onChange={(e) => onChange({ ...value, rotate: Number(e.target.value) })}
            className="w-full accent-brand-600"
          />
        </label>
        <div className="flex items-center justify-between rounded-lg bg-paper px-3 py-2">
          <span className="text-[11px] font-bold text-ink-600">White patch behind logo</span>
          <button
            onClick={() => onChange({ ...value, badge: !value.badge })}
            className={cn(
              "relative h-5 w-9 rounded-full transition",
              value.badge ? "bg-ok" : "bg-ink-200"
            )}
            aria-pressed={value.badge}
          >
            <span
              className={cn(
                "absolute top-0.5 h-4 w-4 rounded-full bg-white shadow transition-all",
                value.badge ? "left-[18px]" : "left-0.5"
              )}
            />
          </button>
        </div>
      </div>
    </div>
  );
}

/* ---------------- quote modal ---------------- */

function QuoteModal({
  article,
  material,
  qty,
  unit,
  total,
  logoName,
  onClose,
}: {
  article: CatalogArticle;
  material: CatalogMaterial | null;
  qty: number;
  unit: number;
  total: number;
  logoName: string | null;
  onClose: () => void;
}) {
  const [form, setForm] = useState({ name: "", company: "", email: "", message: "" });
  const [sending, setSending] = useState(false);
  const [done, setDone] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSending(true);
    setError(null);
    try {
      const res = await fetch("/api/quote", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          articleId: article.id,
          materialId: material?.id ?? null,
          customerName: form.name,
          company: form.company,
          email: form.email,
          quantity: qty,
          unitPrice: unit,
          total,
          logoName,
          message: form.message,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Could not submit the request.");
      setDone(data.ref as string);
      logActivity("quote_request", String(article.id), { ref: data.ref });
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[80] grid place-items-center bg-ink-950/60 p-4 backdrop-blur-sm">
      <div className="max-h-[92vh] w-full max-w-lg overflow-y-auto rounded-2xl border border-line bg-card shadow-2xl anim-fade-up">
        {done ? (
          <div className="p-8 text-center">
            <span className="mx-auto grid h-14 w-14 place-items-center rounded-full bg-ok-soft text-ok">
              <Check className="h-7 w-7" />
            </span>
            <h3 className="mt-4 font-display text-xl font-black text-ink-950">Request received</h3>
            <p className="mt-2 text-sm text-ink-600">
              Your configuration reference is <span className="font-extrabold text-brand-700">{done}</span>. Our sales
              team will respond within one working day with FOB pricing and sampling options.
            </p>
            <button
              onClick={onClose}
              className="mt-6 rounded-xl bg-ink-950 px-6 py-2.5 text-sm font-bold text-white hover:bg-ink-800"
            >
              Back to catalog
            </button>
          </div>
        ) : (
          <form onSubmit={submit}>
            <div className="flex items-start justify-between border-b border-line bg-paper px-6 py-4">
              <div>
                <h3 className="font-display text-lg font-black text-ink-950">Request a quote</h3>
                <p className="text-xs text-ink-500">
                  {article.name}
                  {material ? ` · ${material.name}` : ""} · {qty} pcs · {formatMoney(total)}
                </p>
              </div>
              <button type="button" onClick={onClose} className="text-ink-400 hover:text-ink-700">
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="space-y-3.5 px-6 py-5">
              <div className="grid gap-3.5 sm:grid-cols-2">
                <label className="block">
                  <span className="mb-1 block text-[11px] font-bold uppercase tracking-wider text-ink-500">
                    Your name *
                  </span>
                  <input
                    required
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                    className="w-full rounded-lg border border-line bg-paper px-3 py-2.5 text-sm outline-none focus:border-brand-500"
                    placeholder="Jane Buyer"
                  />
                </label>
                <label className="block">
                  <span className="mb-1 block text-[11px] font-bold uppercase tracking-wider text-ink-500">
                    Company
                  </span>
                  <input
                    value={form.company}
                    onChange={(e) => setForm({ ...form, company: e.target.value })}
                    className="w-full rounded-lg border border-line bg-paper px-3 py-2.5 text-sm outline-none focus:border-brand-500"
                    placeholder="Club / brand / distributor"
                  />
                </label>
              </div>
              <label className="block">
                <span className="mb-1 block text-[11px] font-bold uppercase tracking-wider text-ink-500">
                  Business email *
                </span>
                <input
                  required
                  type="email"
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  className="w-full rounded-lg border border-line bg-paper px-3 py-2.5 text-sm outline-none focus:border-brand-500"
                  placeholder="you@company.com"
                />
              </label>
              <label className="block">
                <span className="mb-1 block text-[11px] font-bold uppercase tracking-wider text-ink-500">
                  Notes for the sales team
                </span>
                <textarea
                  rows={3}
                  value={form.message}
                  onChange={(e) => setForm({ ...form, message: e.target.value })}
                  className="w-full rounded-lg border border-line bg-paper px-3 py-2.5 text-sm outline-none focus:border-brand-500"
                  placeholder="Colourways, print positions, target price, delivery market…"
                />
              </label>
              {logoName && (
                <p className="rounded-lg bg-paper px-3 py-2 text-xs text-ink-600">
                  Logo attached: <span className="font-bold">{logoName}</span>
                </p>
              )}
              {error && <p className="text-xs font-bold text-danger">{error}</p>}
            </div>
            <div className="flex items-center justify-end gap-2 border-t border-line bg-paper px-6 py-4">
              <button
                type="button"
                onClick={onClose}
                className="rounded-lg border border-line px-4 py-2.5 text-sm font-bold text-ink-600 hover:bg-card"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={sending}
                className="flex items-center gap-2 rounded-lg bg-brand-600 px-5 py-2.5 text-sm font-extrabold text-white hover:bg-brand-500 disabled:opacity-60"
              >
                {sending ? <RotateCcw className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                {sending ? "Sending…" : "Submit request"}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
