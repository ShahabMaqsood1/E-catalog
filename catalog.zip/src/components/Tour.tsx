"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { usePathname } from "next/navigation";
import { ChevronLeft, ChevronRight, Compass, ListChecks, Play, X } from "lucide-react";
import { TOURS, TOUR_META, type TourDemo, type TourId } from "@/lib/tour-steps";
import { cn } from "@/lib/utils";

type Demo = { action: TourDemo; nonce: number } | null;

type TourContextValue = {
  startTour: (id: TourId) => void;
  isActive: boolean;
  /** true once the visitor has finished (or skipped) the tour for this page */
  seen: boolean;
  /** The configurator/hero listen to this and perform the action themselves,
   *  so the tour DEMONSTRATES the product instead of just describing it. */
  demo: Demo;
};

const TourContext = createContext<TourContextValue>({
  startTour: () => {},
  isActive: false,
  seen: true,
  demo: null,
});

export function useTour() {
  return useContext(TourContext);
}

function tourForPath(pathname: string): TourId {
  if (pathname.startsWith("/admin")) return "admin";
  if (pathname.startsWith("/catalog")) return "catalog";
  if (pathname.startsWith("/contact")) return "contact";
  return "home";
}

const seenKey = (id: TourId) => `fs-tour-seen-${id}`;

function isVisible(el: Element | null): boolean {
  if (!el) return false;
  const r = el.getBoundingClientRect();
  if (r.width < 4 || r.height < 4) return false;
  const style = window.getComputedStyle(el);
  return style.display !== "none" && style.visibility !== "hidden";
}

const TIP_W = 380;

export function TourProvider({ children }: { children: ReactNode }) {
  const pathname = usePathname();
  const [tourId, setTourId] = useState<TourId | null>(null);
  const [steps, setSteps] = useState<typeof TOURS.home>([]);
  const [stepIdx, setStepIdx] = useState(0);
  const [rect, setRect] = useState<DOMRect | null>(null);
  const [welcome, setWelcome] = useState<TourId | null>(null);
  const [chapters, setChapters] = useState(false);
  const [demo, setDemo] = useState<Demo>(null);
  const [seen, setSeen] = useState(true);
  const nonce = useRef(0);

  /* ---- which tour belongs to this page, and has it been seen? ---- */
  const pageTour = tourForPath(pathname);

  useEffect(() => {
    try {
      setSeen(!!localStorage.getItem(seenKey(pageTour)));
    } catch {
      setSeen(true);
    }
  }, [pageTour]);

  /* ---- first visit: offer the tour with a real welcome sheet ---- */
  useEffect(() => {
    try {
      if (localStorage.getItem(seenKey(pageTour))) return;
    } catch {
      return;
    }
    const t = setTimeout(() => setWelcome(pageTour), 1400);
    return () => clearTimeout(t);
  }, [pageTour]);

  const markSeen = useCallback((id: TourId) => {
    try {
      localStorage.setItem(seenKey(id), "1");
    } catch {
      /* private mode */
    }
    setSeen(true);
  }, []);

  const startTour = useCallback(
    (id: TourId) => {
      const available = TOURS[id].filter((s) => isVisible(document.querySelector(s.target)));
      const list = available.length ? available : TOURS[id].filter((s) => document.querySelector(s.target));
      if (!list.length) return;
      setSteps(list);
      setStepIdx(0);
      setChapters(false);
      setTourId(id);
      setWelcome(null);
      nonce.current = 0;
      setDemo(null);
    },
    []
  );

  const finish = useCallback(() => {
    if (tourId) markSeen(tourId);
    setTourId(null);
    setRect(null);
    setChapters(false);
  }, [tourId, markSeen]);

  /* ---- measure the highlighted element (rAF keeps it glued during any scroll) ---- */
  useEffect(() => {
    if (!tourId) return;
    const step = steps[stepIdx];
    if (!step) return;
    let raf = 0;
    let last = "";
    const el = document.querySelector(step.target);
    el?.scrollIntoView({ block: "center", behavior: "smooth" });
    const tick = () => {
      const node = document.querySelector(step.target);
      if (!node || !isVisible(node)) {
        // target disappeared (e.g. a drawer closed) — skip ahead
        setStepIdx((i) => (i + 1 >= steps.length ? i : i + 1));
      } else {
        const r = node.getBoundingClientRect();
        const key = `${Math.round(r.top)}:${Math.round(r.left)}:${Math.round(r.width)}:${Math.round(r.height)}`;
        if (key !== last) {
          last = key;
          setRect(r);
        }
      }
      raf = window.setTimeout(() => (raf = requestAnimationFrame(tick)), 120) as unknown as number;
    };
    tick();
    return () => {
      cancelAnimationFrame(raf);
      clearTimeout(raf);
    };
  }, [tourId, steps, stepIdx]);

  /* ---- fire the demo action for the active step ---- */
  useEffect(() => {
    if (!tourId) return;
    const step = steps[stepIdx];
    if (step?.demo) {
      nonce.current += 1;
      setDemo({ action: step.demo, nonce: nonce.current });
    }
  }, [tourId, steps, stepIdx]);

  const next = useCallback(() => {
    setStepIdx((i) => {
      if (i >= steps.length - 1) {
        finish();
        return i;
      }
      return i + 1;
    });
  }, [steps.length, finish]);

  const back = useCallback(() => setStepIdx((i) => Math.max(0, i - 1)), []);

  useEffect(() => {
    if (welcome && !tourId) {
      const onKey = (e: KeyboardEvent) => {
        if (e.key === "Escape") setWelcome(null);
        if (e.key === "Enter") startTour(welcome);
      };
      window.addEventListener("keydown", onKey);
      return () => window.removeEventListener("keydown", onKey);
    }
    if (!tourId) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") finish();
      if (e.key === "ArrowRight") next();
      if (e.key === "ArrowLeft") back();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [tourId, welcome, next, back, finish, startTour]);

  const meta = tourId ? TOUR_META[tourId] : null;
  const step = steps[stepIdx];

  const tipStyle = useMemo(() => {
    const vw = typeof window !== "undefined" ? window.innerWidth : 1200;
    const vh = typeof window !== "undefined" ? window.innerHeight : 800;
    if (!rect) return { top: vh - 330, left: Math.max(16, vw - TIP_W - 24) };
    const tipH = 300;
    let top = 0;
    let left = 0;
    const placement = step?.placement ?? "bottom";
    if (placement === "bottom") {
      top = rect.bottom + 16;
      left = rect.left + rect.width / 2 - TIP_W / 2;
    } else if (placement === "top") {
      top = rect.top - 16 - tipH;
      left = rect.left + rect.width / 2 - TIP_W / 2;
    } else if (placement === "left") {
      top = rect.top + rect.height / 2 - tipH / 2;
      left = rect.left - TIP_W - 16;
    } else {
      top = rect.top + rect.height / 2 - tipH / 2;
      left = rect.right + 16;
    }
    // never cover the highlighted element: if there is no room on the wanted
    // side, flip to the other one
    if (placement === "left" && left < 12) left = Math.min(rect.right + 16, vw - TIP_W - 12);
    if (placement === "right" && left + TIP_W > vw - 12) left = Math.max(12, rect.left - TIP_W - 16);
    left = Math.max(12, Math.min(left, vw - TIP_W - 12));
    top = Math.max(12, Math.min(top, vh - tipH - 12));
    return { top, left };
  }, [rect, step]);

  const value = useMemo(
    () => ({ startTour, isActive: !!tourId, seen, demo }),
    [startTour, tourId, seen, demo]
  );

  const welcomeMeta = welcome ? TOUR_META[welcome] : null;

  return (
    <TourContext.Provider value={value}>
      {children}

      {/* ------------------------------------------------ welcome sheet ---- */}
      {welcome && welcomeMeta && !tourId && (
        <div className="fixed inset-0 z-[95] grid place-items-center bg-ink-950/70 p-4 backdrop-blur-sm anim-fade-up">
          <div className="w-full max-w-lg overflow-hidden rounded-2xl border border-line bg-card shadow-2xl">
            <div className="relative bg-ink-950 px-6 py-6">
              <span className="absolute right-4 top-4 rounded-full bg-brand-600/20 px-2.5 py-1 text-[10px] font-extrabold uppercase tracking-widest text-brand-400">
                {welcomeMeta.minutes} guided tour
              </span>
              <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-brand-600 text-white">
                <Compass className="h-5 w-5" />
              </span>
              <h2 className="mt-3 font-display text-xl font-black uppercase tracking-tight text-white">
                {welcomeMeta.title}
              </h2>
              <p className="mt-2 text-[13px] leading-relaxed text-white/65">{welcomeMeta.intro}</p>
            </div>
            <div className="px-6 py-5">
              <p className="text-[11px] font-extrabold uppercase tracking-[0.18em] text-ink-400">What you will see</p>
              <ul className="mt-3 grid gap-2">
                {TOURS[welcome]
                  .filter((s) => s.chapter)
                  .slice(0, 6)
                  .map((s, i) => (
                    <li key={i} className="flex items-start gap-2.5 text-[13px] text-ink-600">
                      <span className="mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-md bg-brand-600/10 text-[10px] font-extrabold text-brand-700">
                        {i + 1}
                      </span>
                      <span>
                        <b className="font-bold text-ink-900">{s.chapter}</b> — {s.title}
                      </span>
                    </li>
                  ))}
              </ul>
              <div className="mt-5 flex items-center justify-between gap-3">
                <button
                  onClick={() => {
                    markSeen(welcome);
                    setWelcome(null);
                  }}
                  className="text-xs font-semibold text-ink-400 hover:text-ink-700"
                >
                  Not now
                </button>
                <button
                  onClick={() => startTour(welcome)}
                  className="flex items-center gap-2 rounded-xl bg-brand-600 px-5 py-3 font-display text-xs font-extrabold uppercase tracking-widest text-white hover:bg-brand-500"
                >
                  <Play className="h-4 w-4" /> Start the tour
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ------------------------------------------------ tour overlay ---- */}
      {tourId && meta && step && (
        <div className="fixed inset-0 z-[100]">
          {rect ? (
            <div
              className="pointer-events-none fixed rounded-xl transition-all duration-200"
              style={{
                top: rect.top - 6,
                left: rect.left - 6,
                width: rect.width + 12,
                height: rect.height + 12,
                boxShadow: "0 0 0 9999px rgba(16,14,12,0.7)",
                outline: "2px solid rgba(203,0,0,0.95)",
              }}
            />
          ) : (
            <div className="fixed inset-0 bg-ink-950/70" />
          )}

          <div
            className="fixed z-[101] w-[380px] max-w-[calc(100vw-24px)] overflow-hidden rounded-2xl border border-line bg-card shadow-2xl anim-fade-up"
            style={tipStyle}
          >
            {/* progress */}
            <div className="h-1 w-full bg-ink-100">
              <div
                className="h-1 bg-brand-600 transition-all duration-300"
                style={{ width: `${((stepIdx + 1) / steps.length) * 100}%` }}
              />
            </div>

            <div className="flex items-center justify-between border-b border-line bg-paper px-5 py-3">
              <span className="flex items-center gap-2">
                <Compass className="h-4 w-4 text-brand-600" />
                <span className="font-display text-[11px] font-extrabold uppercase tracking-[0.16em] text-ink-500">
                  {step.chapter || meta.title}
                </span>
              </span>
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => setChapters((v) => !v)}
                  className="rounded-md p-1.5 text-ink-400 transition hover:bg-card hover:text-ink-700"
                  aria-label="Tour contents"
                  title="Tour contents"
                >
                  <ListChecks className="h-4 w-4" />
                </button>
                <button onClick={finish} className="rounded-md p-1.5 text-ink-400 hover:bg-card hover:text-ink-700" aria-label="Close tour">
                  <X className="h-4 w-4" />
                </button>
              </div>
            </div>

            {chapters && (
              <div className="max-h-52 overflow-y-auto border-b border-line bg-paper px-5 py-3">
                {steps.map((s, i) => (
                  <button
                    key={i}
                    onClick={() => {
                      setStepIdx(i);
                      setChapters(false);
                    }}
                    className={cn(
                      "flex w-full items-center gap-2 rounded-lg px-2 py-1.5 text-left text-xs",
                      i === stepIdx ? "bg-brand-600/10 font-bold text-brand-700" : "text-ink-500 hover:bg-card"
                    )}
                  >
                    <span className="w-4 shrink-0 text-[10px] font-extrabold">{i + 1}</span>
                    <span className="truncate">{s.title}</span>
                  </button>
                ))}
              </div>
            )}

            <div className="px-5 py-4">
              <h3 className="font-display text-[17px] font-black leading-tight text-ink-950">{step.title}</h3>
              <p className="mt-2 text-[13px] leading-relaxed text-ink-600">{step.body}</p>

              {step.demo && (
                <p className="mt-3 flex items-start gap-2 rounded-lg bg-ok-soft px-3 py-2 text-[11px] font-bold leading-relaxed text-ok">
                  <span className="mt-0.5 h-1.5 w-1.5 shrink-0 animate-pulse rounded-full bg-ok" />
                  Live demo — the catalog is doing this for you right now.
                </p>
              )}
              {!step.demo && step.tip && (
                <p className="mt-3 rounded-lg bg-paper-deep px-3 py-2 text-[11px] font-semibold leading-relaxed text-ink-500">
                  <b className="font-extrabold text-ink-700">Try it: </b>
                  {step.tip}
                </p>
              )}

              <div className="mt-4 flex items-center justify-between gap-2">
                <div className="flex items-center gap-1">
                  {steps.map((_, i) => (
                    <button
                      key={i}
                      onClick={() => setStepIdx(i)}
                      aria-label={`Step ${i + 1}`}
                      className={cn(
                        "h-1.5 rounded-full transition-all",
                        i === stepIdx ? "w-5 bg-brand-600" : "w-1.5 bg-ink-200 hover:bg-ink-300"
                      )}
                    />
                  ))}
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={back}
                    disabled={stepIdx === 0}
                    className="flex items-center gap-1 rounded-lg border border-line px-3 py-2 text-xs font-bold text-ink-700 transition hover:bg-paper disabled:opacity-40"
                  >
                    <ChevronLeft className="h-3.5 w-3.5" /> Back
                  </button>
                  <button
                    onClick={next}
                    className="flex items-center gap-1 rounded-lg bg-brand-600 px-4 py-2 text-xs font-extrabold uppercase tracking-wide text-white transition hover:bg-brand-500"
                  >
                    {stepIdx === steps.length - 1 ? "Finish" : "Next"}
                    <ChevronRight className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
              <p className="mt-2 text-center text-[10px] font-semibold uppercase tracking-wider text-ink-300">
                Step {stepIdx + 1} of {steps.length} · use ← → keys · Esc to exit
              </p>
            </div>
          </div>
        </div>
      )}
    </TourContext.Provider>
  );
}
