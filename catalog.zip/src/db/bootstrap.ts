import { db } from "@/db";
import { sql } from "drizzle-orm";

/**
 * Idempotent schema bootstrap.
 *
 * Runs on every server start (see src/instrumentation.ts) so the app works in
 * Docker or any fresh environment WITHOUT running drizzle-kit first: every
 * statement is CREATE TABLE IF NOT EXISTS and matches src/db/schema.ts.
 */
const STATEMENTS = [
  `CREATE TABLE IF NOT EXISTS categories (
    id serial PRIMARY KEY,
    slug text NOT NULL UNIQUE,
    name text NOT NULL,
    short_name text NOT NULL,
    tagline text NOT NULL DEFAULT '',
    description text NOT NULL DEFAULT '',
    icon_key text NOT NULL DEFAULT 'ball',
    sort_order integer NOT NULL DEFAULT 0,
    is_active boolean NOT NULL DEFAULT true
  )`,
  `CREATE TABLE IF NOT EXISTS materials (
    id serial PRIMARY KEY,
    code text NOT NULL UNIQUE,
    name text NOT NULL,
    finish text NOT NULL DEFAULT 'Gloss PU',
    description text NOT NULL DEFAULT '',
    texture_url text NOT NULL DEFAULT '',
    price_delta numeric(10,2) NOT NULL DEFAULT '0',
    thickness text NOT NULL DEFAULT '',
    weight_gsm integer,
    is_active boolean NOT NULL DEFAULT true,
    sort_order integer NOT NULL DEFAULT 0
  )`,
  `CREATE TABLE IF NOT EXISTS articles (
    id serial PRIMARY KEY,
    category_id integer NOT NULL REFERENCES categories(id) ON DELETE CASCADE,
    article_no text NOT NULL UNIQUE,
    name text NOT NULL,
    description text NOT NULL DEFAULT '',
    panel_style text NOT NULL DEFAULT 'classic-32',
    panel_count integer NOT NULL DEFAULT 32,
    base_price numeric(10,2) NOT NULL,
    moq integer NOT NULL DEFAULT 300,
    colors jsonb NOT NULL,
    featured boolean NOT NULL DEFAULT false,
    status text NOT NULL DEFAULT 'live',
    artwork_url text,
    design_svg_url text,
    model_url text,
    model_adjust jsonb,
    render_url text,
    seam_style text NOT NULL DEFAULT 'auto',
    layer_images jsonb,
    specs jsonb,
    cdr_upload_id integer,
    default_material_code text,
    created_at timestamp NOT NULL DEFAULT now()
  )`,
  `CREATE TABLE IF NOT EXISTS quotes (
    id serial PRIMARY KEY,
    ref text NOT NULL UNIQUE,
    article_id integer REFERENCES articles(id) ON DELETE SET NULL,
    material_id integer REFERENCES materials(id) ON DELETE SET NULL,
    customer_name text NOT NULL,
    company text NOT NULL DEFAULT '',
    email text NOT NULL,
    quantity integer NOT NULL,
    unit_price numeric(10,2) NOT NULL,
    total numeric(12,2) NOT NULL,
    logo_name text,
    message text NOT NULL DEFAULT '',
    status text NOT NULL DEFAULT 'new',
    created_at timestamp NOT NULL DEFAULT now()
  )`,
  `CREATE TABLE IF NOT EXISTS activity_log (
    id serial PRIMARY KEY,
    event text NOT NULL,
    ref_id text,
    payload jsonb NOT NULL DEFAULT '{}',
    created_at timestamp NOT NULL DEFAULT now()
  )`,
  `CREATE TABLE IF NOT EXISTS uploads (
    id serial PRIMARY KEY,
    original_name text NOT NULL,
    stored_name text NOT NULL UNIQUE,
    kind text NOT NULL DEFAULT 'file',
    size integer NOT NULL DEFAULT 0,
    article_id integer REFERENCES articles(id) ON DELETE SET NULL,
    status text NOT NULL DEFAULT 'received',
    note text NOT NULL DEFAULT '',
    created_at timestamp NOT NULL DEFAULT now()
  )`,
  `CREATE TABLE IF NOT EXISTS compliance_items (
    id serial PRIMARY KEY,
    title text NOT NULL,
    standard text NOT NULL DEFAULT '',
    detail text NOT NULL DEFAULT '',
    status text NOT NULL DEFAULT 'compliant',
    next_review text NOT NULL DEFAULT '',
    sort_order integer NOT NULL DEFAULT 0
  )`,
  `CREATE TABLE IF NOT EXISTS settings (
    key text PRIMARY KEY,
    value jsonb NOT NULL
  )`,
  `CREATE TABLE IF NOT EXISTS messages (
    id serial PRIMARY KEY,
    kind text NOT NULL DEFAULT 'contact',
    ref text,
    name text NOT NULL,
    email text NOT NULL,
    phone text NOT NULL DEFAULT '',
    company text NOT NULL DEFAULT '',
    subject text NOT NULL DEFAULT '',
    body text NOT NULL DEFAULT '',
    article_id integer REFERENCES articles(id) ON DELETE SET NULL,
    article_label text NOT NULL DEFAULT '',
    quote_id integer,
    meta jsonb NOT NULL DEFAULT '{}',
    status text NOT NULL DEFAULT 'new',
    delivered boolean NOT NULL DEFAULT false,
    delivery_note text NOT NULL DEFAULT '',
    created_at timestamp NOT NULL DEFAULT now()
  )`,
];

/**
 * Columns added after the first release. ALTER … ADD COLUMN IF NOT EXISTS keeps
 * already-running databases (e.g. an existing Docker volume) up to date on boot.
 */
const ALTERS = [
  `ALTER TABLE articles ADD COLUMN IF NOT EXISTS model_url text`,
  `ALTER TABLE articles ADD COLUMN IF NOT EXISTS model_adjust jsonb`,
  `ALTER TABLE articles ADD COLUMN IF NOT EXISTS render_url text`,
  `ALTER TABLE articles ADD COLUMN IF NOT EXISTS seam_style text NOT NULL DEFAULT 'auto'`,
  `ALTER TABLE articles ADD COLUMN IF NOT EXISTS layer_images jsonb`,
  `ALTER TABLE articles ADD COLUMN IF NOT EXISTS design_svg_url text`,
  `ALTER TABLE articles ADD COLUMN IF NOT EXISTS specs jsonb`,
  `ALTER TABLE articles ADD COLUMN IF NOT EXISTS default_material_code text`,
];

export async function bootstrapSchema() {
  for (const stmt of STATEMENTS) {
    await db.execute(sql.raw(stmt));
  }
  for (const alter of ALTERS) {
    await db.execute(sql.raw(alter));
  }
}
