export async function register() {
  if (process.env.NEXT_RUNTIME === "nodejs") {
    // 1) Ensure tables exist (idempotent DDL — works in Docker with zero manual steps)
    try {
      const { bootstrapSchema } = await import("@/db/bootstrap");
      await bootstrapSchema();
    } catch (err) {
      console.warn("[bootstrap] skipped:", (err as Error).message?.slice(0, 140));
    }
    // 2) Seed catalog content if empty + enrich missing fields
    try {
      const { ensureSeeded } = await import("@/db/seed");
      await ensureSeeded();
    } catch (err) {
      console.warn("[seed] skipped:", (err as Error).message?.slice(0, 140));
    }
    // 3) Media tree: make sure every project folder exists and pull any file
    //    left in the old flat upload folder into public/media/<folder>
    try {
      const { ensureFolders } = await import("@/lib/media");
      await ensureFolders();
      const { adoptLegacyUploads } = await import("@/lib/mediaAdopt");
      const r = await adoptLegacyUploads();
      if (r.copied) {
        console.log(`[media] adopted ${r.copied} legacy file(s) into public/media — ${r.rewritten} DB row(s) rewritten`);
      }
    } catch (err) {
      console.warn("[media] skipped:", (err as Error).message?.slice(0, 140));
    }
    // 4) Dashboard security: guarantee a strong hashed password exists
    try {
      const { getCredential } = await import("@/lib/adminAuth");
      await getCredential();
    } catch (err) {
      console.warn("[admin-security] skipped:", (err as Error).message?.slice(0, 140));
    }
  }
}
