import { db } from "@/db";
import {
  articles,
  categories,
  compliance,
  materials,
  settings,
  type BallSpecs,
} from "@/db/schema";
import { eq, sql } from "drizzle-orm";

/** Seed data version — bump this whenever the shipped catalog dataset changes.
 *  Existing databases are migrated (old articles replaced) on next boot. */
const SEED_VERSION = "2";

const CATEGORY_SEED = [
  {
    slug: "hand-stitched",
    name: "Hand-Stitched Soccer Balls",
    shortName: "Hand-Stitched",
    tagline: "Hand sewn for strength and durability",
    description:
      "Hand stitched for strength and durability. Enhanced multi-layer architecture, optimized panel construction, constructional latex bladder. Official size and weight.",
    iconKey: "needle",
    sortOrder: 1,
  },
  {
    slug: "machine-stitched",
    name: "Machine-Stitched Soccer Balls",
    shortName: "Machine-Stitched",
    tagline: "Advanced machine stitched football technology",
    description:
      "Advanced machine stitched football technology. Perfectly balanced, superb water resistance, high class thermo polyurethane leather foam backed for ultimate softness. Official size and weight.",
    iconKey: "machine",
    sortOrder: 2,
  },
  {
    slug: "thermal-bonded",
    name: "Thermo-Bonded Soccer Balls",
    shortName: "Thermo Bonded",
    tagline: "Seamless technology, FIFA approved standards",
    description:
      "Seamless technology with extra air mattress system for extreme softness. High quality bladder for increased air retention, controlled sphericity. Official size and weight, FIFA approved standards.",
    iconKey: "flame",
    sortOrder: 3,
  },
  {
    slug: "hybrid",
    name: "Hybrid Soccer Balls",
    shortName: "Hybrid",
    tagline: "Stitch + bond: durability meets softness",
    description:
      "A bonded outer with stitched reinforcement at stress points. Hybrid builds balance match feel with training durability at a competitive price point.",
    iconKey: "hybrid",
    sortOrder: 4,
  },
  {
    slug: "amb-mini",
    name: "AMB / Mini Balls",
    shortName: "AMB / Mini",
    tagline: "Skills, promo and airless mini formats",
    description:
      "Mini and AMB formats from size 1 skills balls to airless promos. Perfect for academies, giveaways and retail impulse lines.",
    iconKey: "mini",
    sortOrder: 5,
  },
  {
    slug: "volleyballs",
    name: "Volleyballs",
    shortName: "Volleyballs",
    tagline: "Indoor and beach panel constructions",
    description:
      "18-panel indoor and beach volleyball constructions with soft-touch laminated covers and low-pressure bladders.",
    iconKey: "volley",
    sortOrder: 6,
  },
  {
    slug: "medicine-balls",
    name: "Medicine Balls",
    shortName: "Medicine Balls",
    tagline: "Weighted training, grip-textured shells",
    description:
      "Weighted training balls from 1–10 kg with anti-burst shells and grip-textured rexine covers for gym and physio use.",
    iconKey: "medicine",
    sortOrder: 7,
  },
];

const MATERIAL_SEED = [
  {
    code: "FS-RX-01",
    name: "Arctic Gloss PU",
    finish: "Gloss PU",
    description:
      "Our signature bright-white gloss PU rexine with fine pebble grain. The default cover for match articles — crisp print surface and classic look.",
    textureUrl: "/textures/rx-arctic-white.jpg",
    priceDelta: "2.50",
    thickness: "1.05 mm",
    weightGsm: 420,
    sortOrder: 1,
  },
  {
    code: "FS-RX-02",
    name: "Lava Pebble TPU",
    finish: "Matte TPU",
    description:
      "Vibrant orange TPU with deep pebble grain. Excellent colour fastness and abrasion resistance for outdoor and beach programmes.",
    textureUrl: "/textures/rx-lava-orange.jpg",
    priceDelta: "3.75",
    thickness: "1.10 mm",
    weightGsm: 445,
    sortOrder: 2,
  },
  {
    code: "FS-RX-03",
    name: "Carbon Weave Rexine",
    finish: "Textured weave",
    description:
      "Black carbon-look woven rexine for premium and limited editions. Distinct visual under floodlights, high scuff resistance.",
    textureUrl: "/textures/rx-carbon-black.jpg",
    priceDelta: "4.20",
    thickness: "1.20 mm",
    weightGsm: 470,
    sortOrder: 3,
  },
  {
    code: "FS-RX-04",
    name: "Crimson Microfiber PU",
    finish: "Gloss PU",
    description:
      "Deep crimson microfiber-backed PU. Softer touch than standard rexine with a wet-look sheen — a favourite for club colours.",
    textureUrl: "/textures/rx-crimson-red.jpg",
    priceDelta: "2.90",
    thickness: "1.05 mm",
    weightGsm: 430,
    sortOrder: 4,
  },
  {
    code: "FS-RX-05",
    name: "Aqua Grip Dimple",
    finish: "Dimple grip",
    description:
      "Teal dimpled grip texture engineered for wet-weather control. The dimple pattern increases surface friction by ~18% in lab tests.",
    textureUrl: "/textures/rx-teal-grip.jpg",
    priceDelta: "3.40",
    thickness: "1.15 mm",
    weightGsm: 455,
    sortOrder: 5,
  },
  {
    code: "FS-RX-06",
    name: "Royal Pearl Metallic",
    finish: "Pearl metallic",
    description:
      "Champagne pearl metallic rexine for trophy and anniversary editions. Pairs beautifully with foil-blocked logos.",
    textureUrl: "/textures/rx-royal-gold.jpg",
    priceDelta: "5.00",
    thickness: "1.10 mm",
    weightGsm: 460,
    sortOrder: 6,
  },
];

/* ------------------------------------------------------------------ *
 * REAL CATALOG DATA — acquired from the previous Forward price list.
 * Sr. 1–15 with exact MOQ and FOB prices. 3D files to be attached
 * per article once available (Admin → Articles → 3D shape).
 * ------------------------------------------------------------------ */

const SPECS_THERMO: BallSpecs = {
  bladder: "Stuffed butyl bladder",
  lining: "Multilayer fabric construction",
  foamMm: 3.5,
  cover: "Seamless thermo-bonded cover",
};
const SPECS_HAND: BallSpecs = {
  bladder: "Constructional latex bladder",
  lining: "Enhanced multi-layer architecture",
  foamMm: 2,
  cover: "Hand-stitched rexine cover",
};
const SPECS_MACHINE: BallSpecs = {
  bladder: "Butyl bladder",
  lining: "Thermo polyurethane foam backing",
  foamMm: 2.5,
  cover: "Machine-stitched TPU leather",
};

const ARTICLE_SEED: Array<{
  categorySlug: string;
  articleNo: string;
  name: string;
  description: string;
  panelStyle: string;
  panelCount: number;
  basePrice: string;
  moq: number;
  colors: { base: string; accent: string; ink: string };
  featured?: boolean;
  specs: BallSpecs;
}> = [
  // ---- THERMO BONDED ----
  {
    categorySlug: "thermal-bonded",
    articleNo: "FS-TB-01",
    name: "FLARE",
    description:
      "FIFA Quality Pro approved (licence 1005140). Seamless thermo-bonded construction with extra air mattress system for extreme softness, high quality bladder for increased air retention and controlled sphericity. Official size and weight.",
    panelStyle: "vortex-18",
    panelCount: 18,
    basePrice: "26.25",
    moq: 500,
    colors: { base: "#f2f0ea", accent: "#b9902f", ink: "#262219" },
    featured: true,
    specs: SPECS_THERMO,
  },
  {
    categorySlug: "thermal-bonded",
    articleNo: "FS-TB-02",
    name: "BLAZE",
    description:
      "Thermo-bonded performance ball with seamless panels, extra air mattress system for extreme softness and controlled sphericity. Official size and weight.",
    panelStyle: "vortex-18",
    panelCount: 18,
    basePrice: "16.47",
    moq: 500,
    colors: { base: "#f4f2ee", accent: "#d2372e", ink: "#221d19" },
    specs: SPECS_THERMO,
  },
  {
    categorySlug: "thermal-bonded",
    articleNo: "FS-TB-03",
    name: "NEO",
    description:
      "Thermo-bonded training-to-match ball. Seamless technology, high quality bladder for increased air retention, official size and weight.",
    panelStyle: "vortex-18",
    panelCount: 18,
    basePrice: "10.30",
    moq: 500,
    colors: { base: "#f4f2ee", accent: "#2456a6", ink: "#1e1b18" },
    specs: SPECS_THERMO,
  },
  {
    categorySlug: "thermal-bonded",
    articleNo: "FS-TB-04",
    name: "FUTSAL MATCH UP",
    description:
      "Indoor thermal bonded futsal ball. Multilayer fabric construction, stuffed butyl bladder, perfectly balanced. Official size and weight, low-bounce futsal specification.",
    panelStyle: "vortex-18",
    panelCount: 18,
    basePrice: "9.84",
    moq: 500,
    colors: { base: "#f1eee9", accent: "#8e2f57", ink: "#241f22" },
    specs: SPECS_THERMO,
  },
  // ---- HAND STITCH ----
  {
    categorySlug: "hand-stitched",
    articleNo: "FS-HS-05",
    name: "MUNDIALE",
    description:
      "Hand stitched for strength and durability. Enhanced multi-layer architecture, optimized panel construction, constructional latex bladder. Official size and weight.",
    panelStyle: "vortex-18",
    panelCount: 32,
    basePrice: "11.50",
    moq: 500,
    colors: { base: "#f5f2ee", accent: "#d84f8e", ink: "#232024" },
    featured: true,
    specs: SPECS_HAND,
  },
  {
    categorySlug: "hand-stitched",
    articleNo: "FS-HS-06",
    name: "MATCH",
    description:
      "Classic hand-stitched match ball. Multi-layer architecture with optimized panel construction and latex bladder. Official size and weight.",
    panelStyle: "classic-32",
    panelCount: 32,
    basePrice: "6.49",
    moq: 500,
    colors: { base: "#f4f1ea", accent: "#1f7a4d", ink: "#20211c" },
    specs: SPECS_HAND,
  },
  {
    categorySlug: "hand-stitched",
    articleNo: "FS-HS-07",
    name: "FUTSAL PRO",
    description:
      "Hand-stitched futsal ball with controlled rebound, multi-layer architecture and latex bladder. Official futsal size and weight.",
    panelStyle: "classic-32",
    panelCount: 32,
    basePrice: "12.00",
    moq: 500,
    colors: { base: "#f3f1ea", accent: "#2456a6", ink: "#1f1d1a" },
    specs: SPECS_HAND,
  },
  {
    categorySlug: "hand-stitched",
    articleNo: "FS-HS-08",
    name: "FUTSAL TRAINING",
    description:
      "Hand-stitched futsal training ball built for daily academy sessions. Durable seams, latex bladder, official size and weight.",
    panelStyle: "vortex-18",
    panelCount: 32,
    basePrice: "7.70",
    moq: 500,
    colors: { base: "#f3f2e2", accent: "#d8dc4a", ink: "#3a3a20" },
    specs: SPECS_HAND,
  },
  {
    categorySlug: "hand-stitched",
    articleNo: "FS-HS-09",
    name: "HAND BALL",
    description:
      "Hand-stitched team handball with grip-friendly rexine cover, multi-layer architecture and latex bladder. Official size and weight.",
    panelStyle: "vortex-18",
    panelCount: 32,
    basePrice: "8.67",
    moq: 1000,
    colors: { base: "#2e8fa3", accent: "#14505e", ink: "#0e333c" },
    specs: SPECS_HAND,
  },
  // ---- MACHINE STITCH ----
  {
    categorySlug: "machine-stitched",
    articleNo: "FS-MS-10",
    name: "HFT",
    description:
      "Advanced machine stitched football technology. Perfectly balanced, superb water resistance, high class thermo polyurethane leather foam backed for ultimate softness. Official size and weight.",
    panelStyle: "vortex-18",
    panelCount: 32,
    basePrice: "6.45",
    moq: 1000,
    colors: { base: "#f4f3ee", accent: "#2f9e44", ink: "#21241e" },
    featured: true,
    specs: SPECS_MACHINE,
  },
  {
    categorySlug: "machine-stitched",
    articleNo: "FS-MS-11",
    name: "RIHNO",
    description:
      "Machine stitched training ball with geometric panel design. Perfectly balanced, water resistant TPU leather, foam backed for softness. Official size and weight.",
    panelStyle: "geo-24",
    panelCount: 24,
    basePrice: "3.85",
    moq: 1000,
    colors: { base: "#f2f0ea", accent: "#7a2742", ink: "#221d20" },
    specs: SPECS_MACHINE,
  },
  {
    categorySlug: "machine-stitched",
    articleNo: "FS-MS-12",
    name: "STRIKER",
    description:
      "Machine stitched club ball in high-contrast graphics. Balanced, water resistant, foam-backed TPU leather. Official size and weight.",
    panelStyle: "geo-24",
    panelCount: 24,
    basePrice: "3.50",
    moq: 1000,
    colors: { base: "#f4f4f2", accent: "#17181c", ink: "#101114" },
    specs: SPECS_MACHINE,
  },
  {
    categorySlug: "amb-mini",
    articleNo: "FS-MB-13",
    name: "MINI BALL",
    description:
      "Machine stitched mini ball for skills work, promos and retail. Foam-backed cover, official mini size and weight.",
    panelStyle: "mini-star",
    panelCount: 12,
    basePrice: "2.90",
    moq: 1000,
    colors: { base: "#f6f4ef", accent: "#cb2431", ink: "#241f1f" },
    specs: SPECS_MACHINE,
  },
  {
    categorySlug: "volleyballs",
    articleNo: "FS-VB-14",
    name: "VOLLEY BALL",
    description:
      "Machine stitched volleyball with soft foam-backed cover and balanced flight. Official size and weight.",
    panelStyle: "volley-18",
    panelCount: 18,
    basePrice: "4.15",
    moq: 1000,
    colors: { base: "#f5f3ec", accent: "#e8590c", ink: "#2b2118" },
    specs: SPECS_MACHINE,
  },
  {
    categorySlug: "machine-stitched",
    articleNo: "FS-MS-15",
    name: "DIGITAL PRINTED",
    description:
      "Full digital printed cover on a machine stitched construction — unlimited custom graphics, perfect for promotions and club programmes. Official size and weight.",
    panelStyle: "geo-24",
    panelCount: 24,
    basePrice: "4.05",
    moq: 1000,
    colors: { base: "#d94f30", accent: "#f2b234", ink: "#40210f" },
    specs: SPECS_MACHINE,
  },
];

const COMPLIANCE_SEED = [
  {
    title: "FIFA Quality — Size 5 match parameters",
    standard: "FIFA Quality Programme",
    detail:
      "Circumference 68.5–69.5 cm · weight 410–450 g · rebound 110–160 cm · water uptake ≤ 10%. FLARE carries FIFA Quality Pro licence 1005140. Batch-tested every production run.",
    status: "compliant",
    nextReview: "2026-11-30",
    sortOrder: 1,
  },
  {
    title: "REACH — restricted substances in cover materials",
    standard: "EU REACH SVHC",
    detail:
      "All rexine and PU cover stocks screened for SVHC candidates, phthalates and azo dyes. Mill certificates archived per lot.",
    status: "compliant",
    nextReview: "2026-09-30",
    sortOrder: 2,
  },
  {
    title: "ISO 9001:2015 — quality management",
    standard: "ISO 9001",
    detail: "Annual surveillance audit across cutting, printing, stitching, bonding and packing lines.",
    status: "compliant",
    nextReview: "2027-02-28",
    sortOrder: 3,
  },
  {
    title: "Child labour & social compliance",
    standard: "SA8000 / Adidas CoC",
    detail: "No child labour across the supply chain; third-party social audits twice per year.",
    status: "compliant",
    nextReview: "2026-12-15",
    sortOrder: 4,
  },
  {
    title: "California Prop 65 — printed inks",
    standard: "CA Prop 65",
    detail: "Heavy-metal limits on screen and digital inks for US-bound retail programmes.",
    status: "in-progress",
    nextReview: "2026-08-31",
    sortOrder: 5,
  },
  {
    title: "Toy safety for mini / promo balls",
    standard: "EN 71-1/2/3",
    detail: "Mini and keychain formats classified as toys in the EU — mechanical and migration testing required.",
    status: "compliant",
    nextReview: "2026-10-31",
    sortOrder: 6,
  },
];

const HERO_PRESETS_V2 = [
  { label: "FLARE · FIFA Approved", articleNo: "FS-TB-01", materialCode: "FS-RX-01" },
  { label: "BLAZE", articleNo: "FS-TB-02", materialCode: "FS-RX-04" },
  { label: "STRIKER", articleNo: "FS-MS-12", materialCode: "FS-RX-03" },
];

const SETTINGS_SEED: Array<[string, unknown]> = [
  [
    "company",
    {
      name: "Forward Sports (Pvt) Ltd",
      city: "Sialkot, Pakistan",
      site: "forward.pk",
      tagline: "The Soccer Expert",
    },
  ],
  ["currency", { code: "USD", symbol: "$" }],
  ["defaultMoq", 500],
  ["leadTime", "4–6 weeks from artwork approval"],
  ["salesEmail", "sales@forward.pk"],
  [
    "quoteTiers",
    [
      { minQty: 1000, discountPct: 4 },
      { minQty: 5000, discountPct: 7 },
      { minQty: 10000, discountPct: 10 },
    ],
  ],
  ["heroPresets", HERO_PRESETS_V2],
  ["seedVersion", SEED_VERSION],
];

async function upsertSetting(key: string, value: unknown) {
  await db
    .insert(settings)
    .values({ key, value: value as never })
    .onConflictDoUpdate({ target: settings.key, set: { value: value as never } });
}

async function insertArticles(catBySlug: Map<string, number>) {
  await db.insert(articles).values(
    ARTICLE_SEED.map((a) => ({
      categoryId: catBySlug.get(a.categorySlug)!,
      articleNo: a.articleNo,
      name: a.name,
      description: a.description,
      panelStyle: a.panelStyle,
      panelCount: a.panelCount,
      basePrice: a.basePrice,
      moq: a.moq,
      colors: a.colors,
      featured: a.featured ?? false,
      specs: a.specs,
      seamStyle:
        a.categorySlug === "hand-stitched"
          ? "hand"
          : a.categorySlug === "machine-stitched"
            ? "machine"
            : a.categorySlug === "thermal-bonded"
              ? "bonded"
              : "auto",
    }))
  );
}

export async function ensureSeeded() {
  const result = await db.execute(sql`select count(*)::int as n from categories`);
  const rows =
    (result as unknown as { rows?: Array<{ n: number }> }).rows ??
    (result as unknown as Array<{ n: number }>);
  const n = Number(rows?.[0]?.n ?? 0);

  if (n === 0) {
    const catRows = await db
      .insert(categories)
      .values(CATEGORY_SEED)
      .returning({ id: categories.id, slug: categories.slug });
    const catBySlug = new Map(catRows.map((c) => [c.slug, c.id]));
    await db.insert(materials).values(MATERIAL_SEED);
    await insertArticles(catBySlug);
    await db.insert(compliance).values(COMPLIANCE_SEED);
  } else {
    // Versioned migration: replace outdated demo articles with the real catalog
    const verRow = await db.select().from(settings).where(eq(settings.key, "seedVersion"));
    const current = typeof verRow[0]?.value === "string" ? verRow[0].value : null;
    if (current !== SEED_VERSION) {
      const cats = await db.select().from(categories);
      const catBySlug = new Map(cats.map((c) => [c.slug, c.id]));
      await db.delete(articles);
      await insertArticles(catBySlug);
      // refresh section copy so it matches the acquired catalog wording
      for (const c of CATEGORY_SEED) {
        const id = catBySlug.get(c.slug);
        if (id) {
          await db
            .update(categories)
            .set({ tagline: c.tagline, description: c.description })
            .where(eq(categories.id, id));
        }
      }
      await upsertSetting("heroPresets", HERO_PRESETS_V2);
      await upsertSetting("seedVersion", SEED_VERSION);
    }
  }

  for (const [key, value] of SETTINGS_SEED) {
    await db
      .insert(settings)
      .values({ key, value: value as never })
      .onConflictDoNothing({ target: settings.key });
  }
}
