import Link from "next/link";
import { BadgeCheck, Mail, MapPin, Phone } from "lucide-react";
import { getContent } from "@/lib/content";

const CATEGORIES = [
  { slug: "hand-stitched", name: "Hand-Stitched" },
  { slug: "machine-stitched", name: "Machine-Stitched" },
  { slug: "thermal-bonded", name: "Thermal-Bonded" },
  { slug: "hybrid", name: "Hybrid" },
  { slug: "amb-mini", name: "AMB / Mini Balls" },
  { slug: "volleyballs", name: "Volleyballs" },
  { slug: "medicine-balls", name: "Medicine Balls" },
];

const BADGES = ["FIFA Quality", "ISO 9001", "REACH", "SA8000", "EN 71"];

export default async function Footer() {
  const c = await getContent();
  return (
    <footer className="bg-ink-950 text-white/70">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-14 sm:px-6 md:grid-cols-2 lg:grid-cols-4">
        <div>
          <div className="flex items-center gap-3">
            <span className="grid h-9 w-9 place-items-center rounded-md bg-brand-600 font-display text-lg font-black text-white">
              F
            </span>
            <span className="font-display text-sm font-black uppercase tracking-[0.16em] text-white">
              Forward Sports
            </span>
          </div>
          <p className="mt-4 max-w-xs text-sm leading-relaxed">{c["footer.about"]}</p>
          <p className="mt-4 flex items-start gap-2 text-xs">
            <MapPin className="mt-0.5 h-3.5 w-3.5 shrink-0 text-brand-400" />
            {c["footer.address"]}
          </p>
        </div>

        <div>
          <h4 className="font-display text-xs font-extrabold uppercase tracking-[0.22em] text-white">Constructions</h4>
          <ul className="mt-4 space-y-2.5 text-sm">
            {CATEGORIES.map((cat) => (
              <li key={cat.slug}>
                <Link href={`/catalog#${cat.slug}`} className="transition hover:text-brand-400">
                  {cat.name}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h4 className="font-display text-xs font-extrabold uppercase tracking-[0.22em] text-white">Compliance</h4>
          <div className="mt-4 flex flex-wrap gap-2">
            {BADGES.map((b) => (
              <span
                key={b}
                className="inline-flex items-center gap-1.5 rounded-md border border-white/15 px-2.5 py-1.5 text-xs font-semibold"
              >
                <BadgeCheck className="h-3.5 w-3.5 text-brand-400" />
                {b}
              </span>
            ))}
          </div>
          <p className="mt-5 text-xs leading-relaxed text-white/50">{c["footer.complianceNote"]}</p>
        </div>

        <div>
          <h4 className="font-display text-xs font-extrabold uppercase tracking-[0.22em] text-white">Contact</h4>
          <ul className="mt-4 space-y-3 text-sm">
            <li className="flex items-center gap-2.5">
              <Mail className="h-4 w-4 text-brand-400" />
              <a href={`mailto:${c["footer.email"]}`} className="hover:text-brand-400">
                {c["footer.email"]}
              </a>
            </li>
            <li className="flex items-center gap-2.5">
              <Phone className="h-4 w-4 text-brand-400" />
              {c["footer.phone"]}
            </li>
            <li className="text-xs text-white/50">{c["footer.hours"]}</li>
          </ul>
          <Link
            href="/catalog"
            className="mt-6 inline-block rounded-lg bg-brand-600 px-5 py-2.5 font-display text-xs font-extrabold uppercase tracking-widest text-white transition hover:bg-brand-500"
          >
            {c["home.ctaPrimary"]}
          </Link>
        </div>
      </div>

      <div className="border-t border-white/10">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-2 px-4 py-5 text-xs text-white/45 sm:flex-row sm:px-6">
          <p>{c["footer.copyright"]}</p>
          <p>
            {c["footer.craftLine"]} ·{" "}
            <a href="https://forward.pk" className="underline-offset-2 hover:text-brand-400 hover:underline">
              forward.pk
            </a>
          </p>
        </div>
      </div>
    </footer>
  );
}
