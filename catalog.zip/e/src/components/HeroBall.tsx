"use client";

import dynamic from "next/dynamic";
import { useState } from "react";
import { Layers, Minimize2 } from "lucide-react";
import SafeBoundary from "@/components/SafeBoundary";
import type { BallColors, BallSpecs, LayerImages } from "@/db/schema";
import type { LayerKey } from "@/components/BallViewer";
import { cn } from "@/lib/utils";

const BallViewer = dynamic(() => import("@/components/BallViewer"), { ssr: false });

export type HeroPresetData = {
  label: string;
  articleNo: string;
  panelStyle: string;
  colors: BallColors;
  artworkUrl: string | null;
  designSvgUrl: string | null;
  modelUrl: string | null;
  renderUrl: string | null;
  seamStyle: string;
  specs: BallSpecs | null;
  layerImages: LayerImages | null;
  rexineUrl: string | null;
  rexineName: string;
  rexineThickness: string;
};

const FALLBACK: HeroPresetData[] = [
  {
    label: "Match White",
    articleNo: "FS-HS-3202",
    panelStyle: "classic-32",
    colors: { base: "#f4f2ec", accent: "#cb0000", ink: "#26221f" },
    artworkUrl: null,
    designSvgUrl: null,
    modelUrl: null,
    renderUrl: null,
    seamStyle: "hand",
    specs: null,
    layerImages: null,
    rexineUrl: "/textures/rx-arctic-white.jpg",
    rexineName: "Arctic Gloss PU",
    rexineThickness: "1.05 mm",
  },
];

export default function HeroBall({ presets }: { presets?: HeroPresetData[] }) {
  const list = presets && presets.length > 0 ? presets : FALLBACK;
  const [idx, setIdx] = useState(0);
  const [exploded, setExploded] = useState(false);
  const [focus, setFocus] = useState<LayerKey | null>(null);
  const p = list[Math.min(idx, list.length - 1)];

  const specs: BallSpecs = p.specs ?? {
    bladder: "Butyl valve bladder",
    lining: "Cotton-poly winding",
    foamMm: 2,
  };

  const layers: Array<{ key: LayerKey; name: string; detail: string; badge: string }> = [
    {
      key: "cover",
      name: "Rexine cover",
      detail: `${p.rexineName} · ${p.rexineThickness || "1.05 mm"}`,
      badge: p.rexineThickness || "1.05 mm",
    },
    { key: "foam", name: "Impact foam", detail: `${specs.foamMm} mm EVA cushion`, badge: `${specs.foamMm} mm` },
    { key: "lining", name: "Fabric lining", detail: specs.lining, badge: "lining" },
    { key: "bladder", name: "Bladder", detail: specs.bladder, badge: "core" },
  ];

  return (
    <div className="relative">
      <div className="blueprint-grid relative h-[340px] overflow-hidden rounded-2xl border border-ink-800 bg-ink-950 sm:h-[430px]">
        <SafeBoundary label="hero" height="100%">
        <BallViewer
          className="h-full w-full"
          panelStyle={p.panelStyle}
          colors={p.colors}
          rexineUrl={p.rexineUrl}
          artworkUrl={p.artworkUrl}
          designSvgUrl={p.designSvgUrl}
          modelUrl={p.modelUrl}
          renderUrl={p.renderUrl}
          layerImages={p.layerImages}
          seamStyle={p.seamStyle}
          label={p.articleNo}
          roughness={0.42}
          autoRotate
          exploded={exploded}
          specs={specs}
          focusLayer={focus}
          layerNames={Object.fromEntries(layers.map((l) => [l.key, { name: l.name, detail: l.detail }]))}
        />
        </SafeBoundary>
        <span className="pointer-events-none absolute left-4 top-4 rounded-md bg-black/55 px-2.5 py-1 font-display text-[11px] font-extrabold uppercase tracking-widest text-white/80 backdrop-blur">
          {exploded ? `${p.label} · construction` : `${p.label} · live 3D`}
        </span>
        <div className="absolute bottom-4 left-4 flex gap-2">
          <button
            onClick={() => setExploded((v) => !v)}
            className={cn(
              "flex h-9 items-center gap-1.5 rounded-lg px-3 text-xs font-bold backdrop-blur transition",
              exploded ? "bg-brand-600 text-white" : "bg-white/15 text-white hover:bg-brand-600"
            )}
          >
            <Layers className="h-4 w-4" />
            {exploded ? "Assemble ball" : "Look inside"}
          </button>
          {exploded && (
            <button
              onClick={() => setExploded(false)}
              className="flex h-9 items-center gap-1.5 rounded-lg bg-white/15 px-3 text-xs font-bold text-white backdrop-blur hover:bg-white/25"
            >
              <Minimize2 className="h-4 w-4" />
            </button>
          )}
        </div>
        <span className="pointer-events-none absolute bottom-4 right-4 hidden rounded-md bg-black/45 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-wider text-white/60 backdrop-blur sm:block">
          {exploded ? "Hover a layer to isolate" : "Drag to rotate · Scroll to zoom"}
        </span>
      </div>

      {/* Exploded layer cards */}
      {exploded && (
        <div className="mt-3 grid gap-2 sm:grid-cols-2">
          {layers.map((l) => (
            <div
              key={l.key}
              onMouseEnter={() => setFocus(l.key)}
              onMouseLeave={() => setFocus(null)}
              className={cn(
                "flex items-center justify-between gap-2 rounded-lg border bg-white/5 px-3 py-2 backdrop-blur transition",
                focus === l.key ? "border-brand-500 bg-brand-600/20" : "border-white/15"
              )}
            >
              <div className="min-w-0">
                <p className="text-[11px] font-extrabold uppercase tracking-wide text-white">{l.name}</p>
                <p className="truncate text-[11px] text-white/60">{l.detail}</p>
              </div>
              <span className="shrink-0 rounded bg-black/40 px-1.5 py-0.5 font-display text-[10px] font-black text-brand-400">
                {l.badge}
              </span>
            </div>
          ))}
        </div>
      )}

      {/* Sample chips — editable in Admin → Front page */}
      <div className="mt-3 flex flex-wrap items-center gap-2">
        {list.map((pr, i) => (
          <button
            key={`${pr.label}-${i}`}
            onClick={() => {
              setIdx(i);
              setExploded(false);
              setFocus(null);
            }}
            className={
              i === idx
                ? "rounded-lg bg-brand-600 px-3 py-1.5 text-[11px] font-extrabold uppercase tracking-wider text-white"
                : "rounded-lg border border-white/20 bg-white/5 px-3 py-1.5 text-[11px] font-bold uppercase tracking-wider text-white/70 hover:border-brand-400 hover:text-white"
            }
          >
            {pr.label}
          </button>
        ))}
        <span className="hidden text-[10px] font-semibold uppercase tracking-wider text-white/35 sm:block">
          {p.articleNo}
        </span>
      </div>
    </div>
  );
}
