"use client";

import { Component, type ErrorInfo, type ReactNode } from "react";

/**
 * Keeps a failing 3D/canvas subtree from taking the whole page down.
 * If WebGL is unavailable or the GPU process drops, users see a calm
 * fallback card instead of a blank/crashed page.
 */
export default class SafeBoundary extends Component<
  { children: ReactNode; label?: string; height?: string },
  { failed: boolean }
> {
  state = { failed: false };

  static getDerivedStateFromError() {
    return { failed: true };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    console.warn("[SafeBoundary]", this.props.label ?? "viewer", error.message, info.componentStack);
  }

  render() {
    if (this.state.failed) {
      return (
        <div
          className="grid place-items-center rounded-xl border border-line bg-card p-6 text-center"
          style={{ minHeight: this.props.height ?? "260px" }}
        >
          <div>
            <p className="font-display text-sm font-extrabold uppercase tracking-widest text-ink-700">
              3D preview unavailable
            </p>
            <p className="mt-2 max-w-xs text-xs leading-relaxed text-ink-500">
              Your browser or device blocked WebGL for this view. Everything else — prices, materials,
              quotes — works normally. Try a different browser or enable hardware acceleration.
            </p>
            <button
              onClick={() => this.setState({ failed: false })}
              className="mt-4 rounded-lg border border-line px-4 py-2 text-xs font-bold text-ink-700 hover:bg-paper"
            >
              Try again
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}
