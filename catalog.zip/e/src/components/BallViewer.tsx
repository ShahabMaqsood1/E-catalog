"use client";

import { Suspense, useEffect, useMemo, useRef, useState } from "react";
import * as THREE from "three";
import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader.js";
import { STLLoader } from "three/examples/jsm/loaders/STLLoader.js";
import { OBJLoader } from "three/examples/jsm/loaders/OBJLoader.js";
import { Canvas, useFrame, useThree, type ThreeEvent } from "@react-three/fiber";
import { Html, OrbitControls } from "@react-three/drei";
import { buildBallCanvas, type BallTextureMeta, type BallTextureOptions } from "@/lib/ballTexture";
import {
  DEFAULT_MODEL_ADJUST,
  type BallColors,
  type BallSpecs,
  type LayerImages,
  type LogoTransform,
  type ModelAdjust,
  type SeamStyle,
} from "@/db/schema";

export type LayerKey = "cover" | "foam" | "lining" | "bladder";
export type LayerLabel = { name: string; detail: string };

export type BallViewerProps = {
  panelStyle: string;
  colors: BallColors;
  rexineUrl?: string | null;
  artworkUrl?: string | null;
  designSvgUrl?: string | null;
  modelUrl?: string | null;
  modelAdjust?: ModelAdjust | null;
  renderUrl?: string | null;
  layerImages?: LayerImages | null;
  seamStyle?: SeamStyle | string | null;
  logoUrl?: string | null;
  logo?: LogoTransform | null;
  logoDraggable?: boolean;
  onLogoMove?: (pos: { u: number; v: number }) => void;
  label?: string;
  roughness?: number;
  autoRotate?: boolean;
  closeUp?: boolean;
  exploded?: boolean;
  specs?: BallSpecs | null;
  layerNames?: Partial<Record<LayerKey, LayerLabel>>;
  focusLayer?: LayerKey | null;
  onMeta?: (meta: BallTextureMeta) => void;
  className?: string;
};

const EXPLODE_OFFSET: Record<LayerKey, number> = {
  cover: 0.95,
  foam: 0.35,
  lining: -0.25,
  bladder: -0.78,
};

const extOf = (url: string) => url.split("?")[0].split("#")[0].split(".").pop()?.toLowerCase() ?? "";

/* ---------------- safe async loaders ---------------- */

function useSafeTexture(url?: string | null) {
  const [tex, setTex] = useState<THREE.Texture | null>(null);
  useEffect(() => {
    if (!url) {
      setTex(null);
      return;
    }
    let live = true;
    new THREE.TextureLoader().load(
      url,
      (t) => {
        if (!live) return;
        t.colorSpace = THREE.SRGBColorSpace;
        t.wrapS = t.wrapT = THREE.RepeatWrapping;
        setTex(t);
      },
      undefined,
      () => live && setTex(null)
    );
    return () => {
      live = false;
    };
  }, [url]);
  return tex;
}

/** STL files carry no UVs — generate equirectangular (spherical) ones so the
 *  ball wrap maps onto them. The u-seam is placed at the back of the ball. */
function applySphericalUVs(geom: THREE.BufferGeometry) {
  geom.computeBoundingBox();
  const box = geom.boundingBox ?? new THREE.Box3().setFromObject(new THREE.Mesh(geom));
  const centre = new THREE.Vector3();
  const size = new THREE.Vector3();
  box.getCenter(centre);
  box.getSize(size);
  const r = Math.max(size.x, size.y, size.z) / 2 || 1;
  const pos = geom.attributes.position as THREE.BufferAttribute;
  const uvs = new Float32Array(pos.count * 2);
  const p = new THREE.Vector3();
  for (let i = 0; i < pos.count; i++) {
    p.fromBufferAttribute(pos, i).sub(centre).divideScalar(r);
    uvs[i * 2] = 0.5 + Math.atan2(p.z, p.x) / (Math.PI * 2);
    uvs[i * 2 + 1] = 0.5 - Math.asin(THREE.MathUtils.clamp(p.y, -1, 1)) / Math.PI;
  }
  geom.setAttribute("uv", new THREE.BufferAttribute(uvs, 2));
  geom.computeVertexNormals();
}

function normalise(object: THREE.Object3D) {
  const box = new THREE.Box3().setFromObject(object);
  const size = new THREE.Vector3();
  const centre = new THREE.Vector3();
  box.getSize(size);
  box.getCenter(centre);
  const maxDim = Math.max(size.x, size.y, size.z) || 1;
  object.position.sub(centre);
  const wrapper = new THREE.Group();
  wrapper.add(object);
  wrapper.scale.setScalar(2 / maxDim);
  return wrapper;
}

/** Loads .glb / .gltf / .stl / .obj and always returns something renderable (or null) */
function useUploadedModel(url?: string | null) {
  const [object, setObject] = useState<THREE.Object3D | null>(null);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    if (!url) {
      setObject(null);
      setFailed(false);
      return;
    }
    let live = true;
    const ext = extOf(url);
    const done = (obj: THREE.Object3D) => live && setObject(normalise(obj));
    const fail = () => {
      if (!live) return;
      setObject(null);
      setFailed(true);
    };

    const guard = (root: THREE.Object3D): boolean => {
      // Safety net: never put a monster mesh into the GPU — fall back instead
      let tris = 0;
      root.traverse((o) => {
        const mesh = o as THREE.Mesh;
        if (mesh.isMesh && mesh.geometry) {
          const g = mesh.geometry as THREE.BufferGeometry;
          tris += (g.index ? g.index.count : g.attributes.position?.count ?? 0) / 3;
        }
      });
      if (tris > 900_000) {
        console.warn(`[BallViewer] model has ${Math.round(tris)} triangles — too heavy, using fallback ball`);
        return false;
      }
      return true;
    };

    if (ext === "stl") {
      new STLLoader().load(
        url,
        (geom) => {
          if (geom.index ? geom.index.count / 3 > 900_000 : geom.attributes.position.count / 3 > 900_000) {
            fail();
            return;
          }
          applySphericalUVs(geom);
          done(new THREE.Mesh(geom));
        },
        undefined,
        fail
      );
    } else if (ext === "obj") {
      new OBJLoader().load(
        url,
        (group) => {
          if (guard(group)) done(group);
          else fail();
        },
        undefined,
        fail
      );
    } else {
      new GLTFLoader().load(
        url,
        (gltf) => {
          if (guard(gltf.scene)) done(gltf.scene);
          else fail();
        },
        undefined,
        fail
      );
    }
    return () => {
      live = false;
    };
  }, [url]);

  return { object, failed };
}

/* ---------------- camera ---------------- */

function CameraRig({ closeUp, exploded }: { closeUp: boolean; exploded: boolean }) {
  const { camera } = useThree();
  const anim = useRef({ until: 0, target: 3.3, key: "" });
  const key = `${exploded}|${closeUp}`;
  useEffect(() => {
    if (anim.current.key !== key) {
      anim.current.key = key;
      anim.current.target = exploded ? 4.9 : closeUp ? 1.7 : 3.3;
      anim.current.until = performance.now() + 1200;
    }
  }, [key, exploded, closeUp]);
  useFrame((_, delta) => {
    if (performance.now() > anim.current.until) return;
    const len = camera.position.length();
    camera.position.setLength(THREE.MathUtils.damp(len, anim.current.target, 5, delta));
  });
  return null;
}

/* ---------------- texture + drag ---------------- */

function useBallTexture(canvas: HTMLCanvasElement | null, adjust?: ModelAdjust | null) {
  const texture = useMemo(() => {
    if (!canvas) return null;
    const t = new THREE.CanvasTexture(canvas);
    t.colorSpace = THREE.SRGBColorSpace;
    t.anisotropy = 8;
    t.wrapS = t.wrapT = THREE.RepeatWrapping;
    return t;
  }, [canvas]);

  const a = { ...DEFAULT_MODEL_ADJUST, ...(adjust ?? {}) };
  useEffect(() => {
    if (!texture) return;
    const s = THREE.MathUtils.clamp(a.scale || 1, 0.4, 2.5);
    texture.repeat.set(1 / s, 1 / s);
    texture.offset.set(a.offsetX || 0, a.offsetY || 0);
    texture.needsUpdate = true;
  }, [texture, a.scale, a.offsetX, a.offsetY]);

  useEffect(() => () => texture?.dispose(), [texture]);
  return texture;
}

/** Lets the buyer drag their logo across the ball; converts the hit point to wrap UVs */
function useLogoDrag(enabled: boolean, onMove?: (p: { u: number; v: number }) => void) {
  const controls = useThree((s) => s.controls) as unknown as { enabled: boolean } | null;
  const dragging = useRef(false);
  const last = useRef(0);

  useEffect(() => {
    if (!enabled) return;
    const up = () => {
      dragging.current = false;
      if (controls) controls.enabled = true;
      document.body.style.cursor = "";
    };
    window.addEventListener("pointerup", up);
    return () => window.removeEventListener("pointerup", up);
  }, [enabled, controls]);

  return {
    onPointerDown: (e: ThreeEvent<PointerEvent>) => {
      if (!enabled) return;
      e.stopPropagation();
      dragging.current = true;
      if (controls) controls.enabled = false;
      document.body.style.cursor = "grabbing";
    },
    onPointerMove: (e: ThreeEvent<PointerEvent>) => {
      if (!enabled || !dragging.current || !e.uv) return;
      const now = performance.now();
      if (now - last.current < 45) return; // throttle canvas rebuilds
      last.current = now;
      onMove?.({ u: e.uv.x, v: 1 - e.uv.y });
    },
  };
}

function coverMaterialProps(texture: THREE.Texture | null, roughness: number, opacity: number) {
  return texture
    ? {
        map: texture,
        bumpMap: texture,
        bumpScale: 1.1,
        roughness,
        clearcoat: 0.55,
        clearcoatRoughness: 0.4,
        transparent: opacity < 1,
        opacity,
      }
    : { color: "#d9d5cb", roughness: 0.6, transparent: opacity < 1, opacity };
}

/* ---------------- assembled views ---------------- */

function Ball({
  canvas,
  roughness,
  drag,
  logoDraggable,
  rotY,
}: {
  canvas: HTMLCanvasElement | null;
  roughness: number;
  drag: ReturnType<typeof useLogoDrag>;
  logoDraggable: boolean;
  rotY: number;
}) {
  const texture = useBallTexture(canvas);
  return (
    <mesh rotation={[0, -Math.PI / 2 + rotY, 0]} {...drag}>
      <sphereGeometry args={[1, 64, 64]} />
      <meshPhysicalMaterial side={THREE.FrontSide} {...coverMaterialProps(texture, roughness, 1)} />
    </mesh>
  );
}

/** Designer-supplied 3D model (.glb/.gltf/.obj/.stl) re-skinned with the live rexine */
function ModelBall({
  url,
  canvas,
  roughness,
  adjust,
  drag,
}: {
  url: string;
  canvas: HTMLCanvasElement | null;
  roughness: number;
  adjust?: ModelAdjust | null;
  drag: ReturnType<typeof useLogoDrag>;
}) {
  const { object, failed } = useUploadedModel(url);
  const texture = useBallTexture(canvas, adjust);
  const applied = useRef<THREE.Material[]>([]);
  const rotY = ((adjust?.rotY ?? 0) * Math.PI) / 180;

  useEffect(() => {
    if (!object) return;
    const mat = texture
      ? new THREE.MeshPhysicalMaterial({
          map: texture,
          bumpMap: texture,
          bumpScale: 0.9,
          roughness,
          clearcoat: 0.5,
          clearcoatRoughness: 0.45,
        })
      : new THREE.MeshStandardMaterial({ color: "#d9d5cb", roughness: 0.6 });
    applied.current.forEach((m) => m.dispose());
    applied.current = [mat];
    object.traverse((o) => {
      const mesh = o as THREE.Mesh;
      if (mesh.isMesh) {
        // OBJ/STL may lack UVs for some meshes — keep the spherical ones we generated
        mesh.material = mat;
      }
    });
    return () => {
      applied.current.forEach((m) => m.dispose());
      applied.current = [];
    };
  }, [object, texture, roughness]);

  if (failed || !object) {
    return <Ball canvas={canvas} roughness={roughness} drag={drag} logoDraggable={false} rotY={rotY} />;
  }
  return (
    <group rotation={[0, -Math.PI / 2 + rotY, 0]} {...drag}>
      <primitive object={object} />
    </group>
  );
}

/* ---------------- exploded "look inside" ---------------- */

function makeWovenTexture() {
  const c = document.createElement("canvas");
  c.width = 96;
  c.height = 96;
  const x = c.getContext("2d");
  if (x) {
    x.fillStyle = "#cdbc9d";
    x.fillRect(0, 0, 96, 96);
    x.strokeStyle = "rgba(94,80,58,0.5)";
    x.lineWidth = 2;
    for (let i = 0; i <= 96; i += 8) {
      x.beginPath();
      x.moveTo(i, 0);
      x.lineTo(i, 96);
      x.stroke();
      x.beginPath();
      x.moveTo(0, i);
      x.lineTo(96, i);
      x.stroke();
    }
  }
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.repeat.set(16, 8);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

const wedgeArgs = (r: number): [number, number, number, number, number] => [
  r,
  64,
  64,
  Math.PI * 0.75,
  Math.PI * 1.5,
];

function LayerLabelTag({ name, detail }: LayerLabel) {
  return (
    <div className="pointer-events-none select-none whitespace-nowrap rounded-md border border-white/15 bg-ink-950/85 px-2.5 py-1.5 shadow-lg backdrop-blur">
      <p className="font-display text-[11px] font-extrabold uppercase tracking-wider text-white">{name}</p>
      <p className="max-w-[220px] truncate text-[10px] font-semibold text-brand-400">{detail}</p>
    </div>
  );
}

function ExplodedBall({
  canvas,
  roughness,
  specs,
  focus,
  layerNames,
  layerImages,
}: {
  canvas: HTMLCanvasElement | null;
  roughness: number;
  specs: BallSpecs;
  focus: LayerKey | null;
  layerNames?: Partial<Record<LayerKey, LayerLabel>>;
  layerImages?: LayerImages | null;
}) {
  const texture = useBallTexture(canvas);
  const woven = useMemo(() => makeWovenTexture(), []);
  const foamTex = useSafeTexture(layerImages?.foam);
  const liningTex = useSafeTexture(layerImages?.lining) ?? woven;
  const bladderTex = useSafeTexture(layerImages?.bladder);
  const coverTex = useSafeTexture(layerImages?.cover);
  const refs = {
    cover: useRef<THREE.Group>(null),
    foam: useRef<THREE.Group>(null),
    lining: useRef<THREE.Group>(null),
    bladder: useRef<THREE.Group>(null),
  };
  const t = useRef(0);

  useEffect(() => () => woven.dispose(), [woven]);

  useFrame((_, delta) => {
    t.current = THREE.MathUtils.damp(t.current, 1, 3.4, delta);
    (Object.keys(refs) as LayerKey[]).forEach((k) => {
      const g = refs[k].current;
      if (g) g.position.x = EXPLODE_OFFSET[k] * t.current;
    });
  });

  const latex = specs.bladder.toLowerCase().includes("latex");
  const dim = (key: LayerKey) => (focus && focus !== key ? 0.2 : 1);
  const names: Record<LayerKey, LayerLabel> = {
    cover: layerNames?.cover ?? { name: "Rexine cover", detail: "1.05 mm" },
    foam: layerNames?.foam ?? { name: "Impact foam", detail: `${specs.foamMm} mm EVA` },
    lining: layerNames?.lining ?? { name: "Fabric lining", detail: specs.lining },
    bladder: layerNames?.bladder ?? { name: "Bladder", detail: specs.bladder },
  };
  const tagPos: [number, number, number][] = [
    [0.55, 0.85, 0.3],
    [0.42, 0.66, 0.25],
    [0.32, 0.52, 0.22],
    [0.16, 0.42, 0.2],
  ];

  return (
    <group rotation={[0, -Math.PI / 2, 0]}>
      <group ref={refs.cover}>
        <mesh>
          <sphereGeometry args={wedgeArgs(1)} />
          <meshPhysicalMaterial
            side={THREE.DoubleSide}
            {...coverMaterialProps(coverTex ?? texture, roughness, dim("cover"))}
          />
        </mesh>
        <Html position={tagPos[0]} zIndexRange={[40, 30]}>
          <LayerLabelTag {...names.cover} />
        </Html>
      </group>

      <group ref={refs.foam}>
        <mesh>
          <sphereGeometry args={wedgeArgs(0.8)} />
          <meshStandardMaterial
            map={foamTex}
            color={foamTex ? "#ffffff" : "#efe7d2"}
            roughness={1}
            side={THREE.DoubleSide}
            transparent={focus !== null}
            opacity={dim("foam")}
          />
        </mesh>
        <Html position={tagPos[1]} zIndexRange={[40, 30]}>
          <LayerLabelTag {...names.foam} />
        </Html>
      </group>

      <group ref={refs.lining}>
        <mesh>
          <sphereGeometry args={wedgeArgs(0.63)} />
          <meshStandardMaterial
            map={liningTex}
            color={liningTex ? "#ffffff" : "#cdbc9d"}
            roughness={0.9}
            side={THREE.DoubleSide}
            transparent={focus !== null}
            opacity={dim("lining")}
          />
        </mesh>
        <Html position={tagPos[2]} zIndexRange={[40, 30]}>
          <LayerLabelTag {...names.lining} />
        </Html>
      </group>

      <group ref={refs.bladder}>
        <mesh>
          <sphereGeometry args={[0.48, 64, 64]} />
          <meshPhysicalMaterial
            map={bladderTex}
            color={bladderTex ? "#ffffff" : latex ? "#d9c9a2" : "#2e2721"}
            roughness={0.42}
            clearcoat={0.35}
            side={THREE.DoubleSide}
            transparent={focus !== null}
            opacity={dim("bladder")}
          />
        </mesh>
        <mesh position={[0, -0.5, 0]}>
          <cylinderGeometry args={[0.035, 0.045, 0.09, 24]} />
          <meshStandardMaterial color="#151310" roughness={0.5} />
        </mesh>
        <Html position={tagPos[3]} zIndexRange={[40, 30]}>
          <LayerLabelTag {...names.bladder} />
        </Html>
      </group>
    </group>
  );
}

/* ---------------- main viewer ---------------- */

export default function BallViewer({
  panelStyle,
  colors,
  rexineUrl,
  artworkUrl,
  designSvgUrl,
  modelUrl,
  modelAdjust,
  renderUrl,
  layerImages,
  seamStyle,
  logoUrl,
  logo,
  logoDraggable = false,
  onLogoMove,
  label,
  roughness = 0.42,
  autoRotate = true,
  closeUp = false,
  exploded = false,
  specs,
  layerNames,
  focusLayer = null,
  onMeta,
  className,
}: BallViewerProps) {
  const [canvas, setCanvas] = useState<HTMLCanvasElement | null>(null);
  const buildSeq = useRef(0);
  const onMetaRef = useRef(onMeta);
  onMetaRef.current = onMeta;
  const logoKey = logo ? `${logo.u}|${logo.v}|${logo.scale}|${logo.rotate}|${logo.badge}` : "";

  useEffect(() => {
    const seq = ++buildSeq.current;
    const opts: BallTextureOptions = {
      panelStyle,
      colors,
      rexineUrl,
      artworkUrl,
      designSvgUrl,
      logoUrl,
      logo,
      label,
      seamStyle,
      onMeta: (m) => onMetaRef.current?.(m),
    };
    buildBallCanvas(opts)
      .then((c) => buildSeq.current === seq && setCanvas(c))
      .catch(() => buildSeq.current === seq && setCanvas(null));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [panelStyle, colors, rexineUrl, artworkUrl, designSvgUrl, logoUrl, logoKey, label, seamStyle]);

  const drag = useLogoDrag(logoDraggable && !exploded, onLogoMove);

  const resolvedSpecs: BallSpecs = specs ?? {
    bladder: "Butyl valve bladder",
    lining: "Cotton-poly winding",
    foamMm: 2,
  };

  const showRender = !exploded && !!renderUrl && !modelUrl;

  return (
    <div className={className}>
      {showRender ? (
        <div className="relative h-full w-full">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={renderUrl!} alt="3D render" className="h-full w-full object-contain" />
          <span className="absolute right-3 top-3 rounded-md bg-black/55 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-white/80 backdrop-blur">
            Studio 3D render · click “Look inside” for layers
          </span>
        </div>
      ) : (
        <>
          {!canvas && (
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="h-24 w-24 animate-pulse rounded-full bg-ink-200/60" />
            </div>
          )}
          <Canvas
            camera={{ position: [0.9, 0.55, 3.1], fov: 40 }}
            dpr={[1, 1.5]}
            gl={{ antialias: true, alpha: true, powerPreference: "default" }}
            style={{ background: "transparent" }}
          >
            <ambientLight intensity={0.85} />
            <directionalLight position={[4, 6, 6]} intensity={1.7} />
            <directionalLight position={[-6, -2, -5]} intensity={0.45} color="#ffe1d6" />
            <directionalLight position={[0, -6, 3]} intensity={0.25} />
            <Suspense fallback={null}>
              {exploded ? (
                <ExplodedBall
                  canvas={canvas}
                  roughness={roughness}
                  specs={resolvedSpecs}
                  focus={focusLayer}
                  layerNames={layerNames}
                  layerImages={layerImages}
                />
              ) : modelUrl ? (
                <ModelBall url={modelUrl} canvas={canvas} roughness={roughness} adjust={modelAdjust} drag={drag} />
              ) : (
                <Ball
                  canvas={canvas}
                  roughness={roughness}
                  drag={drag}
                  logoDraggable={logoDraggable}
                  rotY={((modelAdjust?.rotY ?? 0) * Math.PI) / 180}
                />
              )}
            </Suspense>
            <CameraRig closeUp={closeUp} exploded={exploded} />
            <OrbitControls
              makeDefault
              enablePan={false}
              minDistance={1.3}
              maxDistance={7.5}
              autoRotate={autoRotate && !exploded}
              autoRotateSpeed={0.85}
              zoomSpeed={0.9}
            />
          </Canvas>
          {logoDraggable && !exploded && (
            <span className="pointer-events-none absolute bottom-16 left-1/2 -translate-x-1/2 rounded-md bg-brand-600/90 px-3 py-1.5 text-[11px] font-bold text-white backdrop-blur">
              Drag the logo on the ball to place it
            </span>
          )}
        </>
      )}
    </div>
  );
}
