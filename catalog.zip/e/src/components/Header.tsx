"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import { Compass, Menu, X } from "lucide-react";
import { useTour } from "@/components/Tour";
import { cn } from "@/lib/utils";

const NAV = [
  { href: "/", label: "Home" },
  { href: "/catalog", label: "Catalog" },
  { href: "/catalog#thermal-bonded", label: "Thermal Bonded" },
  { href: "/catalog#hand-stitched", label: "Hand-Stitched" },
];

export default function Header() {
  const pathname = usePathname();
  const { startTour, isActive } = useTour();
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 border-b border-line bg-paper/90 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-4 px-4 sm:px-6">
        <Link href="/" data-tour="brand" className="flex items-center gap-3">
          <span className="grid h-9 w-9 place-items-center rounded-md bg-brand-600 font-display text-lg font-black text-white shadow-sm">
            F
          </span>
          <span className="leading-none">
            <span className="block font-display text-[15px] font-black uppercase tracking-[0.14em] text-ink-950">
              Forward Sports
            </span>
            <span className="mt-0.5 block text-[10px] font-bold uppercase tracking-[0.28em] text-brand-700">
              E-Catalog · Sialkot
            </span>
          </span>
        </Link>

        <nav className="hidden items-center gap-1 lg:flex">
          {NAV.map((n) => (
            <Link
              key={n.href}
              href={n.href}
              className={cn(
                "rounded-lg px-3 py-2 text-sm font-semibold text-ink-600 transition hover:bg-ink-950/5 hover:text-ink-950",
                (pathname === n.href || (n.href !== "/catalog" && pathname.startsWith(n.href) && n.href.startsWith("/catalog/"))) &&
                  pathname === n.href
                  ? "bg-ink-950/5 text-ink-950"
                  : ""
              )}
            >
              {n.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <button
            data-tour="tour-button"
            onClick={() =>
              startTour(pathname.startsWith("/admin") ? "admin" : pathname.startsWith("/catalog") ? "catalog" : "home")
            }
            disabled={isActive}
            className="hidden items-center gap-1.5 rounded-lg border border-line bg-card px-3 py-2 text-xs font-bold uppercase tracking-wide text-ink-700 transition hover:border-brand-300 hover:text-brand-700 sm:flex"
          >
            <Compass className="h-3.5 w-3.5" />
            Tour
          </button>
          <button
            className="rounded-lg border border-line p-2 text-ink-700 lg:hidden"
            onClick={() => setOpen((v) => !v)}
            aria-label="Menu"
          >
            {open ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
          </button>
        </div>
      </div>

      {open && (
        <div className="border-t border-line bg-card px-4 py-3 lg:hidden">
          {NAV.map((n) => (
            <Link
              key={n.href}
              href={n.href}
              onClick={() => setOpen(false)}
              className="block rounded-lg px-3 py-2.5 text-sm font-semibold text-ink-700 hover:bg-paper"
            >
              {n.label}
            </Link>
          ))}
          <button
            onClick={() => {
              setOpen(false);
              startTour(pathname.startsWith("/catalog") ? "catalog" : "home");
            }}
            className="mt-1 flex w-full items-center gap-2 rounded-lg px-3 py-2.5 text-sm font-semibold text-brand-700"
          >
            <Compass className="h-4 w-4" /> Start the guided tour
          </button>
        </div>
      )}
    </header>
  );
}
