import type { Metadata } from "next";
import type { ReactNode } from "react";
import "@fontsource-variable/archivo";
import "@fontsource-variable/manrope";
import "./globals.css";
import { TourProvider } from "@/components/Tour";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

export const metadata: Metadata = {
  title: "Forward Sports — E-Catalog | The Soccer Expert",
  description:
    "Interactive 3D e-catalog of Forward Sports, Sialkot. Configure hand-stitched, machine-stitched, thermal-bonded, hybrid, mini, volleyball and medicine balls with live rexine materials and your own logo.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-paper text-ink-900 font-ui antialiased">
        <TourProvider>
          <Header />
          {children}
          <Footer />
        </TourProvider>
      </body>
    </html>
  );
}
