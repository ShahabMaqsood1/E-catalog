import Link from "next/link";
import { eq } from "drizzle-orm";
import { ArrowRight, BadgeCheck, Factory, Flame, Hand, Layers } from "lucide-react";
import { db } from "@/db";
import { articles, categories, compliance, materials, type HeroPreset } from "@/db/schema";
import { getSetting } from "@/lib/settings";
import { getContent } from "@/lib/content";
import { CategoryIcon } from "@/components/CategoryIcon";
import HeroBall, { type HeroPresetData } from "@/components/HeroBall";
import BallThumb from "@/components/BallThumb";
import { formatMoney } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const [cats, arts, mats, comp, presetCfg, c] = await Promise.all([
    db.select().from(categories).where(eq(categories.isActive, true)).orderBy(categories.sortOrder),
    db.select().from(articles),
    db.select().from(materials).where(eq(materials.isActive, true)),
    db.select().from(compliance).where(eq(compliance.status, "compliant")).limit(6),
    getSetting<HeroPreset[]>("heroPresets", []),
    getContent(),
  ]);

  const liveArts = arts.filter((a) => a.status === "live");
  const heroPresets: HeroPresetData[] = presetCfg
    .map((cfg): HeroPresetData | null => {
      const a = liveArts.find((x) => x.articleNo === cfg.articleNo) ?? liveArts[0];
      const m = mats.find((x) => x.code === cfg.materialCode) ?? mats[0];
      if (!a) return null;
      return {
        label: cfg.label || a.name,
        articleNo: a.articleNo,
        panelStyle: a.panelStyle,
        colors: a.colors,
        artworkUrl: a.artworkUrl,
        designSvgUrl: a.designSvgUrl,
        modelUrl: a.modelUrl,
        renderUrl: a.renderUrl,
        seamStyle: a.seamStyle,
        specs: a.specs,
        layerImages: a.layerImages,
        rexineUrl: m?.textureUrl ?? null,
        rexineName: m?.name ?? "Standard cover",
        rexineThickness: m?.thickness ?? "",
      };
    })
    .filter((x) => x !== null);

  const featured = liveArts.filter((a) => a.featured).slice(0, 6);
  const catStats = cats.map((cat) => {
    const inCat = liveArts.filter((a) => a.categoryId === cat.id);
    const mins = inCat.map((a) => Number(a.basePrice));
    return { ...cat, count: inCat.length, from: mins.length ? Math.min(...mins) : null };
  });
  const chips = c["home.processChips"].split(",").map((s) => s.trim()).filter(Boolean);
  const steps = [1, 2, 3].map((n) => ({
    icon: n === 1 ? <Layers className="h-5 w-5" /> : n === 2 ? <Hand className="h-5 w-5" /> : <Factory className="h-5 w-5" />,
    label: c[`home.step${n}Label`],
    title: c[`home.step${n}Title`],
    body: c[`home.step${n}Body`],
  }));

  return (
    <main>
      {/* Hero */}
      <section className="relative overflow-hidden bg-ink-950 text-white">
        <div className="blueprint-grid absolute inset-0" />
        <div className="pointer-events-none absolute -right-40 -top-40 h-[480px] w-[480px] rounded-full bg-brand-600/20 blur-[130px]" />
        <div className="relative mx-auto grid max-w-7xl items-center gap-10 px-4 pb-16 pt-14 sm:px-6 lg:grid-cols-[1.05fr_1fr] lg:pb-20 lg:pt-18">
          <div>
            <p className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-3.5 py-1.5 text-[11px] font-extrabold uppercase tracking-[0.22em] text-white/80">
              <span className="h-1.5 w-1.5 rounded-full bg-brand-500 pulse-dot" />
              {c["home.badge"]}
            </p>
            <h1 className="mt-6 font-display text-4xl font-black uppercase leading-[1.02] tracking-tight sm:text-5xl lg:text-[56px]">
              {c["home.title1"]}
              <span className="block text-brand-500">{c["home.title2"]}</span>
            </h1>
            <p className="mt-5 max-w-xl text-base leading-relaxed text-white/65">{c["home.intro"]}</p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link
                href="/catalog"
                className="flex items-center gap-2 rounded-xl bg-brand-600 px-6 py-3.5 font-display text-sm font-extrabold uppercase tracking-widest text-white shadow-xl shadow-brand-600/30 transition hover:bg-brand-500"
              >
                {c["home.ctaPrimary"]} <ArrowRight className="h-4 w-4" />
              </Link>
              <a
                href="#constructions"
                className="flex items-center gap-2 rounded-xl border border-white/20 bg-white/5 px-6 py-3.5 font-display text-sm font-extrabold uppercase tracking-widest text-white transition hover:bg-white/10"
              >
                {c["home.ctaSecondary"]}
              </a>
            </div>
            <dl className="mt-10 grid max-w-lg grid-cols-3 gap-6 border-t border-white/10 pt-6">
              {[
                [`${catStats.length}`, c["home.stat1"]],
                [`${liveArts.length}`, c["home.stat2"]],
                [`${mats.length}`, c["home.stat3"]],
              ].map(([v, l]) => (
                <div key={l}>
                  <dt className="font-display text-3xl font-black text-white">{v}</dt>
                  <dd className="mt-1 text-[11px] font-bold uppercase tracking-wider text-white/50">{l}</dd>
                </div>
              ))}
            </dl>
          </div>
          <div data-tour="hero-ball">
            <HeroBall presets={heroPresets} />
          </div>
        </div>
      </section>

      {/* Categories */}
      <section id="constructions" data-tour="categories" className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
        <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="text-xs font-extrabold uppercase tracking-[0.28em] text-brand-700">
              {c["home.constructionsEyebrow"]}
            </p>
            <h2 className="mt-2 font-display text-3xl font-black uppercase tracking-tight text-ink-950 sm:text-4xl">
              {c["home.constructionsTitle"]}
            </h2>
          </div>
          <Link href="/catalog" className="flex items-center gap-1.5 text-sm font-bold text-brand-700 hover:text-brand-600">
            {c["home.ctaPrimary"]} <ArrowRight className="h-4 w-4" />
          </Link>
        </div>

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {catStats.map((cat, i) => (
            <Link
              key={cat.id}
              href={`/catalog#${cat.slug}`}
              className="group relative overflow-hidden rounded-2xl border border-line bg-card p-6 transition hover:-translate-y-0.5 hover:border-brand-300 hover:shadow-lg"
            >
              <span className="absolute right-4 top-4 font-display text-4xl font-black text-ink-100 transition group-hover:text-brand-100">
                {String(i + 1).padStart(2, "0")}
              </span>
              <span className="grid h-11 w-11 place-items-center rounded-xl bg-ink-950 text-white transition group-hover:bg-brand-600">
                <CategoryIcon iconKey={cat.iconKey} className="h-5 w-5" />
              </span>
              <h3 className="mt-5 font-display text-lg font-extrabold leading-tight text-ink-950">{cat.shortName}</h3>
              <p className="mt-1.5 text-[13px] leading-relaxed text-ink-500">{cat.tagline}</p>
              <p className="mt-4 flex items-center justify-between border-t border-line pt-3.5 text-xs font-bold text-ink-600">
                <span>
                  {cat.count} article{cat.count === 1 ? "" : "s"}
                  {cat.from !== null && <span className="text-ink-400"> · from {formatMoney(cat.from)}</span>}
                </span>
                <ArrowRight className="h-4 w-4 text-brand-600 transition group-hover:translate-x-1" />
              </p>
            </Link>
          ))}

          <div className="relative overflow-hidden rounded-2xl bg-brand-600 p-6 text-white">
            <Flame className="h-8 w-8 text-white/70" />
            <h3 className="mt-5 font-display text-lg font-extrabold leading-tight">{c["home.capacityTitle"]}</h3>
            <p className="mt-1.5 text-[13px] leading-relaxed text-white/80">{c["home.capacityBody"]}</p>
            <p className="mt-4 border-t border-white/20 pt-3.5 text-xs font-bold uppercase tracking-wider text-white/70">
              {c["home.capacityFoot"]}
            </p>
          </div>
        </div>
      </section>

      {/* Featured */}
      <section className="border-y border-line bg-paper-deep/60">
        <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
          <div className="mb-8">
            <p className="text-xs font-extrabold uppercase tracking-[0.28em] text-brand-700">{c["home.featuredEyebrow"]}</p>
            <h2 className="mt-2 font-display text-3xl font-black uppercase tracking-tight text-ink-950">
              {c["home.featuredTitle"]}
            </h2>
          </div>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {featured.map((a) => {
              const cat = cats.find((x) => x.id === a.categoryId);
              return (
                <Link
                  key={a.id}
                  href={`/catalog#${cat?.slug ?? ""}`}
                  className="group flex items-center gap-4 rounded-2xl border border-line bg-card p-5 transition hover:border-brand-300 hover:shadow-md"
                >
                  <BallThumb
                    panelStyle={a.panelStyle}
                    colors={a.colors}
                    artworkUrl={a.artworkUrl}
                    designSvgUrl={a.designSvgUrl}
                    seamStyle={a.seamStyle}
                    size={92}
                  />
                  <div className="min-w-0">
                    <p className="text-[10px] font-extrabold uppercase tracking-[0.2em] text-brand-700">{cat?.shortName}</p>
                    <h3 className="mt-1 font-display text-base font-extrabold text-ink-950">{a.name}</h3>
                    <p className="mt-0.5 text-xs font-semibold text-ink-400">
                      {a.articleNo} · {a.panelCount} panels
                    </p>
                    <p className="mt-2 font-display text-lg font-black text-ink-950">
                      FOB {formatMoney(a.basePrice)}
                    </p>
                  </div>
                </Link>
              );
            })}
          </div>
        </div>
      </section>

      {/* Process */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
        <div className="grid items-start gap-10 lg:grid-cols-[1fr_1.3fr]">
          <div>
            <p className="text-xs font-extrabold uppercase tracking-[0.28em] text-brand-700">{c["home.processEyebrow"]}</p>
            <h2 className="mt-2 font-display text-3xl font-black uppercase tracking-tight text-ink-950 sm:text-4xl">
              {c["home.processTitle"]}
            </h2>
            <p className="mt-4 max-w-md text-sm leading-relaxed text-ink-500">{c["home.processIntro"]}</p>
            <div className="mt-6 flex flex-wrap gap-2">
              {chips.map((t) => (
                <span key={t} className="rounded-md border border-line bg-card px-2.5 py-1.5 text-xs font-bold text-ink-600">
                  {t}
                </span>
              ))}
            </div>
          </div>
          <ol className="space-y-4">
            {steps.map((s) => (
              <li key={s.title} className="flex gap-4 rounded-2xl border border-line bg-card p-6">
                <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-brand-600 text-white">{s.icon}</span>
                <div>
                  <p className="text-[10px] font-extrabold uppercase tracking-[0.24em] text-brand-700">{s.label}</p>
                  <h3 className="mt-1 font-display text-lg font-extrabold text-ink-950">{s.title}</h3>
                  <p className="mt-1.5 text-[13px] leading-relaxed text-ink-500">{s.body}</p>
                </div>
              </li>
            ))}
          </ol>
        </div>
      </section>

      {/* Compliance strip */}
      <section className="bg-ink-950 text-white">
        <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6">
          <div className="flex flex-wrap items-center justify-between gap-6">
            <div className="max-w-md">
              <h2 className="font-display text-2xl font-black uppercase tracking-tight">{c["home.complianceTitle"]}</h2>
              <p className="mt-2 text-sm text-white/60">{c["home.complianceBody"]}</p>
            </div>
            <div className="flex flex-wrap gap-2.5">
              {comp.map((item) => (
                <span
                  key={item.id}
                  className="inline-flex items-center gap-2 rounded-lg border border-white/15 bg-white/5 px-3.5 py-2 text-xs font-bold"
                >
                  <BadgeCheck className="h-4 w-4 text-brand-400" />
                  {item.title.split("—")[0].trim()}
                </span>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
        <div className="relative overflow-hidden rounded-3xl bg-brand-600 px-8 py-12 text-white sm:px-12">
          <div className="pointer-events-none absolute -right-24 -top-24 h-80 w-80 rounded-full border-[28px] border-white/10" />
          <div className="pointer-events-none absolute -bottom-32 right-24 h-72 w-72 rounded-full border-[22px] border-white/10" />
          <div className="relative max-w-2xl">
            <h2 className="font-display text-3xl font-black uppercase tracking-tight sm:text-4xl">{c["home.ctaTitle"]}</h2>
            <p className="mt-3 text-sm leading-relaxed text-white/80">{c["home.ctaBody"]}</p>
            <div className="mt-7 flex flex-wrap gap-3">
              <Link
                href="/catalog"
                className="rounded-xl bg-white px-6 py-3 font-display text-sm font-extrabold uppercase tracking-widest text-brand-700 transition hover:bg-paper"
              >
                {c["home.ctaPrimary2"]}
              </Link>
              <Link
                href="/catalog#thermal-bonded"
                className="rounded-xl border border-white/40 px-6 py-3 font-display text-sm font-extrabold uppercase tracking-widest text-white transition hover:bg-white/10"
              >
                {c["home.ctaSecondary2"]}
              </Link>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
