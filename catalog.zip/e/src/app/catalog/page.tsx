import { eq } from "drizzle-orm";
import { db } from "@/db";
import { articles, categories, materials } from "@/db/schema";
import CatalogOnePage from "@/components/Configurator";
import { DEFAULT_TIERS, getSetting } from "@/lib/settings";
import { getContent } from "@/lib/content";

export const dynamic = "force-dynamic";

export default async function CatalogPage() {
  const [cats, arts, mats, tiers, content] = await Promise.all([
    db.select().from(categories).where(eq(categories.isActive, true)).orderBy(categories.sortOrder),
    db.select().from(articles).where(eq(articles.status, "live")),
    db.select().from(materials).where(eq(materials.isActive, true)).orderBy(materials.sortOrder),
    getSetting("quoteTiers", DEFAULT_TIERS),
    getContent(),
  ]);

  const slugById = new Map(cats.map((c) => [c.id, c.slug]));

  return (
    <CatalogOnePage
      categories={cats.map((c) => ({
        id: c.id,
        slug: c.slug,
        name: c.name,
        shortName: c.shortName,
        tagline: c.tagline,
        description: c.description,
        iconKey: c.iconKey,
      }))}
      articles={arts.map((a) => ({
        id: a.id,
        categoryId: a.categoryId,
        articleNo: a.articleNo,
        name: a.name,
        description: a.description,
        panelStyle: a.panelStyle,
        panelCount: a.panelCount,
        basePrice: Number(a.basePrice),
        moq: a.moq,
        colors: a.colors,
        featured: a.featured,
        artworkUrl: a.artworkUrl,
        designSvgUrl: a.designSvgUrl,
        modelUrl: a.modelUrl,
        modelAdjust: a.modelAdjust,
        renderUrl: a.renderUrl,
        seamStyle: a.seamStyle,
        layerImages: a.layerImages,
        specs: a.specs,
        categorySlug: slugById.get(a.categoryId) ?? "",
      }))}
      materials={mats.map((m) => ({
        id: m.id,
        code: m.code,
        name: m.name,
        finish: m.finish,
        description: m.description,
        textureUrl: m.textureUrl,
        priceDelta: Number(m.priceDelta),
        thickness: m.thickness,
        weightGsm: m.weightGsm,
      }))}
      tiers={tiers}
      content={content}
    />
  );
}
