/**
 * mock3d.mjs — MOCK 3D DATA FACTORY (Forward Sports e-catalog)
 * ------------------------------------------------------------------
 * Generates, with ZERO external dependencies (pure Node: zlib + pg):
 *   1. One baked-artwork GLB per article  → public/media/models/mock-<articleNo>.glb
 *      (UV sphere + procedurally painted equirectangular wrap using the
 *       article's real colours + panel style; embedded PNG; glTF 2.0 binary)
 *      and attaches it via articles.model_url.
 *   2. Nine procedural rexine swatch PNGs → public/textures/rx-*.png
 *      (FS-RX-07…FS-RX-15, pebbled leather grain per material colour)
 *      and inserts the material rows (ON CONFLICT DO NOTHING).
 *   3. Sets articles.default_material_code (per-article rexine identity).
 *
 * These are MOCK assets — replace each article's model_url with the client's
 * real baked GLB when it arrives (Admin → Articles, or PATCH API).
 *
 * Run:  node scripts/mock3d.mjs        (idempotent — safe to re-run)
 */
import { deflateSync } from "node:zlib";
import { writeFileSync, mkdirSync } from "node:fs";
import path from "node:path";
import pg from "pg";

const DB_URL =
  process.env.DATABASE_URL || "postgresql://postgres:postgres@127.0.0.1:5432/app_db";
/* Item 6 + 10: everything lands in the project's own media tree, in a folder per
   asset type, so the files travel with the project when it is copied to another
   machine (storage/uploads was outside the project and got left behind). */
const MODEL_DIR = path.resolve("public/media/models");
const REXINE_DIR = path.resolve("public/media/rexine");
const MODEL_URL_PREFIX = "/api/files/models";
const WRAP_W = 1024;
const WRAP_H = 512;

/* ---------------------------------------------------------------- PNG ---- */
const CRC_TABLE = (() => {
  const t = new Int32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    t[n] = c;
  }
  return t;
})();
function crc32(buf) {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}
function chunk(type, data) {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length);
  const body = Buffer.concat([Buffer.from(type, "ascii"), data]);
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crc32(body));
  return Buffer.concat([len, body, crc]);
}
/** rgb: Uint8Array w*h*3 → PNG buffer */
function pngEncode(w, h, rgb) {
  const raw = Buffer.alloc((w * 3 + 1) * h);
  for (let y = 0; y < h; y++) {
    raw[y * (w * 3 + 1)] = 0; // filter: none
    rgb.subarray(y * w * 3, (y + 1) * w * 3).forEach((v, i) => {
      raw[y * (w * 3 + 1) + 1 + i] = v;
    });
  }
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(w, 0);
  ihdr.writeUInt32BE(h, 4);
  ihdr[8] = 8; // depth
  ihdr[9] = 2; // color type: truecolor
  return Buffer.concat([
    Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]),
    chunk("IHDR", ihdr),
    chunk("IDAT", deflateSync(raw, { level: 9 })),
    chunk("IEND", Buffer.alloc(0)),
  ]);
}

/* ------------------------------------------------------------- noise ----- */
const hash2 = (i, j, seed) => {
  const s = Math.sin(i * 127.1 + j * 311.7 + seed * 57.13) * 43758.5453;
  return s - Math.floor(s);
};
function vnoise(x, y, seed) {
  const xi = Math.floor(x), yi = Math.floor(y);
  const xf = x - xi, yf = y - yi;
  const u = xf * xf * (3 - 2 * xf), v = yf * yf * (3 - 2 * yf);
  const a = hash2(xi, yi, seed), b = hash2(xi + 1, yi, seed);
  const c = hash2(xi, yi + 1, seed), d = hash2(xi + 1, yi + 1, seed);
  return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
}
function fbm(x, y, seed) {
  return (
    0.55 * vnoise(x, y, seed) +
    0.3 * vnoise(x * 2.1, y * 2.1, seed + 11) +
    0.15 * vnoise(x * 4.3, y * 4.3, seed + 23)
  );
}

/* ------------------------------------------------------------ colours ---- */
const hex2rgb = (hex) => {
  const h = (hex || "#cccccc").replace("#", "");
  const n = parseInt(h.length === 3 ? h.split("").map((c) => c + c).join("") : h, 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
};
const mix = (a, b, t) => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];
const clamp255 = (v) => (v < 0 ? 0 : v > 255 ? 255 : v | 0);

/* ------------------------------------------------- equirect wrap painter -- */
/** Returns rgb Uint8Array(W*H*3) — stylised panel artwork per article. */
function paintWrap(colors, style, seed) {
  const base = hex2rgb(colors?.base);
  const accent = hex2rgb(colors?.accent);
  const ink = hex2rgb(colors?.ink || "#1b1b1b");
  const out = new Uint8Array(WRAP_W * WRAP_H * 3);
  const SW = 0.055; // seam half-width in panel units

  for (let py = 0; py < WRAP_H; py++) {
    const v = (py + 0.5) / WRAP_H;
    const lat = (0.5 - v) * Math.PI;
    for (let px = 0; px < WRAP_W; px++) {
      const u = (px + 0.5) / WRAP_W;
      const lon = (u - 0.5) * 2 * Math.PI;
      let col; // [r,g,b]
      let seamT = 1; // 0 = on seam line, 1 = panel interior
      let stitch = false;

      if (style === "vortex-18") {
        const t = u * 9 + Math.sin(v * Math.PI * 2) * 0.55 + v * 1.2;
        const cell = Math.floor(t), f = t - cell;
        const dx = Math.min(f, 1 - f);
        const fy = v * 3 - Math.floor(v * 3);
        const dy = Math.min(fy, 1 - fy) * 1.6;
        seamT = Math.min(1, Math.min(dx, dy) / SW);
        col = cell % 2 ? accent : base;
        stitch = dx < SW * 0.4;
      } else if (style === "geo-24") {
        const gx = u * 6, gy = v * 4;
        const cx = Math.floor(gx), cy = Math.floor(gy);
        const fx = gx - cx, fy = gy - cy;
        const tri = fx + fy > 1;
        const d3 = Math.abs(fx + fy - 1) * 0.7071;
        seamT = Math.min(1, Math.min(Math.min(fx, 1 - fx), Math.min(fy, 1 - fy), d3) / SW);
        col = (cx + cy * 2 + (tri ? 1 : 0)) % 2 ? accent : base;
        stitch = d3 < SW * 0.4;
      } else if (style === "mini-star") {
        const cols = 4, rows = 3;
        const row = Math.floor(v * rows);
        const x = u * cols + (row % 2) * 0.5;
        const cell = Math.floor(x), fx = x - cell;
        const fy = v * rows - row;
        seamT = Math.min(1, Math.min(Math.min(fx, 1 - fx), Math.min(fy, 1 - fy) * 1.4) / SW);
        col = (cell + row) % 2 ? accent : base;
        // star motif near the "front" of the wrap
        const dl = Math.atan2(Math.sin(lon), Math.cos(lon));
        const dt = lat + 0.12;
        const r = Math.sqrt(dl * dl * 0.55 + dt * dt);
        const th = Math.atan2(dt, dl * 0.74);
        const R = 0.16 + 0.2 * Math.pow(Math.abs(Math.cos(2.5 * th)), 0.65);
        if (r < R) col = accent;
        if (r >= R && r < R + 0.028) col = ink;
        if (r < R) seamT = 1;
      } else if (style === "volley-18") {
        const t = u * 6 + 0.35 * Math.sin(v * Math.PI * 2) + 0.15 * Math.sin(v * Math.PI * 4 + 0.7);
        const cell = Math.floor(t), f = t - cell;
        const dx = Math.min(f, 1 - f);
        seamT = Math.min(1, dx / SW);
        col = cell % 3 === 0 ? accent : base;
        stitch = dx < SW * 0.4;
      } else {
        // classic-32 (and fallback): staggered brick grid
        const cols = 8, rows = 4;
        const row = Math.floor(v * rows);
        const x = u * cols + (row % 2) * 0.5;
        const cell = Math.floor(x), fx = x - cell;
        const fy = v * rows - row;
        seamT = Math.min(1, Math.min(Math.min(fx, 1 - fx), Math.min(fy, 1 - fy) * 1.4) / SW);
        col = (cell + row) % 2 ? accent : base;
        stitch = Math.min(fx, 1 - fx) < SW * 0.4 || Math.min(fy, 1 - fy) < SW * 0.3;
      }

      // seam lines: blend into ink; dashed stitch highlight on seam centres
      if (seamT < 1) {
        col = mix(col, ink, 1 - seamT);
        if (stitch && seamT < 0.45 && (px + py) % 9 < 4) col = mix(col, base, 0.22);
      }
      // micro grain so the surface reads like material, plus polar shading
      const n = fbm(px * 0.32, py * 0.32, seed);
      const g = 0.94 + 0.12 * n;
      const polar = 1 - 0.1 * Math.pow(Math.abs(v - 0.5) * 2, 3);
      const o = (py * WRAP_W + px) * 3;
      out[o] = clamp255(col[0] * g * polar);
      out[o + 1] = clamp255(col[1] * g * polar);
      out[o + 2] = clamp255(col[2] * g * polar);
    }
  }
  return out;
}

/* ------------------------------------------------------- glb builder ----- */
function uvSphere(widthSeg = 96, heightSeg = 64) {
  const pos = [], nor = [], uv = [], idx = [];
  for (let iy = 0; iy <= heightSeg; iy++) {
    const v = iy / heightSeg, phi = v * Math.PI;
    for (let ix = 0; ix <= widthSeg; ix++) {
      const u = ix / widthSeg, theta = u * Math.PI * 2;
      const x = -Math.cos(theta) * Math.sin(phi);
      const y = Math.cos(phi);
      const z = Math.sin(theta) * Math.sin(phi);
      pos.push(x, y, z);
      nor.push(x, y, z);
      uv.push(u, v); // glTF UV origin = top-left; row 0 of wrap = north pole
    }
  }
  const gx1 = widthSeg + 1;
  for (let iy = 0; iy < heightSeg; iy++) {
    for (let ix = 0; ix < widthSeg; ix++) {
      const a = gx1 * iy + ix + 1, b = gx1 * iy + ix;
      const c = gx1 * (iy + 1) + ix, d = gx1 * (iy + 1) + ix + 1;
      if (iy !== 0) idx.push(a, b, d);
      if (iy !== heightSeg - 1) idx.push(b, c, d);
    }
  }
  return {
    position: new Float32Array(pos),
    normal: new Float32Array(nor),
    texcoord: new Float32Array(uv),
    indices: new Uint32Array(idx),
  };
}

function buildGlb(pngBuf) {
  const sph = uvSphere();
  const pad4 = (n) => (n + 3) & ~3;
  const pBytes = Buffer.from(sph.position.buffer);
  const nBytes = Buffer.from(sph.normal.buffer);
  const tBytes = Buffer.from(sph.texcoord.buffer);
  const iBytes = Buffer.from(sph.indices.buffer);
  const offP = 0;
  const offN = offP + pBytes.length;
  const offT = pad4(offN + nBytes.length);
  const offI = pad4(offT + tBytes.length);
  const offImg = pad4(offI + iBytes.length);
  const binLen = offImg + pngBuf.length;
  const bin = Buffer.alloc(binLen);
  pBytes.copy(bin, offP);
  nBytes.copy(bin, offN);
  tBytes.copy(bin, offT);
  iBytes.copy(bin, offI);
  pngBuf.copy(bin, offImg);

  const vCount = sph.position.length / 3;
  const iCount = sph.indices.length;
  const json = {
    asset: { version: "2.0", generator: "forward-sports mock3d (procedural)" },
    scene: 0,
    scenes: [{ nodes: [0] }],
    nodes: [{ mesh: 0, name: "Ball" }],
    meshes: [
      {
        name: "BallMesh",
        primitives: [
          { attributes: { POSITION: 0, NORMAL: 1, TEXCOORD_0: 2 }, indices: 3, material: 0 },
        ],
      },
    ],
    materials: [
      {
        name: "BallSkin",
        pbrMetallicRoughness: {
          baseColorTexture: { index: 0 },
          metallicFactor: 0,
          roughnessFactor: 0.5,
        },
        doubleSided: false,
      },
    ],
    textures: [{ sampler: 0, source: 0 }],
    samplers: [{ magFilter: 9729, minFilter: 9987, wrapS: 10497, wrapT: 10497 }],
    images: [{ bufferView: 4, mimeType: "image/png", name: "wrap" }],
    accessors: [
      { bufferView: 0, componentType: 5126, count: vCount, type: "VEC3", min: [-1, -1, -1], max: [1, 1, 1] },
      { bufferView: 1, componentType: 5126, count: vCount, type: "VEC3" },
      { bufferView: 2, componentType: 5126, count: vCount, type: "VEC2" },
      { bufferView: 3, componentType: 5125, count: iCount, type: "SCALAR" },
    ],
    bufferViews: [
      { buffer: 0, byteOffset: offP, byteLength: pBytes.length, target: 34962 },
      { buffer: 0, byteOffset: offN, byteLength: nBytes.length, target: 34962 },
      { buffer: 0, byteOffset: offT, byteLength: tBytes.length, target: 34962 },
      { buffer: 0, byteOffset: offI, byteLength: iBytes.length, target: 34963 },
      { buffer: 0, byteOffset: offImg, byteLength: pngBuf.length },
    ],
    buffers: [{ byteLength: binLen }],
  };
  let jsonBuf = Buffer.from(JSON.stringify(json), "utf8");
  jsonBuf = Buffer.concat([jsonBuf, Buffer.alloc(pad4(jsonBuf.length) - jsonBuf.length, 0x20)]);
  const binPad = Buffer.alloc(pad4(binLen) - binLen);
  const total = 12 + 8 + jsonBuf.length + 8 + bin.length + binPad.length;
  const head = Buffer.alloc(12);
  head.writeUInt32LE(0x46546c67, 0);
  head.writeUInt32LE(2, 4);
  head.writeUInt32LE(total, 8);
  const jh = Buffer.alloc(8);
  jh.writeUInt32LE(jsonBuf.length, 0);
  jh.writeUInt32LE(0x4e4f534a, 4);
  const bh = Buffer.alloc(8);
  bh.writeUInt32LE(bin.length + binPad.length, 0);
  bh.writeUInt32LE(0x004e4942, 4);
  return Buffer.concat([head, jh, jsonBuf, bh, bin, binPad]);
}

/* Session 4h: mock swatch generation REMOVED — real rexine photos are uploaded
   via Admin → Materials (each upload sets materials.texture_url live).
   New material rows are inserted with an empty texture_url. */

/* ------------------------------------------------------------- main ------ */
const ARTICLE_MATERIAL = {
  "FS-TB-01": "FS-RX-06", "FS-TB-02": "FS-RX-02", "FS-TB-03": "FS-RX-01",
  "FS-TB-04": "FS-RX-05", "FS-HS-05": "FS-RX-04", "FS-HS-06": "FS-RX-03",
  "FS-HS-07": "FS-RX-07", "FS-HS-08": "FS-RX-08", "FS-HS-09": "FS-RX-09",
  "FS-MS-10": "FS-RX-10", "FS-MS-11": "FS-RX-11", "FS-MS-12": "FS-RX-12",
  "FS-MB-13": "FS-MB-13RX", "FS-VB-14": "FS-RX-14", "FS-MS-15": "FS-RX-15",
};
const MATERIAL_ROWS = [
  ["FS-RX-07", "Pitch Green Suede", "Suede touch", "Soft suede-touch rexine in deep pitch green — tuned for hand-stitched futsal articles with a dry, grippy feel.", "", "2.20", "1.10 mm", 400, 7],
  ["FS-RX-08", "Training Orange Matte", "Matte TPU", "High-visibility matte training orange with pebble grain. Scuff-resistant finish for daily training balls.", "", "1.80", "1.00 mm", 380, 8],
  ["FS-RX-09", "Court Blue Grip", "Dimple grip", "Indoor-court blue with dimple grip texture for handball — consistent tack in fast play.", "", "3.20", "1.05 mm", 420, 9],
  ["FS-RX-10", "HFT Yellow Microfiber", "Microfiber PU", "Bright microfiber PU in HFT yellow — soft hand-feel, excellent print retention for machine-stitched promo balls.", "", "2.60", "1.00 mm", 390, 10],
  ["FS-RX-11", "Rhino Charcoal Weave", "Textured weave", "Heavy charcoal weave-textured rexine built for the RIHNO line — maximum durability, rugged look.", "", "4.20", "1.20 mm", 480, 11],
  ["FS-RX-12", "Striker Cobalt Gloss", "Gloss PU", "Deep cobalt gloss PU with fine grain — striking shelf presence for entry price points.", "", "2.50", "1.05 mm", 420, 12],
  ["FS-MB-13RX", "Candy Soft-touch Pink", "Soft-touch PU", "Candy pink soft-touch PU for mini/skill balls — gentle grip, kid-friendly feel.", "", "2.10", "1.00 mm", 380, 13],
  ["FS-RX-14", "Volley Ivory Micro", "Microfiber PU", "Ivory microfiber PU for volleyballs — soft touch panel surface with subtle sheen.", "", "2.40", "1.00 mm", 390, 14],
  ["FS-RX-15", "Prisma Print-grade White", "Print-grade PU", "Ultra-white print-grade PU for digital-printed articles — the brightest base for full-colour sublimation artwork.", "", "4.60", "1.10 mm", 450, 15],
];

async function main() {
  mkdirSync(MODEL_DIR, { recursive: true });
  mkdirSync(REXINE_DIR, { recursive: true });
  const client = new pg.Client({ connectionString: DB_URL });
  await client.connect();

  // 1. materials (idempotent)
  for (const r of MATERIAL_ROWS) {
    await client.query(
      `INSERT INTO materials (code,name,finish,description,texture_url,price_delta,thickness,weight_gsm,is_active,sort_order)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,true,$9) ON CONFLICT (code) DO NOTHING`,
      r
    );
  }
  console.log(`materials: ${MATERIAL_ROWS.length} new rexines ensured`);

  // 2. swatches: none — real photos come from Admin → Materials (session 4h)

  // 3. per-article mock GLBs + attachments + default rexine
  const { rows } = await client.query(
    "SELECT id, article_no, colors, panel_style FROM articles ORDER BY id"
  );
  for (const a of rows) {
    const wrap = paintWrap(a.colors ?? {}, a.panel_style, a.id * 7 + 3);
    const glb = buildGlb(pngEncode(WRAP_W, WRAP_H, wrap));
    const safe = String(a.article_no).toLowerCase().replace(/[^a-z0-9._-]+/g, "-");
    const file = `mock-${safe}.glb`;
    writeFileSync(path.join(MODEL_DIR, file), glb);
    await client.query(
      "UPDATE articles SET model_url=$1, default_material_code=$2 WHERE id=$3",
      [`${MODEL_URL_PREFIX}/${file}`, ARTICLE_MATERIAL[a.article_no] ?? null, a.id]
    );
    console.log(
      `  ${a.article_no.padEnd(9)} ${a.panel_style.padEnd(11)} → ${file} (${(glb.length / 1024) | 0} KB) rexine=${ARTICLE_MATERIAL[a.article_no] ?? "—"}`
    );
  }

  await client.end();
  console.log(`done: ${rows.length} mock GLBs attached.`);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
