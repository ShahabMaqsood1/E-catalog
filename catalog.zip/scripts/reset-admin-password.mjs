/**
 * Emergency dashboard-password reset — works even when you cannot sign in.
 *
 *   node scripts/reset-admin-password.mjs                     → uses ADMIN_PASSWORD from .env
 *   node scripts/reset-admin-password.mjs "My@NewPassword1"   → uses the value you pass
 *
 * It writes the same scrypt hash the app verifies against (settings row
 * `adminCredential`), rotates the session epoch so every old cookie dies, and
 * clears the brute-force lockout. Pure Node + pg, no build step required.
 */
import { randomBytes, scryptSync } from "node:crypto";
import { existsSync, readFileSync } from "node:fs";
import path from "node:path";
import pg from "pg";

const MIN_PASSWORD_LENGTH = 12;

function loadEnvFile() {
  const file = path.resolve(".env");
  if (!existsSync(file)) return {};
  const out = {};
  for (const line of readFileSync(file, "utf8").split(/\r?\n/)) {
    const m = /^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/i.exec(line);
    if (!m) continue;
    let v = m[2].trim();
    if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) v = v.slice(1, -1);
    out[m[1]] = v;
  }
  return out;
}

const env = loadEnvFile();
const DB_URL = process.env.DATABASE_URL || env.DATABASE_URL || "postgresql://postgres:postgres@127.0.0.1:5432/app_db";

function passwordIssues(pw) {
  const issues = [];
  if (pw.length < MIN_PASSWORD_LENGTH) issues.push(`at least ${MIN_PASSWORD_LENGTH} characters (currently ${pw.length})`);
  if (!/[A-Z]/.test(pw)) issues.push("an uppercase letter");
  if (!/[a-z]/.test(pw)) issues.push("a lowercase letter");
  if (!/\d/.test(pw)) issues.push("a number");
  if (!/[^A-Za-z0-9]/.test(pw)) issues.push("a symbol (!@#$%&*+-?)");
  if (/^(forward|catalog|admin|password|12345)/i.test(pw)) issues.push("must not start with forward/catalog/admin/password/12345");
  return issues;
}

const password = String(process.argv[2] || env.ADMIN_PASSWORD || "").trim();
if (!password) {
  console.error("No password given. Usage: node scripts/reset-admin-password.mjs \"My@NewPassword1\"");
  console.error("(or set ADMIN_PASSWORD in .env and run it without arguments)");
  process.exit(1);
}
const issues = passwordIssues(password);
if (issues.length) {
  console.error("That password is too weak. It needs:");
  for (const i of issues) console.error(`  • ${i}`);
  process.exit(1);
}

const salt = randomBytes(16).toString("hex");
const hash = scryptSync(password, salt, 32, { N: 16384, r: 8, p: 1 }).toString("hex");

const client = new pg.Client({ connectionString: DB_URL });
await client.connect();
try {
  await client.query(`CREATE TABLE IF NOT EXISTS settings (key text PRIMARY KEY, value jsonb NOT NULL)`);
  const prev = await client.query(`SELECT value->>'epoch' AS epoch FROM settings WHERE key='adminCredential'`);
  const epoch = Number(prev.rows[0]?.epoch || 0) + 1;
  const value = JSON.stringify({ salt, hash, epoch, updatedAt: new Date().toISOString(), source: "reset-script" });
  await client.query(
    `INSERT INTO settings (key, value) VALUES ('adminCredential', $1::jsonb)
     ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value`,
    [value]
  );
  await client.query(
    `INSERT INTO settings (key, value) VALUES ('loginGuard', $1::jsonb)
     ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value`,
    [JSON.stringify({ fails: 0, lockedUntil: null, lastFailAt: null, lastOkAt: null })]
  );
  console.log("\n✔ Dashboard password reset.\n");
  console.log(`  Sign in at   /admin`);
  console.log(`  Password     ${password}`);
  console.log(`  Sessions     all previous cookies invalidated (epoch ${epoch})`);
  console.log(`  Lockout      cleared\n`);
  console.log("Change it afterwards from Admin → Security → Dashboard password.");
} finally {
  await client.end();
}
