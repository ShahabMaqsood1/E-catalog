# PROJECT_HANDOFF.md — Forward Sports E-Catalog (3D Ball Configurator)

> **Purpose of this file:** single source of truth for any AI assistant (or developer) taking over
> this project. Read this FIRST. It contains the full state: decisions, architecture, data, pipelines,
> credentials, what works, what's mock, and exact next steps.
> Last updated: session 4 (v2 — mock 3D data + per-article rexine). Supersedes anything
> contradicting it in `HANDBOOK.md` (HANDBOOK.md remains valid as the original admin operating manual).

---

## 1. What this product is

B2B e-catalog + live 3D configurator for **Forward Sports** (Sialkot, PK) — football/soccer ball
manufacturing. Buyers browse 15 articles, configure them in 3D (rexine material, colourways, logo
placement, exploded "look inside" construction view), and request FOB quotes. The admin dashboard
manages articles, rexine materials, categories, uploads, front page, quotes, compliance, insights.

## 2. Session history (condensed)

1. **Sessions 1–2:** full app built (spec lived in a client gist). Shipped as `catalog.zip` inside
   GitHub repo **https://github.com/ShahabMaqsood1/E-catalog** (project root inside zip: `e/`).
2. **Session 3:** client sent `FLARE.svg`, `NEO.svg` (CorelDRAW panel maps) + one `3D Ball.stl`.
   SVG "Panel Intelligence" approach attempted → **client rejected it** (§3.1).
3. **Session 4a:** sandbox had been wiped → project **re-deployed from the GitHub zip**;
   **MODEL-FIRST pivot** implemented (§3.2, §7); 6 AI-generated rexine swatches added (the seeded
   `/textures/rx-*.jpg` files never existed in the zip — everything 404'd); seed made
   non-destructive (§9); sample STL attached to FLARE+NEO via the admin upload pipeline.
4. **Session 4b (this latest state):** client asked for (a) **mock 3D data for ALL articles**
   until real baked-artwork GLBs arrive, and (b) **a different rexine per article** ("keeping the
   same rexine materials for each ball in the list is wrong"). Both implemented and verified:
   `scripts/mock3d.mjs` generated 15 baked-artwork mock GLBs; `articles.defaultMaterialCode`
   column + 15 materials + full UI/API/seed wiring added.
5. **Session 4c (latest):** client's browser showed the "3D preview unavailable" SafeBoundary
   card (WebGL blocked — likely device setting or the embedded preview frame's permissions
   policy; r3f throws when it can't get a WebGL2 context, and the same failure explains the
   session-3 "3D isn't working" complaint). Fix: **WebGL-free resilience layer** — new
   `SoftBall` software renderer (shaded rotating sphere ray-marched on a plain 2D canvas from
   the SAME procedural wrap painter — no GPU needed) wired as the SafeBoundary fallback in the
   configurator, home hero and admin preview; SafeBoundary v2 (reason probe: missing-WebGL vs
   engine error, "Open in a new tab" button); studio IBL contained in its own `EnvBoundary`
   inside the viewer so an exotic-GPU environment failure can never kill the canvas.
6. **Session 4d (latest):** client feedback: "Look inside" and "close-up" did nothing in the
   software fallback, and clicking an article on narrow screens opened a full-page takeover.
   Fixes: **SoftBall v2** now software-implements BOTH studio modes with no GPU — damped
   close-up zoom (1.5×) and a full 4-layer exploded construction (wedge-cut cover/foam/lining +
   full bladder, per-pixel depth sort, cut-edge darkening, on-canvas layer label chips,
   focus-layer dimming, animated assemble/disassemble), mirroring the WebGL rig's radii/offsets.
   SafeBoundary card gained a **"How to enable WebGL"** guide (new tab, graphics acceleration,
   chrome://gpu, SwiftShader flag, drivers). Configurator mobile sheet rebuilt as a **right-side
   drawer** (max-w-xl, dimmed click-to-close backdrop, slide/fade keyframes `sf-drawer`/`sf-fade`
   in globals.css) — the article list stays visible behind it.
7. **Session 4g (branding, latest):** client: "this website is for catalog purpose only … use the
   logo + same theme from forward.pk; production/speciality bragging doesn't matter; point people
   to the website for equipment/staff/working." Done:
   - Brand assets downloaded to `public/brand/`: `forward-logo.png` (light bg, dark wordmark),
     `forward-logo-white.png` (dark bg, white wordmark), `favicon.ico` — from forward.pk.
   - Theme matched to forward.pk: brand red was ALREADY #CB0000 (site red); added their second
     font **DM Sans** (`@fontsource-variable/dm-sans`) as `--font-display` (body stays Manrope,
     their primary font); **dark header** (ink-950) with white logo + red "forward.pk ↗" button.
   - Catalog-only copy: capacity card ("1.5M balls/month") → "Everything else lives at
     forward.pk"; manufacturing-process section → "How this catalog works" (pick → configure →
     quote); compliance strip badges → single "Visit forward.pk" CTA; footer Compliance column →
     "Explore Forward Sports" links (main site / virtual tour / team / CSR); footer.about +
     complianceNote rewritten; metadata title/description + favicon updated.
   - All copy lives in `src/lib/content-schema.ts` DEFAULT_CONTENT (admin-editable via
     Settings → Site content; DB overrides merge over defaults — none saved yet).
8. **Session 4h (latest):** client follow-ups — (a) **logo/favicon are now dashboard-managed**:
   Admin → Site content → "Branding — logo & favicon" card uploads to `/api/upload`, saves
   settings key `brand` {logo, favicon}; layout (async) + Footer read it via `getSetting`,
   favicon via `generateMetadata`; defaults remain `public/brand/*` (shipped in project).
   (b) **Featured articles now reach the front page**: `page.tsx` appends featured articles
   (with their model + own rexine) to the hero rotation after editor presets, cap 6 — verified
   live (NEO featured → "NEO · Featured" in home hero). (c) **Rexine texture made PROMINENT**
   on baked models (client: "customer wouldn't notice"): bumpScale 0.4→1.35, swatch doubles as
   roughnessMap, roughness +0.3, and a colour **tint** = swatch average colour lerped at 0.45
   (`useGrainTexture` now returns {tex, tint}; knob list in §13). (d) **ALL mock swatch images
   DELETED** (public/textures/ + public/designs/ removed; materials.texture_url set '' in DB and
   seed; mock3d.mjs no longer paints swatches; picker shows a clean placeholder chip until real
   photos are uploaded via Admin → Materials). (e) everything visible in preview lives in
   project files (public/, storage/uploads/) — DB rows are the only non-file state; back up
   with `pg_dump` (§11).
7. **Session 4e (latest, CRITICAL):** headless-Chrome smoke test revealed the viewer had TWO
   real code crashes — the "3D preview unavailable" card was NEVER a WebGL problem:
   (a) the ORIGINAL zip calls `useLogoDrag` (an r3f `useThree` hook) in the `BallViewer` BODY,
   outside `<Canvas>` → r3f throws "Hooks can only be used within the Canvas component!" on
   every mount; the hook now lives INSIDE `Ball`/`ModelBall` (which are inside Canvas) and
   receives `logoDraggable`/`onLogoMove` props instead of a pre-built `drag` object;
   (b) three **r186**: `MeshPhysicalMaterial.copy(aMeshStandardMaterial)` CRASHES
   ("Cannot read properties of undefined (reading 'x')" — Physical.copy reads Physical-only
   vector fields). The baked-GLB material upgrade now forwards fields explicitly
   (color/map/normal(+scale)/rough(+map)/metal(+map)/ao/emissive/alpha/opacity/side/… +
   Physical extras only when the source is Physical). NEVER use `physical.copy(standard)` again.
   Verified with headless Chrome (SwiftShader): live WebGL2 canvas, mock GLB 200, zero errors,
   screenshot shows the studio rendering correctly. SafeBoundary v3 also gained a visible
   **diagnostics line** (WebGL probe + renderer string + thrown error) and a one-time 2.5 s
   auto-retry, so any future failure self-explains in the UI.

> ⚠️ Sandboxes reset between chats. The GitHub repo + this file are the durable artifacts.
> **The repo zip is STALE** — it lacks all session-3/4 code changes. The client was asked to
> commit the updated project back to GitHub. Recovery runbook: §11.

## 3. THE KEY DECISIONS (client's words)

1. **SVG panel maps are ABANDONED.** "Forget about getting svg file and stuff cause they won't
   work." CorelDRAW SVG exports are die-line sheets, not equirectangular wraps. `designSvgUrl`,
   `svgPanels.ts`, "Panel Intelligence" UI remain in code but are **dormant** (no article uses
   them; don't delete — harmless fallback).
2. **MODEL-FIRST:** client will supply a **baked-artwork GLB per article** (designer brief:
   `BLENDER_MCP_PROMPT.md`). The app loads the model, keeps its artwork exactly as designed, and
   animates it. **The viewer never assumes a panel shape** — any future shape (32p, 18p vortex,
   12p mini, volleyball…) drops in with zero code changes.
3. **Rexine texture clarity:** the selected material's swatch is applied over baked artwork as a
   physical FINISH only — tiling grain **bumpMap** (repeat 4×4, bumpScale 0.4; skipped if the
   model brings its own normalMap), finish-driven **roughness** (0.40 gloss / 0.62 when finish
   contains "matte"), **clearcoat 0.35/0.5 sheen**, under **local studio IBL** (drei
   `<Environment>` + 4 `<Lightformer>`s, no network fetches). Baked colours are never repainted.
4. **Mock 3D data (NEW):** until real GLBs arrive, **every article carries a procedurally
   generated baked-artwork mock GLB** (own colours, own panel-style artwork) — see §10/§12.
   They exercise the exact same baked-model path as the real files; replacement is a one-field
   PATCH per article.
5. **Per-article rexine (NEW):** every article has its **own default material**
   (`articles.default_material_code` → `materials.code`). The configurator pre-selects it when an
   article is opened/switched; buyers can still change material manually (manual pick wins until
   the next article switch). Homepage hero presets resolve material by their own `materialCode`
   setting (unchanged).

## 4. Tech stack & environment

| Thing | Value |
|---|---|
| Framework | Next.js **16.2.6** App Router, React 19.2.6, TS 5.9 |
| 3D | three **^0.186.1**, @react-three/fiber ^9.8.1, @react-three/drei ^10.7.9 |
| DB | PostgreSQL + Drizzle ORM 0.45.2 (`pg`). Sandbox: `postgresql://postgres:postgres@127.0.0.1:5432/app_db` |
| Schema mgmt | **No migration files.** `src/instrumentation.ts` → `bootstrapSchema()` (idempotent `CREATE TABLE IF NOT EXISTS` + an `ALTERS` array of `ADD COLUMN IF NOT EXISTS` in `src/db/bootstrap.ts`) + `ensureSeeded()` on every boot. Schema changes must be mirrored in `schema.ts` AND bootstrap DDL AND (for existing DBs) the ALTERS array. |
| Styling | Tailwind 4, tokens in `globals.css` (ink/brand/ok palette, blueprint-grid, Archivo+Manrope) |
| Uploads | disk `storage/uploads/` (gitignored, EPHEMERAL) served by `/api/files/[name]`; STL auto-converts to GLB on upload (`stlNormalize.ts`) |
| Env | `.env`: `DATABASE_URL=…app_db`, `ADMIN_PASSWORD=forward2026` |
| Mock data factory | **`scripts/mock3d.mjs`** — pure Node (zlib+pg, no deps): procedural equirectangular wrap painter (per panel style) → PNG encoder → GLB builder (UV sphere 96×64 ≈ 12.6k tris, embedded 1024×512 PNG) + swatch painter + DB updates. **Idempotent; re-run any time:** `node scripts/mock3d.mjs` (needs the DB booted once so ALTERS added `default_material_code`, else apply the ALTER manually first — the script prints a clear error). |

## 5. File map (what matters)

```
scripts/mock3d.mjs            → MOCK DATA FACTORY (§4) — 15 GLBs + 9 swatches + DB wiring
src/
  instrumentation.ts          → boot: bootstrapSchema() + ensureSeeded() (try/catch guarded)
  db/schema.ts                → Drizzle schema (8 tables, §6)
  db/bootstrap.ts             → DDL mirror + ALTERS[] (now includes default_material_code)
  db/seed.ts                  → SEED_VERSION="3"; 7 categories, **15 materials**, 15 articles,
                                ARTICLE_MATERIAL map (per-article rexine), compliance, settings.
                                Non-destructive versioned merge — §9.
  lib/ballTexture.ts          → procedural 2048×1024 equirect wrap painter (panel styles
                                classic-32/vortex-18/geo-24/mini-star/volley-18, rexine fill,
                                seams, artwork mode, dormant SVG mode, logo)
  lib/stlNormalize.ts         → STL→GLB (spherical UVs) used by /api/upload
  lib/svgPanels.ts            → DORMANT svg parser (§12 known quirks)
  lib/{content,content-schema,settings,insights,adminAuth,tour-steps,utils}.ts
  components/BallViewer.tsx   → THE 3D VIEWER — model-first logic (§7)
  components/Configurator.tsx → buyer studio; per-article material defaulting effect (on
                                articleId change → material matching defaultMaterialCode)
  components/BallThumb.tsx    → 2D procedural thumbnails (does NOT render GLBs)
  components/SoftBall.tsx     → WebGL-FREE software ball v2: rotating shaded sphere +
                                software close-up (damped 1.5× zoom) + software exploded view
                                (4 wedge-cut layers, depth-sorted, on-canvas labels, focus
                                dimming), adaptive 320→224→160px — SafeBoundary fallback
  components/SafeBoundary.tsx → v2: reason probe (webgl vs engine), Open-in-new-tab button,
                                renders caller-provided `fallback` node (SoftBall)
  components/HeroBall.tsx     → home hero driven by settings.heroPresets
  components/admin/AdminEditors.tsx → article editor now has a "Default rexine" select
                                (fetches materials, saves via generic draft spread)
  app/{page,catalog/page,admin/page}.tsx
  app/api/{health,admin/login,admin/logout,admin/[resource],upload,files/[name],quote,seed,activity}
public/
  textures/rx-arctic-white.jpg rx-lava-orange.jpg rx-carbon-black.jpg rx-crimson-red.jpg
           rx-teal-grip.jpg rx-royal-gold.jpg          → 6 AI-generated swatches (session 4a)
  textures/rx-pitch-green.png rx-training-orange.png rx-court-blue.png rx-hft-yellow.png
           rx-rhino-charcoal.png rx-striker-cobalt.png rx-candy-pink.png rx-volley-ivory.png
           rx-prisma-white.png                          → 9 procedural grain swatches (mock3d.mjs)
  designs/panel-map-ultrabond.svg                       → dormant demo svg
storage/uploads/              → mock-fs-*.glb ×15 + uploaded originals (EPHEMERAL per sandbox)
3D Ball.stl / FLARE.svg / NEO.svg → client samples (ride in the repo zip root)
HANDBOOK.md / BLENDER_MCP_PROMPT.md / Dockerfile / docker-compose*.yml
```

## 6. Database schema

- **categories**: id, slug✱, name, shortName, tagline, description, icon, sortOrder
- **articles**: id, categoryId→categories(cascade), articleNo✱, name, description, panelStyle,
  panelCount, basePrice numeric(10,2), moq, colors jsonb{base,accent,ink}, featured, status
  (live|draft), artworkUrl, designSvgUrl (DORMANT), **modelUrl** (PRIMARY 3D asset), modelAdjust
  jsonb{offsetX,offsetY,scale,rotY}, renderUrl, seamStyle(hand|machine|bonded|hybrid|auto),
  layerImages jsonb, specs jsonb{bladder,lining,foamMm,cover?}, cdrUploadId,
  **defaultMaterialCode** (NEW → materials.code; per-article rexine), createdAt
- **materials**: id, code✱, name, finish, description, textureUrl (swatch = picker image +
  painter fill + 3D grain bump), priceDelta numeric, thickness, weightGsm, isActive, sortOrder
- **quotes**: id, ref✱, articleId→articles(**set null**), contact fields, config jsonb, status
- **activity_log**, **uploads** (id, originalName, storedName, kind model|design-file|image,
  size, articleId, status, note), **compliance_items**
- **settings**: key text PK + value jsonb (NO id column). Keys: company, currency, defaultMoq,
  heroPresets, leadTime, quoteTiers, salesEmail, **seedVersion="3"**

## 7. THE 3D VIEWER (`BallViewer.tsx`) — current behaviour

Decision tree (non-exploded): `renderUrl && !modelUrl` → static img; **`modelUrl` → ModelBall**;
else procedural sphere. Exploded view = 4-layer wedge construction (unchanged).

**ModelBall (model-first):**
- Loads .glb/.gltf/.stl(+spherical UVs)/.obj; auto-normalises scale; **>900k-triangle guard**
  falls back to the procedural sphere.
- **Baked mode** (any mesh material has a `.map` — all mock + future real GLBs): materials
  cloned→MeshPhysicalMaterial (`.copy()` keeps every map), sRGB + anisotropy 8, then rexine
  FINISH overlay per §3.3. **Designer colours never repainted.**
- **Bare mode** (no maps — e.g. converted STL): procedural wrap re-skin with modelAdjust.
- **Animation:** damped turntable (0.4 rad/s) that **pauses while dragging** (OrbitControls
  start/end + 1.1 s resume) + subtle float; camera autoRotate disabled when a model spins
  itself; Configurator play/pause button drives it.
- Lighting: ambient 0.7 + 3 directionals + local `<Environment>`/`<Lightformer>` studio IBL,
  wrapped in `EnvBoundary` (if the IBL portal ever errors on an exotic GPU/driver it silently
  drops out and the plain lights keep the viewer alive).

**Failure resilience (sessions 4c/4d):** if the whole canvas subtree throws (most common:
browser or embedded preview frame blocks WebGL → r3f can't create a WebGL2 context),
`SafeBoundary` catches it and renders: reason-specific message, a collapsible **"How to enable
WebGL"** guide (open in new tab / graphics-acceleration setting / chrome://gpu check /
SwiftShader flag for GPU-less machines / driver update), Try again + Open-in-a-new-tab buttons,
and — crucially — a **`SoftBall` software preview**: the article's real wrap (colours, panel
style, rexine, seams) ray-marched onto a shaded rotating sphere with pure Canvas2D
(`buildBallCanvas` at res 1024, per-pixel lambert+specular+rim, adaptive resolution).
**SoftBall v2 implements the studio modes too:** close-up = damped 1.5× zoom; Look inside =
software exploded view (same layer radii 1/0.8/0.63/0.48 and x-offsets 0.95/0.35/−0.25/−0.78
as the WebGL rig; 90° camera-facing wedge cuts on cover/foam/lining; full bladder, latex-aware
colouring; per-pixel nearest-layer z-sort; cut-edge darkening; on-canvas label chips with
name+detail; focus-layer dimming; damped assemble/disassemble animation). Props are fed from
Configurator (article+material+autoRotate+closeUp+exploded+specs+layerMeta+focusLayer),
HeroBall (preset+layers+focus) and the admin preview (static). Buyers NEVER lose a feature to a
WebGL block. Note: SoftBall shows the PROCEDURAL wrap — for mock/real baked GLBs it renders the
equivalent procedural artwork (same colours/style), not the GLB's own pixels
(decoding+software-rastering a GLB is deliberately out of scope).

**Narrow-screen UX (4d):** clicking an article under 1024 px opens the configurator as a
right-side DRAWER (`max-w-xl`, backdrop dims the list, click backdrop or X to close, slide/fade
animations via `sf-drawer`/`sf-fade` keyframes in `globals.css`) — no more full-page takeover.

## 8. API quick reference

| Endpoint | Method | Auth | Notes |
|---|---|---|---|
| `/api/admin/login` | POST `{password}` | — | cookie session; password `forward2026` |
| `/api/admin/[resource]` | GET | cookie | articles, materials, categories, quotes, uploads, activity, compliance, settings, insights → **`{rows:[…]}`** |
| `/api/admin/[resource]` | POST/PATCH | cookie | PATCH `{id,data:{…}}` → `{row}`. Article data accepts **modelUrl, modelAdjust, defaultMaterialCode** (""→null), artworkUrl, renderUrl, designSvgUrl, layerImages… Material data accepts textureUrl etc. |
| `/api/upload` | POST multipart `file` | cookie | images/svg/stl/glb/gltf/obj; STL→GLB auto; response has `upload.url` + **`derived.glb.url`** (attach the derived GLB) |
| `/api/files/[name]` | GET | — | serves storage/uploads; glb→`model/gltf-binary` |
| `/api/quote`, `/api/health`, `/api/seed`, `/api/activity` | — | — | quote=public; health=platform check |

## 9. Seeding & restart-safety (IMPORTANT — do not revert)

- Fresh DB (0 categories) → full insert (7 cats, **15 materials**, 15 articles with
  `defaultMaterialCode` from `ARTICLE_MATERIAL`, compliance). Article ids 1..15.
- Existing DB → gate `settings.seedVersion !== SEED_VERSION("3")` → **NON-DESTRUCTIVE upsert
  merge by articleNo**: updates ONLY seed-owned fields (categoryId, name, description,
  panelStyle, panelCount, basePrice, moq, colors, featured, specs, **defaultMaterialCode**,
  seamStyle) and inserts missing seed articles. **Never deletes; never touches modelUrl,
  modelAdjust, artworkUrl, designSvgUrl, renderUrl, layerImages, cdrUploadId, status.**
  Proven across reboots (session 3 had a destructive delete+insert here that wiped attachments).
- The merge does NOT insert materials on existing DBs — new materials on an already-seeded DB
  come from `scripts/mock3d.mjs` (idempotent) or Admin → Materials.
- Settings seed loop runs every boot (onConflictDoNothing).

## 10. Current live data state (verified after reboot, seedVersion=3)

**Articles (ids 1–15, all live, ALL with mock baked GLB + own rexine):**

| id | articleNo | name | style | price | mock model | default rexine |
|----|-----------|------|-------|-------|------------|----------------|
| 1 | FS-TB-01 | FLARE | vortex-18 | 26.25 | mock-fs-tb-01.glb | FS-RX-06 Royal Pearl Metallic |
| 2 | FS-TB-02 | BLAZE | vortex-18 | 16.47 | mock-fs-tb-02.glb | FS-RX-02 Lava Pebble TPU |
| 3 | FS-TB-03 | NEO | vortex-18 | 10.30 | mock-fs-tb-03.glb | FS-RX-01 Arctic Gloss PU |
| 4 | FS-TB-04 | FUTSAL MATCH UP | vortex-18 | 9.84 | mock-fs-tb-04.glb | FS-RX-05 Aqua Grip Dimple |
| 5 | FS-HS-05 | MUNDIALE | vortex-18 | 11.50 | mock-fs-hs-05.glb | FS-RX-04 Crimson Microfiber |
| 6 | FS-HS-06 | MATCH | classic-32 | 6.49 | mock-fs-hs-06.glb | FS-RX-03 Carbon Weave |
| 7 | FS-HS-07 | FUTSAL PRO | classic-32 | 12.00 | mock-fs-hs-07.glb | FS-RX-07 Pitch Green Suede |
| 8 | FS-HS-08 | FUTSAL TRAINING | vortex-18 | 7.70 | mock-fs-hs-08.glb | FS-RX-08 Training Orange Matte |
| 9 | FS-HS-09 | HAND BALL | vortex-18 | 8.67 | mock-fs-hs-09.glb | FS-RX-09 Court Blue Grip |
| 10 | FS-MS-10 | HFT | vortex-18 | 6.45 | mock-fs-ms-10.glb | FS-RX-10 HFT Yellow Microfiber |
| 11 | FS-MS-11 | RIHNO | geo-24 | 3.85 | mock-fs-ms-11.glb | FS-RX-11 Rhino Charcoal Weave |
| 12 | FS-MS-12 | STRIKER | geo-24 | 3.50 | mock-fs-ms-12.glb | FS-RX-12 Striker Cobalt Gloss |
| 13 | FS-MB-13 | MINI BALL | mini-star | 2.90 | mock-fs-mb-13.glb | FS-MB-13RX Candy Soft-touch Pink |
| 14 | FS-VB-14 | VOLLEY BALL | volley-18 | 4.15 | mock-fs-vb-14.glb | FS-RX-14 Volley Ivory Micro |
| 15 | FS-MS-15 | DIGITAL PRINTED | geo-24 | 4.05 | mock-fs-ms-15.glb | FS-RX-15 Prisma Print-grade White |

MOQs: ids 1–8 → 500; ids 9–15 → 1000. Categories: thermal-bonded, hand-stitched,
machine-stitched, hybrid, amb-mini, volleyballs, medicine-balls.

**Materials (15):** FS-RX-01…06 = original six (AI-photo swatches `/textures/rx-*.jpg`,
deltas 2.50–5.00) + FS-RX-07…15 & FS-MB-13RX = nine new (procedural grain swatches
`/textures/rx-*.png`, deltas 1.80–4.60, finishes: Suede touch / Matte TPU / Dimple grip /
Microfiber PU / Textured weave / Gloss PU / Soft-touch PU / Print-grade PU).

⚠️ **ALL rexine names, codes, finishes, price deltas AND swatch images are INVENTED mock data**
— they do not reference any real supplier or catalog (client confirmed aware, session 4h).
The 6 JPGs were AI-generated; the 9 PNGs are procedural grain from `scripts/mock3d.mjs`.
To replace with the factory's REAL rexines: photograph each material flat, even diffuse light,
no shadows, frame-filling, ~1024×1024+, then either (a) Admin → Materials → edit → upload
swatch (updates textureUrl live), or (b) overwrite the same filename in `public/textures/`
(zero DB/code change). Rename materials/codes/prices in the same editor. Mapping:

| material code | name (mock) | swatch file in public/textures/ |
|---|---|---|
| FS-RX-01 | Arctic Gloss PU | rx-arctic-white.jpg |
| FS-RX-02 | Lava Pebble TPU | rx-lava-orange.jpg |
| FS-RX-03 | Carbon Weave Rexine | rx-carbon-black.jpg |
| FS-RX-04 | Crimson Microfiber PU | rx-crimson-red.jpg |
| FS-RX-05 | Aqua Grip Dimple | rx-teal-grip.jpg |
| FS-RX-06 | Royal Pearl Metallic | rx-royal-gold.jpg |
| FS-RX-07 | Pitch Green Suede | rx-pitch-green.png |
| FS-RX-08 | Training Orange Matte | rx-training-orange.png |
| FS-RX-09 | Court Blue Grip | rx-court-blue.png |
| FS-RX-10 | HFT Yellow Microfiber | rx-hft-yellow.png |
| FS-RX-11 | Rhino Charcoal Weave | rx-rhino-charcoal.png |
| FS-RX-12 | Striker Cobalt Gloss | rx-striker-cobalt.png |
| FS-MB-13RX | Candy Soft-touch Pink | rx-candy-pink.png |
| FS-RX-14 | Volley Ivory Micro | rx-volley-ivory.png |
| FS-RX-15 | Prisma Print-grade White | rx-prisma-white.png |

The swatch image does triple duty: picker chip, procedural-wrap panel fill (bare-mesh/fallback
rendering) and 3D grain bumpMap + tint over baked artwork — so a REAL photo of the actual
material makes all three correct at once. Generic leather-grain photos (if real ones aren't
handy yet): ambientCG.com (CC0), Textures.com, Poliigon — but for "exact texture" the factory
should photograph its own stock.

**Status after session 4h:** all mock swatch files are GONE. Every `materials.texture_url` row
is empty; the picker renders a neutral placeholder chip; the 3D shows baked artwork with plain
finish until a photo is uploaded (Admin → Materials → edit → upload swatch — sets texture_url
live, no rebuild). Client is actively uploading their own rexine photos and 3D GLBs now.

**Mock GLB spec:** UV sphere 96×64 (12,610 verts / 12,096 tris), embedded 1024×512 PNG
equirectangular wrap painted per article (panel-style patterns: vortex swirl bands, classic
brick-32 w/ dashed stitching, geo-24 triangles, mini-star w/ 5-lobe star motif, volley-18 wavy
6-panel; colours = article `colors{base,accent,ink}`; micro-grain + polar shading), roughness
0.5 / metallic 0, ~0.8–1.0 MB each. Generated by `scripts/mock3d.mjs` — tweak patterns there
and re-run (idempotent, re-attaches everything).

## 11. Post-reset recovery runbook (exact commands)

```bash
# 1. deploy project (if sandbox reset to template)
curl -sL -o /tmp/repo.zip https://codeload.github.com/ShahabMaqsood1/E-catalog/zip/refs/heads/main
cd /tmp && unzip -q repo.zip && unzip -q E-catalog-main/catalog.zip -d unz
cd <project-root> && rm -rf src public storage scripts
tar -C /tmp/unz/e -cf - --exclude=.git . | tar -xf -
printf 'DATABASE_URL=postgresql://postgres:postgres@127.0.0.1:5432/app_db\nADMIN_PASSWORD=forward2026\n' > .env
mkdir -p storage/uploads && npm install
# 2. re-apply ALL code changes listed in §12 (the repo zip is stale!)
# 3. validate + boot
npx next typegen && npm exec tsc -- --noEmit && npm run build   # then platform build_and_start
#    (first boot runs bootstrap: creates tables incl. default_material_code + seeds fresh DB)
# 4. regenerate mock data (GLBs+swatches live in ephemeral dirs; DB rows persist per instance)
node scripts/mock3d.mjs
# 5. verify
curl -s -o /dev/null -w "%{http_code}\n" localhost:3000/api/files/mock-fs-tb-01.glb   # 200
psql postgresql://postgres:postgres@127.0.0.1:5432/app_db -Atc \
 "select count(*) from articles where model_url like '/api/files/mock-%'"              # 15
```

**Replacing a mock with the client's REAL baked GLB (ongoing workflow):**
Admin → Articles → edit article → Upload 3D model (.glb) → save. Or API:
`POST /api/upload` (multipart) → `PATCH /api/admin/articles {"id":N,"data":{"modelUrl":"/api/files/<stored>.glb"}}`.
Set `modelAdjust.rotY` if the artwork needs rotating. Nothing else to change — baked mode is
automatic when the GLB carries textures.

**Designer delivery spec:** one .glb per article; artwork baked as base-colour texture (optional
normal/roughness maps are honoured — viewer skips its grain bump when a normalMap exists);
<900k triangles; export WITH UVs; `BLENDER_MCP_PROMPT.md` is the existing Blender brief.

## 12. All code changes vs. the original zip (cumulative — re-apply after any reset)

**Session 4a (model-first pivot):**
1. `src/components/BallViewer.tsx` — ModelBall rewritten: baked-artwork detection & KEEP
   (MeshPhysicalMaterial copy + rexine finish overlay: grain bumpMap repeat(4,4) bumpScale 0.4,
   finish roughness, clearcoat 0.35/0.5, envMapIntensity 0.9); bare-mesh fallback re-skin;
   damped turntable spin w/ drag-pause + float; `useGrainTexture` hook; local
   `<Environment>`+4×`<Lightformer>` IBL; ambient 0.85→0.7, key 1.7→1.5; OrbitControls
   autoRotate off when a model spins itself.
2. `src/db/seed.ts` — versioned migration made NON-DESTRUCTIVE (upsert merge by articleNo, §9).
3. `src/components/Configurator.tsx` — "Studio 3D model · designer artwork" badge when modelUrl;
   "Vector panels" badge suppressed when modelUrl.
4. `public/textures/rx-{arctic-white,lava-orange,carbon-black,crimson-red,teal-grip,royal-gold}.jpg`
   — 6 AI-generated swatches (were missing → 404s).

**Session 4b (mock data + per-article rexine):**
5. `src/db/schema.ts` — articles.defaultMaterialCode (text, nullable).
6. `src/db/bootstrap.ts` — column in CREATE TABLE articles + ALTERS entry.
7. `src/db/seed.ts` — SEED_VERSION "2"→"3"; MATERIAL_SEED +9 entries (FS-RX-07…15,
   FS-MB-13RX); `ARTICLE_MATERIAL` map; insertArticles + merge set defaultMaterialCode.
8. `src/components/Configurator.tsx` — CatalogArticle.defaultMaterialCode; effect on
   `[articleId]` pre-selects the article's material.
9. `src/app/catalog/page.tsx` — passes defaultMaterialCode through.
10. `src/app/api/admin/[resource]/route.ts` — buildArticleData accepts defaultMaterialCode
    (""→null).
11. `src/components/admin/AdminEditors.tsx` — ArticleRow.defaultMaterialCode; empty draft;
    "Default rexine" select in the article editor (fetches materials on open).
12. **`scripts/mock3d.mjs` (NEW)** — mock data factory (§4/§10); 9 procedural swatch PNGs in
    `public/textures/`.

**Session 4c (WebGL resilience):**
13. `src/components/SoftBall.tsx` (NEW) — WebGL-free software ball renderer (§7).
14. `src/components/SafeBoundary.tsx` — rewritten v2: `fallback?: ReactNode` prop, WebGL probe
    (webgl2→webgl) to pick the message, "Open in a new tab" button, keeps Try again.
15. `src/components/BallViewer.tsx` — `EnvBoundary` class added; `<Environment>` wrapped in it;
    react import extended (Component, ReactNode).
16. `src/components/Configurator.tsx` — SoftBall import + fallback passed to studio boundary
    (uses current article + selected material + autoRotate state).
17. `src/components/HeroBall.tsx` — SoftBall fallback from hero preset data.
18. `src/components/admin/AdminEditors.tsx` — SoftBall fallback from article draft
    (autoRotate=false).

**Session 4d (fallback modes + drawer UX):**
19. `src/components/SoftBall.tsx` — v2: closeUp zoom + exploded 4-layer software view with
    labels/focus dimming (props: closeUp, exploded, specs, layerNames, focusLayer).
20. `src/components/SafeBoundary.tsx` — added "How to enable WebGL" <details> guide.
21. `src/components/Configurator.tsx` — fallback props extended; mobile sheet → right-side
    drawer with click-to-close backdrop.
22. `src/components/HeroBall.tsx` — fallback props extended (exploded/specs/layerNames/focus).
23. `src/app/globals.css` — `sf-fade` + `sf-drawer` keyframes appended.

**Session 4e (the real "3D never worked" bugs):**
24. `src/components/BallViewer.tsx` — `useLogoDrag` moved out of the BallViewer body INTO
    `Ball` and `ModelBall` (inside `<Canvas>`); both take `logoDraggable` + `onLogoMove` props;
    call sites updated. This was in the ORIGINAL zip and crashed every WebGL viewer since
    session 1 — the likely root of every "3D isn't working" complaint ever received.
25. `src/components/BallViewer.tsx` — baked-GLB material upgrade: replaced
    `mat.copy(src)` with explicit per-field forwarding (three r186 crash, see §2.7b).
26. `src/components/SafeBoundary.tsx` — v3: diagnostics line (WebGL probe + renderer + error
    text), one-time 2.5 s auto-retry, clarifying copy that the fallback below is software.
27. Headless smoke-test recipe added to §14 (puppeteer --no-save + SwiftShader flags) — use it
    whenever the 3D path is touched; it produces a screenshot you can actually LOOK at.

**Session 4g (forward.pk branding / catalog-only):**
28. `public/brand/` — forward-logo.png, forward-logo-white.png, favicon.ico (from forward.pk).
29. `src/components/Header.tsx` — rewritten: dark chrome, white logo, "Product Catalog"
    subtitle, red forward.pk external button (also in mobile menu).
30. `src/components/Footer.tsx` — white logo; Compliance badges column → "Explore Forward
    Sports" link column (forward.pk / tour / team / CSR).
31. `src/app/page.tsx` — compliance badge strip → "Visit forward.pk" CTA; compliance DB query +
    BadgeCheck import removed.
32. `src/lib/content-schema.ts` — catalog-only copy swaps (capacity card, process steps,
    compliance strip, catalog eyebrow, footer about/note).
33. `src/app/layout.tsx` — DM Sans import, catalog-only metadata title/description, favicon icon.
34. `src/app/globals.css` — `--font-display` → "DM Sans Variable" (site heading font);
    `@fontsource-variable/dm-sans` added to package.json (the ONLY package added this session).

**Session 4h (dashboard branding, featured fix, texture prominence, mock cleanup):**
35. `src/lib/content-schema.ts` — `BrandCfg` + `DEFAULT_BRAND` (public/brand defaults).
36. `src/app/layout.tsx` — async RootLayout + `generateMetadata`; reads settings `brand`;
    passes logo to Header; favicon from settings.
37. `src/components/Header.tsx` / `Footer.tsx` — logo from brand settings (prop / getSetting).
38. `src/components/admin/ContentTab.tsx` — "Branding — logo & favicon" upload card (live save
    to settings `brand`; preview chips; uses existing uploadFile helper).
39. `src/app/page.tsx` — featured articles appended to hero rotation (front-page visibility).
40. `src/components/BallViewer.tsx` — `useGrainTexture` returns {tex, tint}; baked branch:
    bumpScale 1.35 + roughnessMap + roughness+0.3 + colour lerp 0.45 (PROMINENT rexine).
41. `scripts/mock3d.mjs` — swatch generation removed; `public/textures/` + `public/designs/`
    deleted from repo; `materials.texture_url` emptied in DB + seed + HeroBall fallback.

**Known dormant issues (SVG path — do not fix unless revived):** `svgPanels.ts` only reads
`fill="…"` attributes (CorelDRAW CSS-class fills unread); `ballTexture.ts` stretches non-2:1 SVG
maps; SVG copy still in Configurator meta panel.

## 13. Next steps (priority order)

1. **Client delivers real baked GLBs per article** → replace mocks one by one (§11 workflow).
   Verify baked mode (artwork intact; rexine switch changes grain/sheen/price only) and set
   `modelAdjust.rotY` per model.
2. When all real: delete mock GLBs from storage/uploads (or leave — they're unreferenced).
3. Real factory rexine swatch photos → replace `/textures/rx-*` files (same filenames = zero
   code change; or Admin → Materials → textureUrl per material).
4. Optional polish (not requested yet): thumbnail renders for model articles (BallThumb is still
   2D procedural — consider renderUrl or offscreen capture), per-article spin-speed setting,
   Draco/meshopt support in `useUploadedModel` if real GLBs exceed ~5 MB, AR/QR view.
5. Tuning knobs for texture pop (client feedback): bumpScale 0.4, clearcoat 0.35,
   envMapIntensity 0.9, grain repeat 4×4 — all in BallViewer ModelBall baked branch.
6. **Client's WebGL issue:** their browser/preview frame triggers the SafeBoundary. Tell them:
   use "Open in a new tab" (embedded previews often block WebGL), enable hardware acceleration
   (Chrome: Settings → System; Windows: Settings → Display → Graphics), or try another browser.
   Meanwhile they now always get the SoftBall software preview. If the console shows
   `[SafeBoundary:studio] engine error` while WebGL2 probe succeeds, capture the logged error —
   that would point at a genuine code/driver issue instead of a blocked context.
   As of 4d, ALL viewer features work even with WebGL blocked (software close-up + exploded
   view), so the fallback is a functional mode, not a crippled state.

## 14. Validation checklist (run before declaring done, every session)

```bash
npx next typegen            # ✓ route types
npm exec tsc -- --noEmit    # ✓ zero errors
npm run build               # ✓ production build
# platform build_and_start, then:
curl -s localhost:3000/api/health                                  # ok
for u in / /catalog /admin /api/files/mock-fs-tb-01.glb /textures/rx-pitch-green.png; do
  curl -s -o /dev/null -w "$u %{http_code}\n" localhost:3000$u; done        # all 200
psql postgresql://postgres:postgres@127.0.0.1:5432/app_db -Atc \
 "select (select count(*) from articles where model_url is not null)||' models, '|| \
         (select count(*) from articles where default_material_code is not null)||' rexine-linked, '|| \
         (select count(*) from materials)||' materials'"                    # 15, 15, 15
# reboot once more → same counts + same article ids (merge is non-destructive)

# DB backup (the ONLY non-file state — run before exporting the project):
pg_dump postgresql://postgres:postgres@127.0.0.1:5432/app_db > db-backup.sql
# restore on a fresh sandbox: psql ... -f db-backup.sql  (instead of relying on the seed)

# HEADLESS 3D SMOKE TEST (proves the WebGL path renders; produces a screenshot):
npm i --no-save puppeteer          # NOT a project dep — never add to package.json
sudo -n apt-get install -y -qq libnspr4 libnss3 libatk1.0-0 libatk-bridge2.0-0 libcups2 \
  libdrm2 libxkbcommon0 libxcomposite1 libxdamage1 libxfixes3 libxrandr2 libgbm1 \
  libasound2 libpango-1.0-0 libcairo2            # chrome shared libs (sandbox-only)
# launch with: ["--no-sandbox","--enable-unsafe-swiftshader","--use-gl=angle",
#               "--use-angle=swiftshader","--disable-dev-shm-usage"]
# goto /catalog, wait ~10 s, assert: no "3D preview unavailable" in body text,
# a canvas with a live webgl2 context exists, /api/files/mock-*.glb returned 200,
# no [SafeBoundary]/R3F console warnings; page.screenshot → inspect visually.
```

## 16. Session 5 (client's 10-point list) — what changed and why

The GitHub `Catalog.zip` turned out to be **NEWER than this handoff** (it already contained
sessions 4h–4j: hashed admin auth, `messages` table, `public/media` tree, mail/contact config,
localize/import APIs, the guided tour, the split catalog page). Everything below was verified
against that tree, then fixed or completed.

**THE "PASSWORD IS NOT WORKING" BUG (root cause, fixed).** `ADMIN_PASSWORD` defaulted to
`forward2026` in `.env.example` **and in `docker-compose.yml`**. `passwordIssues()` rejects it
(< 12 chars, no uppercase, no symbol), so `getCredential()` silently generated a RANDOM strong
password and printed it once in the server log — on the client's Docker machine nobody ever saw
it, hence "the password doesn't work". Fixes:
1. `.env` + `.env.example` + `docker-compose.yml` now default to the strong, documented
   **`Fwd@Catalog2026!`** (satisfies every rule; note a password may NOT start with
   forward/catalog/admin/password/12345, so `Forward@2026` would still be rejected).
2. `adminAuth.getCredential()` now **re-adopts a strong `ADMIN_PASSWORD` on every boot while the
   stored source is not `dashboard`** — so fixing the env file and restarting always gets you back
   in. A password set in the dashboard (source `dashboard`) permanently wins over the file.
3. A generated password is also written to `storage/admin-recovery.txt` (mode 0600) instead of
   only the log, and is deleted as soon as a known password takes over.
4. **`scripts/reset-admin-password.mjs` (NEW)** — emergency reset with no sign-in needed:
   `node scripts/reset-admin-password.mjs "My@NewPass123"` (or no argument → uses `.env`).
   Writes the scrypt hash, bumps the epoch (kills all cookies), clears the lockout.
5. `AdminLogin.tsx` — show/hide password + a "Password not working?" recovery panel with the four
   steps above.

**Dashboard tabs that existed only as APIs are now real UI** (`src/components/admin/OperationsTabs.tsx`,
wired into `AdminStudio.tsx` as `inbox` / `media` / `security`):
- **Inbox & mail** (item 8) — SMTP host/port/SSL/user/pass/from/fromName/replyTo + enable toggle,
  "Send test e-mail", last-delivery status; recipient e-mails + phone/WhatsApp/address/hours/
  response note (defaults `hassanqulaba@forward.pk`, `adeel@forward.pk`, `+92 345 6680616`);
  the stored `messages` inbox with delivered/not-delivered badges, filters and status actions.
- **Media & files** (items 6 + 10) — inventory of all eight `public/media/<folder>/` buckets with
  thumbnails and sizes, plus "Copy external files into the project" (POST `/api/admin/localize`)
  which downloads any http(s) asset into the project and rewrites the DB row.
- **Security** (item 2) — credential status, live strength meter, change password, sign out every
  device, and the locked-out recovery command.
- `AdminStudio` Settings tab also got its missing `tour: "tab-settings"` anchor.

**Item 1 — "remove the add logo option": DONE.** The buyer-facing *Your logo on the ball* upload
(`logoBlock` in `Configurator.tsx`) is gone, together with its tour step (chapters renumbered 6–7)
and the "your logo" wording in the catalog intro. The 3D logo plumbing (`logoUrl`, `LogoControls`,
`logoT`, viewer props) is deliberately left in place but unreachable — re-enabling is a one-line
change. There was never a logo upload in the dashboard (layout.tsx: brand assets ship as files).

**Item 3 — navbar: already correct** (`Header.tsx` NAV = Home / Catalog / Contact us; category
shortcuts live as chips on the catalog page). Verified, unchanged.

**Item 4 — split catalog page: hardened.** The right pane is now
`sticky top-16 h-[calc(100vh-4rem)] overflow-y-auto overscroll-contain` (was `max-h-…`, so it
could collapse) and a **native non-passive `wheel` listener** (`railRef` in `Configurator.tsx`)
stops the pane's scroll from chaining into the page at both ends. React registers `wheel`
passively, so `onWheel` + `preventDefault()` would have been ignored — do not "simplify" it back.
The `lg:border-l` divider runs the full content height down to the footer; the left column is the
only thing that moves the page.

**Item 5 — guided tour: kept and made loud** (client chose "make it stand out" over removal).
Pulsing brand button in the header + `TourCta`, per-page tours (home/catalog/contact/admin),
live demos that actually operate the configurator, and new steps for the Inbox & mail / Media &
files / Security tabs.

**Items 6 + 10 — everything lives inside the project.** Uploads already went to
`public/media/{rexine,models,renders,artwork,layers,brand,designs,misc}` via `/api/upload`, served
by `/api/files/<folder>/<name>` (legacy `storage/uploads` still readable). Changed this session:
- `scripts/mock3d.mjs` now writes its 15 mock GLBs to **`public/media/models/`** and stores
  `model_url = /api/files/models/mock-<articleNo>.glb` (was the ephemeral `storage/uploads`).
- **`.gitignore` (NEW)** ignores node_modules/.next/.env/storage but **explicitly keeps
  `public/media/**` and `public/brand/**`** — committing the repo is what makes the data survive
  the move to Forward's PC. `docker-compose.yml` additionally mounts a `media:` volume at
  `/app/public/media` so uploads survive image rebuilds.
- `public/brand/` was MISSING from the zip (every logo/favicon request 404'd). Re-downloaded
  `forward-logo.png`, `forward-logo-white.png`, `favicon.ico` from `https://forward.pk/webImages/`.

**Item 9 — persistence: verified.** Every page is `force-dynamic` and all edits write to the
`settings`/content tables; a test edit of `catalog.title` appeared on `/catalog` immediately and
survived refresh, then reverted cleanly.

**THE DOCKER BUILD FAILURE (fixed).** `COPY --from=builder /app/public ./public` failed with
`"/app/public": not found` because the repo shipped **no `public/` directory at all**. The builder
stage now runs `mkdir -p public/brand public/media/* storage/uploads` before `npm run build`, so
the copy can never fail even on a checkout without those folders — and `public/` now really exists
with the brand assets and the media tree.

**Verification run this session (all green):** `next typegen` ✓ · `tsc --noEmit` ✓ (0 errors) ·
`next build` ✓ · `/api/health`, `/`, `/catalog`, `/contact`, `/admin`, `/brand/*`,
`/api/files/models/mock-fs-tb-01.glb` all 200 · login with `Fwd@Catalog2026!` returns 200 +
cookie, wrong password 401, `/api/admin/*` 401 unauthenticated · DB: 15 articles / 15 with model /
15 rexine-linked / 15 materials · contact POST stored a row with `delivered=false` and the note
"Mail server not configured" (nothing is ever lost).

**Next session's first job:** the client still has to enter their real SMTP mailbox in
Admin → Inbox & mail (e.g. `no-reply@forward.pk`) and press *Send test* — until then enquiries are
stored but not e-mailed. Then replace the 15 mock GLBs with the designer's baked models
(Admin → Articles → upload) and add real rexine swatch photos (Admin → Rexine materials).

---

## 15. Credentials & pointers

- Admin: `/admin` → password **`Fwd@Catalog2026!`** (env `ADMIN_PASSWORD`; change it in
  Admin → Security — that value is hashed in the DB and wins over the file). Locked out?
  `node scripts/reset-admin-password.mjs "My@NewPass123"`.
- Repo: https://github.com/ShahabMaqsood1/E-catalog (`Catalog.zip`) — the zip is now NEWER than
  §12 of this file; §16 documents the current state.
- Original spec gist: https://gist.github.com/ShahabMaqsood1/88877075dbc43749c6a5c01edde7c4c5
- Preview URL changes per sandbox session (platform-managed).
- DB + storage/uploads are sandbox-local and EPHEMERAL. Durable = repo + this file + scripts.

---
*For the next AI: diff the deployed tree against the GitHub zip, re-apply §12 if missing, run
`node scripts/mock3d.mjs` if storage/textures are empty, run §14, continue from §13. Do not
resurrect the SVG pipeline (§3.1). Keep seeding non-destructive (§9).*
